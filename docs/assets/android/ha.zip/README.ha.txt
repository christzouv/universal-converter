UNIVERSAL CONVERTER DON ANDROID - FARAWA
Sigar 3.2

Universal Converter yana sauya hotuna, takardu, bidiyo da sauti, yana yin PDF kuma yana sa musu hannu, kuma yana fitar da tebura zuwa Excel. Komai yana faruwa a wayarka: ba a taɓa loda fayilolinka ba. Manhajar tana amfani da intanet ne kawai don duba sabbin sigogi, don sauke haruffan gane rubutu da ka zaɓa, da lokacin da ka buɗe hanyar haɗi. Idan ka yarda, tana kuma aika rahotannin kurakurai ba tare da suna ba idan wani abu ya lalace.

ABIN DA TAKE YI
Takardu & PDF - Sauyawa tsakanin PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint da Excel. Mayar da shafuka hotuna, da haɗa fayiloli da yawa cikin PDF ɗaya. Matse PDF: ƙara PDF, zaɓi Matse PDF sannan ka shigar da girman da kake buƙata (misali 500 KB); ana rage hotunan da ke ciki har sai ya dace, rubutu kuma yana nan a fili.
Hotuna - Sauyawa tsakanin JPG, PNG, WEBP, BMP, GIF, TIFF da ICO. Ana iya buɗe hotunan HEIC da AVIF ma. Canza girma da pixel, kashi ko girman fayil. Mayar da hotuna PDF ko Word, da karanta rubutun da ke cikin hotuna (OCR). Ana iya ƙara PDF ma: kowane shafi ya zama hoto.
Bidiyo - Sauya bidiyo zuwa MP4, MKV, WebM ko MOV, ko yi GIF mai motsi. MP4, MKV da MOV suna amfani da H.264 ko H.265 daga mai ɓoyewa na kayan aikin wayarka; WebM yana amfani da buɗaɗɗun tsarin VP9 da Opus. Zaɓi inganci, ƙuduri da ɓangaren bidiyo; yanke, juya ko cire sautin; ko ajiye sautin kawai a matsayin M4A, OGG ko WAV.
Ajiye firam - A shafin Bidiyo, zaɓi Ajiye firam, zaɓi lokacin kuma ajiye hoto ɗaya kowace 'yan daƙiƙoƙi, kowane firam ko ɗaya kawai.
Zuwa Excel - Fitar da tebura daga PDF, sikanin, hotuna da fayilolin Word zuwa Excel ko CSV.
Sa hannu - Sa hannu a kan PDF kuma cike fom. Yi sa hannunka sau ɗaya – rubuta sunanka ka zaɓi salo, zana shi da yatsanka ko alƙalami, ko yi amfani da hotonsa a kan takarda – sannan bari manhajar ta nemo layukan sa hannu, ko taɓa shafin inda sa hannu, baƙaƙe, kwanan wata, rubutu ko alamomi za su tafi. Ana sa hannu a fayiloli da yawa lokaci ɗaya; ana ajiye kowanne a matsayin suna_signed.pdf, kuma na asali yana nan yadda yake. Wannan sa hannu ne na lantarki da ake iya gani, ba sa hannu na dijital mai takardar shaida ba.

YADDA AKE AMFANI
1. Zaɓi shafi a ƙasan allo.
2. Danna Ƙara fayiloli, ko raba fayiloli zuwa Universal Converter daga wata manhaja.
3. Zaɓi tsari da zaɓuɓɓuka. Danna (i) kusa da zaɓi don karanta abin da yake yi.
4. Danna maɓallin da ke ƙasan zaɓuɓɓukan.
Ana ajiye sakamako a Downloads/Universal Converter. Yi amfani da Buɗe ko Raba don amfani da su nan take.
Idan ka ƙara fayilolin da wani shafi ke sauyawa, manhajar tana gaya maka wane shafi kuma tana kai su can da taɓawa ɗaya.

DOGAYEN SAUYAWA
Kana iya barin manhajar yayin da bidiyo ke sauyawa. Sanarwa tana nuna cewa har yanzu tana aiki, don haka da fatan ka ba da izinin sanarwa idan aka tambaya. Dogayen bidiyo ko masu ƙuduri mai girma na iya ɗaukar lokaci kuma su ɗumama wayar.

GANE RUBUTU (OCR)
Turanci da sauran harsuna masu haruffan Latin, da Girkanci, suna ciki. Kai tsaye yana karanta waɗannan da kowane haruffa da ka sauke. Don karanta wasu harsuna, taɓa Canza kusa da Harsuna ka zaɓi harsunan da ke cikin fayilolinka: idan ɗaya yana buƙatar haruffan da ba su a wayar tukuna (Cyrillic, Larabci, Sinanci, Japananci, Koriyanci, Thai, Hindi, Jojiyanci, Tamil), manhajar tana ba da damar sauke su nan take, kuma ka ci gaba daga inda kake. Ana iya cire haruffan da aka sauke a Saituna. Idan ba a iya karanta yawancin rubutun ba, manhajar tana faɗin haka kuma tana ba da shawarar ƙara haruffa. Har yanzu ba a iya gane rubutun Ibrananci ba.

HARSUNA
Duk harsuna 18 suna ciki: zaɓi ɗaya a Saituna > Harshen manhaja, kuma manhajar za ta sake farawa da wannan harshe. Ana nuna Larabci da Ibrananci daga dama zuwa hagu. Manhajar duhu ce da farko; zaɓi Haske ko Bi waya a Saituna > Kamanni.

IYAKOKI A WAYA
Ba za a iya buɗe tsofaffin fayilolin .doc da .ppt ba: fara ajiye su a matsayin .docx ko .pptx. Har yanzu ba a iya karanta fayilolin .ods ba, kuma har yanzu ba a iya mayar da PDF masu kalmar sirri hotuna ba. Manyan fayiloli sosai na iya kasawa a wayoyi masu ƙaramin ƙwaƙwalwa. Bidiyon da za a iya buɗewa ya dogara da wayarka.

SABUNTAWA
Manhajar tana duba sabuwar siga kusan sau ɗaya a rana kuma tana gaya maka idan akwai (kashe shi a Saituna > Sabuntawa). Taɓa Sauke, sannan buɗe fayil ɗin da aka sauke don shigar da shi a kan wannan; saitunanka suna nan. Idan ka shigar da manhajar daga Google Play, Google Play ne ke sabunta ta.

CIREWA
Riƙe alamar manhajar ka zaɓi Cire. Fayilolin da ka sauya suna nan a Downloads/Universal Converter.

TAIMAKO DA TALLAFI
Tambayoyi, rahotannin matsala da buƙatun sabbin abubuwa: https://github.com/christzouv/universal-converter/issues
Imel don tambayoyi, ra'ayoyi da harsunan da kake son a ƙara: universal.converter@outlook.com
Shafin yanar gizo: https://christzouv.github.io/universal-converter/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Duk haƙƙoƙi an kiyaye su.