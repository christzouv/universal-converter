UNIVERSAL CONVERTER TIL ANDROID - KOM GODT I GANG
Version 4.0

Universal Converter konverterer billeder, dokumenter, videoer og lyd, laver PDF'er og trækker tabeller over i Excel. Alt sker på din telefon: dine filer bliver aldrig uploadet. Appen bruger kun internettet til at søge efter nye versioner, til at hente de alfabeter til tekstgenkendelse, du vælger, og når du åbner et link. Hvis du tillader det, sender den også anonyme fejlrapporter, når noget går galt.

HVAD DEN GØR
Dokumenter og PDF - Konvertér mellem PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint og Excel. Lav sider om til billeder, og saml flere filer i én PDF. Under PDF kan du slå Komprimér PDF til (angiv en størrelse som 500 KB; teksten forbliver skarp) og Underskriv (sæt din underskrift på hver PDF). Excel og CSV trækker tabeller ud af PDF'er, scanninger og fotos.
Billeder - Konvertér mellem JPG, PNG, WEBP, BMP, GIF, TIFF og ICO. Fotos i HEIC og AVIF kan også åbnes. Skift størrelse i pixels, procent eller filstørrelse. Lav billeder om til PDF eller Word, og læs teksten i billeder (OCR). PDF'er kan også tilføjes: hver side bliver til et billede.
Video - Konvertér videoer til MP4, MKV, WebM eller MOV, eller lav en animeret GIF. MP4, MKV og MOV bruger H.264 eller H.265 fra telefonens hardwareencoder; WebM bruger de åbne formater VP9 og Opus. Vælg kvaliteten, opløsningen og den del af videoen, du vil have; beskær, rotér eller fjern lyden; eller gem kun lyden som MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF eller MKA. Med flere videoer på listen kan du trykke på en for at give den sine egne indstillinger eller kopiere dem til alle.
Gem billeder - Vælg Gem billeder på fanen Video, vælg tidsintervallet, og gem et billede med få sekunders mellemrum, hvert billede eller kun ét.
Underskriv - Underskriv PDF'er og udfyld formularer. Lav din underskrift én gang - skriv dit navn og vælg en stil, tegn den med fingeren eller en pen, eller brug et foto af den på papir - og lad så appen finde underskriftslinjerne, eller tryk på siden, hvor underskrift, initialer, dato, tekst eller flueben skal stå. Mange filer underskrives på én gang; hver gemmes som navn_signed.pdf, og originalen forbliver, som den var. Dette er en synlig elektronisk underskrift, ikke en certifikatbaseret digital signatur.

SÅDAN BRUGER DU DEN
1. Tryk på Tilføj filer, eller del filer til Universal Converter fra en anden app.
2. Tryk på en fil i listen: dens egne indstillinger åbner.
3. Tryk på et format: dets indstillinger åbner lige under det. Tryk på (i) ved siden af en indstilling for at læse, hvad den gør.
4. Gå tilbage til listen og tryk på Konvertér: hver fil konverteres.
Resultaterne gemmes i Downloads/Universal Converter. Brug Åbn eller Del for at bruge dem med det samme.
Du kan vælge et andet sted i Indstillinger > Standardplacering til gemte filer; appen spørger én gang, efter din første konvertering.
Hver fil har sine egne indstillinger: kopiér dem fra den forrige fil i samme format eller til hver fil i det format; "Næste fil" fører dig videre til den næste.
Har du ikke brug for et format? Skjul det under Indstillinger > Formater. Filer uden valgt format får standardformatet (Indstillinger > Standardformater).
Menuen ☰ øverst til venstre åbner Indstillinger, denne vejledning, Nyheder & rettelser og Støt; Indstillinger findes også øverst til højre.

LANGE KONVERTERINGER
Du kan forlade appen, mens en video konverteres: den arbejder videre i baggrunden. Lange videoer eller videoer i høj opløsning kan tage et stykke tid og gøre telefonen varm. Hvis du vil, giver Indstillinger > Notifikationer besked, når en konvertering er færdig. Ryst telefonen kraftigt for at starte Konvertér (Indstillinger > Ryst for at konvertere).

TEKSTGENKENDELSE (OCR)
Engelsk og andre sprog med latinsk alfabet samt græsk er indbygget. Automatisk læser disse og alle alfabeter, du har hentet. For at læse andre sprog skal du trykke på Skift ved siden af Sprog og sætte flueben ved sprogene i dine filer: hvis et af dem kræver et alfabet, der ikke er på telefonen endnu (kyrillisk, arabisk, kinesisk, japansk, koreansk, thai, hindi, georgisk, tamil), tilbyder appen at hente det med det samme, og du fortsætter, hvor du var. Hentede alfabeter kan fjernes i Indstillinger. Hvis meget af teksten ikke kan læses, siger appen det og tilbyder at tilføje et alfabet. Hebraisk og vietnamesisk læses også: hvert hentes én gang, første gang du vælger det. Scanninger og udfyldte formularer bliver til redigerbar tekst og tabeller, sat op som siden (indstillingen "Sider med billeder af tekst" i en PDF's indstillinger).

SPROG
Alle 34 sprog er indbygget: vælg et i Indstillinger > Appens sprog, så genstarter appen på det sprog. Arabisk og hebraisk vises fra højre mod venstre. Appen er mørk som standard; vælg Lyst eller Følg telefonen i Indstillinger > Udseende.

BEGRÆNSNINGER PÅ EN TELEFON
Meget store filer kan mislykkes på telefoner med lidt hukommelse. Hvilke videoer der kan åbnes, afhænger af din telefon.

OPDATERINGER
Appen søger efter en ny version cirka én gang om dagen og siger til, når der er en (slå det fra i Indstillinger > Opdateringer). Tryk på Hent, og åbn så den hentede fil for at installere den oven på denne; dine indstillinger bliver bevaret. Hvis du har installeret appen fra Google Play, opdaterer Google Play den i stedet.

AFINSTALLATION
Hold appens ikon nede, og vælg Afinstaller. Filer, du har konverteret, bliver, hvor de blev gemt.

HJÆLP OG SUPPORT
Spørgsmål, fejlrapporter og ønsker om funktioner: universal.converter@outlook.com
E-mail til spørgsmål, idéer og sprog, du gerne vil have: universal.converter@outlook.com
Websted: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Alle rettigheder forbeholdes.
