UNIVERSAL CONVERTER FOR ANDROID - KOM I GANG
Versjon 4.0

Universal Converter konverterer bilder, dokumenter, videoer og lyd, lager PDF-er og henter tabeller inn i Excel. Alt skjer på telefonen din: filene dine lastes aldri opp. Appen bruker bare internett for å se etter nye versjoner, for å laste ned alfabetene for tekstgjenkjenning som du velger, og når du åpner en lenke. Hvis du tillater det, sender den også anonyme feilrapporter når noe går galt.

HVA DEN GJØR
Dokumenter og PDF - Konverter mellom PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint og Excel. Gjør sider om til bilder, og slå sammen flere filer til én PDF. Under PDF kan du slå på Komprimer PDF (skriv inn en størrelse som 500 KB; teksten forblir skarp) og Signer (sett signaturen din på hver PDF). Excel og CSV henter tabeller ut av PDF-er, skanninger og bilder.
Bilder - Konverter mellom JPG, PNG, WEBP, BMP, GIF, TIFF og ICO. Bilder i HEIC og AVIF kan også åpnes. Endre størrelse i piksler, prosent eller filstørrelse. Gjør bilder om til PDF eller Word, og les teksten i bilder (OCR). PDF-er kan også legges til: hver side blir et bilde.
Video - Konverter videoer til MP4, MKV, WebM eller MOV, eller lag en animert GIF. MP4, MKV og MOV bruker H.264 eller H.265 fra telefonens maskinvarekoder; WebM bruker de åpne formatene VP9 og Opus. Velg kvaliteten, oppløsningen og delen av videoen; beskjær, roter eller fjern lyden; eller lagre bare lyden som MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF eller MKA. Med flere videoer i listen trykker du på én for å gi den egne innstillinger, eller kopierer dem til alle.
Lagre bilder - Velg Lagre bilder i fanen Video, velg tidsrommet og lagre et bilde med noen sekunders mellomrom, hvert bilde eller bare ett.
Signer - Signer PDF-er og fyll ut skjemaer. Lag signaturen din én gang - skriv navnet ditt og velg en stil, tegn den med fingeren eller en penn, eller bruk et bilde av den på papir - og la så appen finne signaturlinjene, eller trykk på siden der signatur, initialer, dato, tekst eller haker skal stå. Mange filer signeres på én gang; hver lagres som navn_signed.pdf, og originalen blir som den var. Dette er en synlig elektronisk signatur, ikke en sertifikatbasert digital signatur.

SLIK BRUKER DU DEN
1. Trykk på Legg til filer, eller del filer til Universal Converter fra en annen app.
2. Trykk på en fil i listen: dens egne valg åpnes.
3. Trykk på et format: alternativene åpnes rett under det. Trykk på (i) ved siden av et alternativ for å lese hva det gjør.
4. Gå tilbake til listen og trykk på Konverter: hver fil konverteres.
Resultatene lagres i Downloads/Universal Converter. Bruk Åpne eller Del for å bruke dem med en gang.
Du kan velge et annet sted i Innstillinger > Standard lagringssted; appen spør én gang, etter den første konverteringen din.
Hver fil har egne innstillinger: kopier dem fra forrige fil i samme format eller til hver fil i det formatet; «Neste fil» tar deg videre til neste.
Trenger du ikke et format? Skjul det i Innstillinger > Formater. Filer uten valgt format får standardformatet (Innstillinger > Standardformater).
Menyen ☰ øverst til venstre åpner Innstillinger, denne veiledningen, Nyheter & rettelser og Støtt; Innstillinger finnes også øverst til høyre.

LANGE KONVERTERINGER
Du kan forlate appen mens en video konverteres: den fortsetter å jobbe i bakgrunnen. Lange videoer eller videoer med høy oppløsning kan ta litt tid og gjøre telefonen varm. Hvis du vil, sier Innstillinger > Varsler fra når en konvertering er ferdig. Rist telefonen kraftig for å starte Konverter (Innstillinger > Rist for å konvertere).

TEKSTGJENKJENNING (OCR)
Engelsk og andre språk med latinsk alfabet, og gresk, er innebygd. Automatisk leser disse og alle alfabeter du har lastet ned. For å lese andre språk trykker du på Endre ved siden av Språk og haker av språkene i filene dine: hvis et av dem trenger et alfabet som ikke er på telefonen ennå (kyrillisk, arabisk, kinesisk, japansk, koreansk, thai, hindi, georgisk, tamil), tilbyr appen å laste det ned med en gang, og du fortsetter der du var. Nedlastede alfabeter kan fjernes i Innstillinger. Hvis mye av teksten ikke kan leses, sier appen fra og tilbyr å legge til et alfabet. Hebraisk og vietnamesisk leses også: hvert lastes ned én gang, første gang du velger det. Skanninger og utfylte skjemaer blir redigerbar tekst og tabeller, lagt opp som siden (alternativet "Sider med bilder av tekst" i valgene for en PDF).

SPRÅK
Alle 34 språk er innebygd: velg ett i Innstillinger > Appens språk, så starter appen på nytt på det språket. Arabisk og hebraisk vises fra høyre mot venstre. Appen er mørk som standard; velg Lyst eller Følg telefonen i Innstillinger > Utseende.

BEGRENSNINGER PÅ EN TELEFON
Svært store filer kan mislykkes på telefoner med lite minne. Hvilke videoer som kan åpnes, avhenger av telefonen din.

OPPDATERINGER
Appen ser etter en ny versjon omtrent én gang om dagen og sier fra når det finnes en (slå dette av i Innstillinger > Oppdateringer). Trykk på Last ned, og åpne så den nedlastede filen for å installere den over denne; innstillingene dine blir værende. Hvis du installerte appen fra Google Play, oppdaterer Google Play den i stedet.

AVINSTALLERING
Hold inne ikonet til appen og velg Avinstaller. Filer du har konvertert, blir liggende der de ble lagret.

HJELP OG STØTTE
Spørsmål, problemrapporter og ønsker om funksjoner: universal.converter@outlook.com
E-post for spørsmål, idéer og språk du ønsker: universal.converter@outlook.com
Nettsted: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Med enerett.
