UNIVERSAL CONVERTER NA ANDROIDA - PIERWSZE KROKI
Wersja 3.1

Universal Converter konwertuje obrazy, dokumenty, filmy i dźwięk, tworzy i podpisuje pliki PDF oraz przenosi tabele do Excela. Wszystko dzieje się na Twoim telefonie: Twoje pliki nigdy nie są wysyłane. Aplikacja łączy się z internetem tylko po to, by sprawdzić nowe wersje, pobrać wybrane alfabety rozpoznawania tekstu i gdy otwierasz link. Jeśli na to pozwolisz, wysyła też anonimowe raporty o błędach, gdy coś pójdzie nie tak.

CO POTRAFI
Dokumenty i PDF - Konwersja między PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint i Excel. Zamiana stron na obrazy i łączenie wielu plików w jeden PDF. Kompresuj PDF: dodaj plik PDF, wybierz Kompresuj PDF i wpisz potrzebny rozmiar (np. 500 KB); obrazy w środku są zmniejszane, aż plik się zmieści, a tekst pozostaje ostry.
Obrazy - Konwersja między JPG, PNG, WEBP, BMP, GIF, TIFF i ICO. Można też otwierać zdjęcia HEIC i AVIF. Zmiana rozmiaru w pikselach, procentach lub według rozmiaru pliku. Zamiana obrazów na PDF lub Word i odczyt tekstu z obrazów (OCR). Można też dodawać pliki PDF: każda strona staje się obrazem.
Wideo - Konwersja filmów do MP4, MKV, WebM lub MOV albo tworzenie animowanych GIF-ów. MP4, MKV i MOV korzystają z H.264 lub H.265 ze sprzętowego kodera telefonu; WebM używa otwartych formatów VP9 i Opus. Wybierz jakość, rozdzielczość i fragment filmu; kadruj, obracaj lub usuń dźwięk; albo zapisz sam dźwięk jako M4A, OGG lub WAV.
Zapisz klatki - W karcie Wideo wybierz Zapisz klatki, ustaw zakres czasu i zapisuj jeden obraz co kilka sekund, każdą klatkę lub tylko jedną.
Do Excela - Wyodrębnianie tabel z plików PDF, skanów, zdjęć i plików Word do Excela lub CSV.
Podpisz - Podpisuj pliki PDF i wypełniaj formularze. Utwórz podpis raz - wpisz imię i nazwisko i wybierz styl, narysuj go palcem lub rysikiem albo użyj zdjęcia podpisu na papierze - a potem pozwól aplikacji znaleźć linie podpisu albo stuknij stronę tam, gdzie mają trafić podpis, inicjały, data, tekst lub znaczniki. Wiele plików podpisuje się za jednym razem; każdy jest zapisywany jako nazwa_signed.pdf, a oryginał pozostaje bez zmian. Jest to widoczny podpis elektroniczny, a nie podpis cyfrowy oparty na certyfikacie.

JAK UŻYWAĆ
1. Wybierz kartę na dole ekranu.
2. Stuknij Dodaj pliki albo udostępnij pliki do Universal Converter z innej aplikacji.
3. Wybierz format i opcje. Stuknij (i) obok opcji, aby przeczytać, co robi.
4. Stuknij przycisk pod opcjami.
Wyniki są zapisywane w Downloads/Universal Converter. Użyj Otwórz lub Udostępnij, aby od razu z nich skorzystać.
Jeśli dodasz pliki, które konwertuje inna karta, aplikacja wskaże tę kartę i przeniesie je tam jednym stuknięciem.

DŁUGIE KONWERSJE
Możesz wyjść z aplikacji, gdy film się konwertuje. Powiadomienie pokazuje, że praca trwa, więc zezwól na powiadomienia, gdy pojawi się pytanie. Długie filmy lub filmy w wysokiej rozdzielczości mogą zająć trochę czasu i rozgrzać telefon.

ROZPOZNAWANIE TEKSTU (OCR)
Angielski i inne języki zapisywane alfabetem łacińskim, w tym polski, oraz grecki są wbudowane. Tryb automatyczny czyta je oraz każdy pobrany alfabet. Aby odczytywać inne języki, stuknij Zmień obok Języki i zaznacz języki swoich plików: jeśli któryś wymaga alfabetu, którego nie ma jeszcze na telefonie (cyrylica, arabski, chiński, japoński, koreański, tajski, hindi, gruziński, tamilski), aplikacja od razu zaproponuje jego pobranie, a potem wrócisz do tego, co robisz. Pobrane alfabety można usunąć w Ustawieniach. Jeśli dużej części tekstu nie da się odczytać, aplikacja o tym informuje i proponuje dodanie alfabetu. Tekstu hebrajskiego nie da się jeszcze rozpoznać.

JĘZYKI
Wszystkie 18 języków jest wbudowanych: wybierz język w Ustawienia > Język aplikacji, a aplikacja uruchomi się ponownie w tym języku. Arabski i hebrajski są wyświetlane od prawej do lewej. Aplikacja domyślnie ma ciemny motyw; wybierz Jasny lub Jak w telefonie w Ustawienia > Wygląd.

OGRANICZENIA NA TELEFONIE
Starych plików .doc i .ppt nie można otworzyć: najpierw zapisz je jako .docx lub .pptx. Plików .ods nie da się jeszcze odczytać, a chronionych hasłem plików PDF nie można jeszcze zamienić na obrazy. Bardzo duże pliki mogą się nie udać na telefonach z małą ilością pamięci. To, które filmy da się otworzyć, zależy od telefonu.

AKTUALIZACJE
Aplikacja mniej więcej raz dziennie sprawdza, czy jest nowa wersja, i informuje o niej (wyłączysz to w Ustawienia > Aktualizacje). Stuknij Pobierz, a potem otwórz pobrany plik, aby zainstalować go w miejsce tej wersji; ustawienia zostają. Jeśli zainstalowano aplikację z Google Play, aktualizuje ją Google Play.

ODINSTALOWANIE
Przytrzymaj ikonę aplikacji i wybierz Odinstaluj. Przekonwertowane pliki zostają w Downloads/Universal Converter.

POMOC I WSPARCIE
Pytania, zgłoszenia problemów i propozycje funkcji: https://github.com/christzouv/universal-converter/issues
E-mail na pytania, pomysły i języki, które chcesz dodać: universal.converter@outlook.com
Strona internetowa: https://christzouv.github.io/universal-converter/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Wszelkie prawa zastrzeżone.