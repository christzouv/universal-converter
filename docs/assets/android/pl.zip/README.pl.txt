UNIVERSAL CONVERTER NA ANDROIDA - PIERWSZE KROKI
Wersja 3.0

Universal Converter konwertuje obrazy, dokumenty, filmy i dźwięk, tworzy i podpisuje pliki PDF oraz przenosi tabele do Excela. Wszystko dzieje się na Twoim telefonie: Twoje pliki nigdy nie są wysyłane. Aplikacja łączy się z internetem tylko, aby sprawdzić nowe wersje, pobrać wybrane języki i gdy otwierasz link. Jeśli na to pozwolisz, wysyła też anonimowe raporty o błędach, gdy coś pójdzie nie tak.

CO POTRAFI
Dokumenty i PDF - Konwersja między PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint i Excel. Zamiana stron na obrazy i łączenie wielu plików w jeden PDF. Kompresuj PDF: dodaj plik PDF, wybierz Kompresuj PDF i wpisz potrzebny rozmiar (np. 500 KB); obrazy w środku są zmniejszane, aż plik się zmieści, a tekst pozostaje ostry.
Obrazy - Konwersja między JPG, PNG, WEBP, BMP, GIF, TIFF i ICO. Można też otwierać zdjęcia HEIC i AVIF. Zmiana rozmiaru w pikselach, procentach lub według rozmiaru pliku. Zamiana obrazów na PDF lub Word i odczyt tekstu z obrazów (OCR). Można też dodawać pliki PDF: każda strona staje się obrazem.
Wideo - Konwersja filmów do MP4 lub MKV z H.264 lub H.265 za pomocą sprzętowego kodera telefonu. Wybierz jakość, rozdzielczość i fragment filmu; kadruj, obracaj lub usuń dźwięk; albo zapisz tylko dźwięk jako M4A.
Zapisz klatki - W karcie Wideo wybierz Zapisz klatki, ustaw zakres czasu i zapisuj jeden obraz co kilka sekund, każdą klatkę lub tylko jedną.
Do Excela - Wyciąganie tabel z plików PDF, skanów, zdjęć i plików Word do Excela lub CSV.
Podpisz - Podpisuj pliki PDF i wypełniaj formularze. Utwórz podpis raz - wpisz imię i nazwisko i wybierz styl, narysuj go myszą lub palcem albo użyj zdjęcia podpisu na papierze - a potem pozwól aplikacji znaleźć linie podpisu albo kliknij na stronie tam, gdzie mają trafić podpis, inicjały, data, tekst lub znaczniki. Wiele plików podpisuje się za jednym razem; każdy jest zapisywany jako nazwa_signed.pdf, a oryginał pozostaje bez zmian. Jest to widoczny podpis elektroniczny, a nie podpis cyfrowy oparty na certyfikacie.

JAK UŻYWAĆ
1. Wybierz kartę na dole ekranu.
2. Stuknij Dodaj pliki albo udostępnij pliki do Universal Converter z innej aplikacji.
3. Wybierz format i opcje. Stuknij (i) obok opcji, aby przeczytać, co robi.
4. Stuknij przycisk pod opcjami.
Wyniki są zapisywane w Downloads/Universal Converter. Użyj Otwórz lub Udostępnij, aby od razu z nich skorzystać.
Jeśli dodasz pliki, które konwertuje inna karta, aplikacja wskaże tę kartę i przeniesie je tam jednym stuknięciem.

DŁUGIE KONWERSJE
Możesz wyjść z aplikacji, gdy film się konwertuje. Powiadomienie pokazuje, że praca trwa, więc zezwól na powiadomienia, gdy pojawi się pytanie. Długie filmy lub filmy w wysokiej rozdzielczości mogą zająć trochę czasu i rozgrzać telefon.

ROZPOZNAWANIE TEKSTU (OCR)
Angielski i inne języki w alfabecie łacińskim, w tym polski, oraz grecki są wbudowane. Automatycznie czyta je i każdy pobrany alfabet; wybranie jednego czyta szybciej. Inne alfabety (cyrylica, arabski, chiński, japoński, koreański, tajski, hindi, gruziński, tamilski) można pobrać w Ustawieniach, a potem wybrać w każdej karcie; tam też można je usunąć, aby zwolnić miejsce. Jeśli dużej części tekstu nie da się odczytać, aplikacja o tym informuje i proponuje dodanie alfabetu. Tekstu hebrajskiego nie da się jeszcze rozpoznać.

JĘZYKI
Angielski i grecki są wbudowane. Hiszpański, włoski, niemiecki, francuski, portugalski, polski, rosyjski, arabski, hebrajski, chiński, japoński, koreański, tamilski, afrikaans, joruba i hausa pobierają się po wybraniu w Ustawieniach, a aplikacja uruchamia się ponownie, aby ich użyć; pobrane języki można też tam usunąć. Aplikacja domyślnie jest ciemna; wybierz Jasny lub Jak w telefonie w Ustawienia > Wygląd.

OGRANICZENIA NA TELEFONIE
Starych plików .doc i .ppt nie można otworzyć: najpierw zapisz je jako .docx lub .pptx. Plików .ods nie da się jeszcze odczytać, a chronionych hasłem plików PDF nie można jeszcze zamienić na obrazy. Bardzo duże pliki mogą się nie udać na telefonach z małą ilością pamięci. To, które filmy da się otworzyć, zależy od telefonu.

AKTUALIZACJE
Aplikacja mniej więcej raz dziennie sprawdza, czy jest nowa wersja, i informuje o niej (wyłączysz to w Ustawienia > Aktualizacje). Stuknij Pobierz, a potem otwórz pobrany plik, aby zainstalować go na tej wersji; ustawienia zostają. Jeśli zainstalowano aplikację z Google Play, aktualizuje ją Google Play.

ODINSTALOWANIE
Przytrzymaj ikonę aplikacji i wybierz Odinstaluj. Przekonwertowane pliki zostają w Downloads/Universal Converter.

POMOC I WSPARCIE
Pytania, zgłoszenia problemów i propozycje funkcji: https://github.com/christzouv/universal-converter/issues
E-mail na pytania, pomysły i języki, które chcesz dodać: universal.converter@outlook.com
Strona internetowa: https://christzouv.github.io/universal-converter/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Wszelkie prawa zastrzeżone.