UNIVERSAL CONVERTER NA ANDROIDA - PIERWSZE KROKI
Wersja 4.0

Universal Converter konwertuje obrazy, dokumenty, filmy i dźwięk, tworzy i podpisuje pliki PDF oraz przenosi tabele do Excela. Wszystko dzieje się na Twoim telefonie: Twoje pliki nigdy nie są wysyłane. Aplikacja łączy się z internetem tylko po to, by sprawdzić nowe wersje, pobrać wybrane alfabety rozpoznawania tekstu i gdy otwierasz link. Jeśli na to pozwolisz, wysyła też anonimowe raporty o błędach, gdy coś pójdzie nie tak.

CO POTRAFI
Dokumenty i PDF - Konwersja między PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint i Excel. Zamiana stron na obrazy i łączenie wielu plików w jeden PDF. W PDF można włączyć Kompresuj PDF (wpisz rozmiar, np. 500 KB; tekst pozostaje ostry) i Podpisz (umieść podpis na każdym pliku PDF). Excel i CSV wyciągają tabele z plików PDF, skanów i zdjęć.
Obrazy - Konwersja między JPG, PNG, WEBP, BMP, GIF, TIFF i ICO. Można też otwierać zdjęcia HEIC i AVIF. Zmiana rozmiaru w pikselach, procentach lub według rozmiaru pliku. Zamiana obrazów na PDF lub Word i odczyt tekstu z obrazów (OCR). Można też dodawać pliki PDF: każda strona staje się obrazem.
Wideo - Konwersja filmów do MP4, MKV, WebM lub MOV albo tworzenie animowanych GIF-ów. MP4, MKV i MOV korzystają z H.264 lub H.265 ze sprzętowego kodera telefonu; WebM używa otwartych formatów VP9 i Opus. Wybierz jakość, rozdzielczość i fragment filmu; kadruj, obracaj lub usuń dźwięk; albo zapisz sam dźwięk jako MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF lub MKA. Gdy na liście jest kilka filmów, dotknij jednego, aby nadać mu własne ustawienia, albo skopiuj je do wszystkich.
Zapisz klatki - W karcie Wideo wybierz Zapisz klatki, ustaw zakres czasu i zapisuj jeden obraz co kilka sekund, każdą klatkę lub tylko jedną.
Podpisz - Podpisuj pliki PDF i wypełniaj formularze. Utwórz podpis raz - wpisz imię i nazwisko i wybierz styl, narysuj go palcem lub rysikiem albo użyj zdjęcia podpisu na papierze - a potem pozwól aplikacji znaleźć linie podpisu albo stuknij stronę tam, gdzie mają trafić podpis, inicjały, data, tekst lub znaczniki. Wiele plików podpisuje się za jednym razem; każdy jest zapisywany jako nazwa_signed.pdf, a oryginał pozostaje bez zmian. Jest to widoczny podpis elektroniczny, a nie podpis cyfrowy oparty na certyfikacie.

JAK UŻYWAĆ
1. Stuknij Dodaj pliki albo udostępnij pliki do Universal Converter z innej aplikacji.
2. Dotknij pliku na liście: otworzą się jego własne opcje.
3. Stuknij format: jego opcje otworzą się tuż pod nim. Stuknij (i) obok opcji, aby przeczytać, co robi.
4. Wróć do listy i dotknij Konwertuj: każdy plik zostanie przekonwertowany.
Wyniki są zapisywane w Downloads/Universal Converter. Użyj Otwórz lub Udostępnij, aby od razu z nich skorzystać.
Inne miejsce wybierzesz w Ustawienia > Domyślne miejsce zapisu; aplikacja pyta raz, po pierwszej konwersji.
Każdy plik ma własne ustawienia: skopiuj je z poprzedniego pliku tego samego formatu albo do każdego pliku tego formatu; „Następny plik” przenosi do kolejnego.
Nie potrzebujesz jakiegoś formatu? Ukryj go w Ustawieniach > Formaty. Pliki bez wybranego formatu dostają domyślny (Ustawienia > Domyślne formaty).
Menu ☰ w lewym górnym rogu otwiera Ustawienia, ten poradnik, Co nowego i poprawki oraz Wsparcie; Ustawienia są też w prawym górnym rogu.

DŁUGIE KONWERSJE
Możesz wyjść z aplikacji podczas konwersji wideo: działa dalej w tle. Długie filmy lub filmy w wysokiej rozdzielczości mogą trwać dłużej i nagrzewać telefon. Jeśli chcesz, Ustawienia > Powiadomienia poinformują, gdy konwersja się zakończy. Potrząśnij mocno telefonem, aby uruchomić Konwertuj (Ustawienia > Potrząśnij, aby konwertować).

ROZPOZNAWANIE TEKSTU (OCR)
Angielski i inne języki zapisywane alfabetem łacińskim, w tym polski, oraz grecki są wbudowane. Tryb automatyczny czyta je oraz każdy pobrany alfabet. Aby odczytywać inne języki, stuknij Zmień obok Języki i zaznacz języki swoich plików: jeśli któryś wymaga alfabetu, którego nie ma jeszcze na telefonie (cyrylica, arabski, chiński, japoński, koreański, tajski, hindi, gruziński, tamilski), aplikacja od razu zaproponuje jego pobranie, a potem wrócisz do tego, co robisz. Pobrane alfabety można usunąć w Ustawieniach. Jeśli dużej części tekstu nie da się odczytać, aplikacja o tym informuje i proponuje dodanie alfabetu. Odczytywany jest też hebrajski i wietnamski: każdy z nich pobiera się raz, przy pierwszym wyborze. Skany i wypełnione formularze stają się tekstem i tabelami do edycji, ułożonymi jak na stronie (opcja „Strony z tekstem w postaci obrazu” w opcjach pliku PDF).

JĘZYKI
Wszystkie 34 języki są wbudowane: wybierz język w Ustawienia > Język aplikacji, a aplikacja uruchomi się ponownie w tym języku. Arabski i hebrajski są wyświetlane od prawej do lewej. Aplikacja domyślnie ma ciemny motyw; wybierz Jasny lub Jak w telefonie w Ustawienia > Wygląd.

OGRANICZENIA NA TELEFONIE
Bardzo duże pliki mogą się nie udać na telefonach z małą ilością pamięci. To, które filmy da się otworzyć, zależy od telefonu.

AKTUALIZACJE
Aplikacja mniej więcej raz dziennie sprawdza, czy jest nowa wersja, i informuje o niej (wyłączysz to w Ustawienia > Aktualizacje). Stuknij Pobierz, a potem otwórz pobrany plik, aby zainstalować go w miejsce tej wersji; ustawienia zostają. Jeśli zainstalowano aplikację z Google Play, aktualizuje ją Google Play.

ODINSTALOWANIE
Przytrzymaj ikonę aplikacji i wybierz Odinstaluj. Przekonwertowane pliki zostają tam, gdzie zostały zapisane.

POMOC I WSPARCIE
Pytania, zgłoszenia problemów i propozycje funkcji: universal.converter@outlook.com
E-mail na pytania, pomysły i języki, które chcesz dodać: universal.converter@outlook.com
Strona internetowa: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Wszelkie prawa zastrzeżone.