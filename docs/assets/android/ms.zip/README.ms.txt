UNIVERSAL CONVERTER UNTUK ANDROID - BERMULA
Versi 4.0

Universal Converter menukar imej, dokumen, video dan audio, membina PDF dan menarik jadual ke Excel. Semuanya berlaku pada telefon anda: fail anda tidak pernah dimuat naik. Aplikasi ini hanya menggunakan internet untuk mencari versi baharu, untuk memuat turun abjad pengecaman teks yang anda pilih, dan apabila anda membuka pautan. Jika anda membenarkannya, ia juga menghantar laporan ralat tanpa nama apabila sesuatu tidak kena.

APA YANG DILAKUKANNYA
Dokumen & PDF - Tukar antara PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint dan Excel. Jadikan halaman sebagai imej, dan gabungkan beberapa fail menjadi satu PDF. Di bawah PDF anda boleh menghidupkan Mampatkan PDF (masukkan saiz seperti 500 KB; teks kekal tajam) dan Tandatangan (letakkan tandatangan anda pada setiap PDF). Excel dan CSV mengeluarkan jadual daripada PDF, imbasan dan foto.
Imej - Tukar antara JPG, PNG, WEBP, BMP, GIF, TIFF dan ICO. Foto dalam HEIC dan AVIF juga boleh dibuka. Ubah saiz mengikut piksel, peratus atau saiz fail. Jadikan gambar sebagai PDF atau Word, dan baca teks dalam gambar (OCR). PDF juga boleh ditambah: setiap halaman menjadi gambar.
Video - Tukar video kepada MP4, MKV, WebM atau MOV, atau buat GIF animasi. MP4, MKV dan MOV menggunakan H.264 atau H.265 daripada pengekod perkakasan telefon anda; WebM menggunakan format terbuka VP9 dan Opus. Pilih kualiti, resolusi dan bahagian video; pangkas, putar atau buang bunyi; atau simpan bunyi sahaja sebagai MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF atau MKA. Jika terdapat beberapa video dalam senarai, ketik satu untuk memberinya tetapan sendiri, atau salin tetapan itu kepada semua.
Simpan bingkai - Dalam tab Video, pilih Simpan bingkai, pilih julat masa dan simpan satu gambar setiap beberapa saat, setiap bingkai atau satu sahaja.
Tandatangan - Tandatangani PDF dan isi borang. Buat tandatangan anda sekali - taip nama anda dan pilih gaya, lukis dengan jari atau pen, atau gunakan foto tandatangan pada kertas - kemudian biarkan aplikasi mencari baris tandatangan, atau ketik pada halaman di tempat tandatangan, parap, tarikh, teks atau tanda semak patut diletakkan. Banyak fail ditandatangani sekali gus; setiap satu disimpan sebagai nama_signed.pdf dan fail asal kekal seperti sedia ada. Ini ialah tandatangan elektronik yang kelihatan, bukan tandatangan digital berasaskan sijil.

CARA MENGGUNAKAN
1. Ketik Tambah fail, atau kongsi fail kepada Universal Converter daripada aplikasi lain.
2. Ketik fail dalam senarai: pilihannya sendiri terbuka.
3. Ketik format: pilihannya dibuka terus di bawahnya. Ketik (i) di sebelah pilihan untuk membaca apa yang dilakukannya.
4. Kembali ke senarai dan ketik Tukar: setiap fail ditukar.
Hasilnya disimpan dalam Downloads/Universal Converter. Gunakan Buka atau Kongsi untuk menggunakannya dengan segera.
Anda boleh memilih tempat lain dalam Tetapan > Lokasi simpan lalai; aplikasi bertanya sekali, selepas penukaran pertama anda.
Setiap fail mempunyai tetapannya sendiri: salin daripada fail sebelumnya yang sama format atau ke setiap fail format itu; «Fail seterusnya» membawa anda ke fail berikutnya.
Tidak perlukan sesuatu format? Sembunyikannya dalam Tetapan > Format. Fail tanpa format dipilih menerima format lalai (Tetapan > Format lalai).
Menu ☰ di kiri atas membuka Tetapan, panduan ini, Apa yang baharu & pembaikan dan Sokong; Tetapan juga ada di kanan atas.

PENUKARAN PANJANG
Anda boleh meninggalkan aplikasi semasa video ditukar: ia terus berfungsi di latar belakang. Video yang panjang atau beresolusi tinggi boleh mengambil masa dan memanaskan telefon. Jika mahu, Tetapan > Pemberitahuan memaklumkan apabila penukaran selesai. Goncang telefon dengan kuat untuk memulakan Tukar (Tetapan > Goncang untuk menukar).

PENGECAMAN TEKS (OCR)
Bahasa Inggeris dan bahasa lain yang menggunakan abjad Latin, serta bahasa Greek, sudah terbina dalam. Automatik membaca bahasa ini dan mana-mana abjad yang telah anda muat turun. Untuk membaca bahasa lain, ketik Tukar di sebelah Bahasa dan tandakan bahasa dalam fail anda: jika satu daripadanya memerlukan abjad yang belum ada pada telefon (Cyril, Arab, Cina, Jepun, Korea, Thai, Hindi, Georgia, Tamil), aplikasi menawarkan untuk memuat turunnya serta-merta, dan anda meneruskan dari tempat anda berhenti. Abjad yang dimuat turun boleh dibuang dalam Tetapan. Jika banyak teks tidak dapat dibaca, aplikasi memberitahu dan menawarkan untuk menambah abjad. Bahasa Ibrani dan Vietnam juga dibaca: setiap satu dimuat turun sekali, kali pertama anda memilihnya. Imbasan dan borang yang telah diisi menjadi teks dan jadual yang boleh disunting, disusun seperti halaman (pilihan "Halaman dengan gambar teks" dalam pilihan sesuatu PDF).

BAHASA
Kesemua 34 bahasa sudah terbina dalam: pilih satu dalam Tetapan > Bahasa aplikasi, dan aplikasi dimulakan semula dalam bahasa itu. Bahasa Arab dan Ibrani dipaparkan dari kanan ke kiri. Aplikasi ini gelap secara lalai; pilih Cerah atau Ikut telefon dalam Tetapan > Penampilan.

HAD PADA TELEFON
Fail yang sangat besar mungkin gagal pada telefon yang mempunyai sedikit memori. Video yang boleh dibuka bergantung pada telefon anda.

KEMAS KINI
Aplikasi mencari versi baharu kira-kira sekali sehari dan memberitahu anda apabila ada (matikan ini dalam Tetapan > Kemas kini). Ketik Muat turun, kemudian buka fail yang dimuat turun untuk memasangnya di atas versi ini; tetapan anda kekal. Jika anda memasang aplikasi daripada Google Play, Google Play yang mengemas kininya.

MENYAHPASANG
Tekan lama ikon aplikasi dan pilih Nyahpasang. Fail yang telah anda tukar kekal di tempat ia disimpan.

BANTUAN DAN SOKONGAN
Soalan, laporan masalah dan permintaan ciri: universal.converter@outlook.com
E-mel untuk soalan, idea dan bahasa yang anda mahu ditambah: universal.converter@outlook.com
Laman web: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Hak cipta terpelihara.
