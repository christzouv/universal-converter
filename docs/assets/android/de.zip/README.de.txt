UNIVERSAL CONVERTER FÜR ANDROID - ERSTE SCHRITTE
Version 3.1

Universal Converter wandelt Bilder, Dokumente, Videos und Audio um, erstellt und unterschreibt PDFs und holt Tabellen nach Excel. Alles geschieht auf Ihrem Handy: Ihre Dateien werden nie hochgeladen. Die App nutzt das Internet nur, um nach neuen Versionen zu suchen, um die von Ihnen gewählten Alphabete der Texterkennung herunterzuladen und wenn Sie einen Link öffnen. Wenn Sie es erlauben, sendet sie außerdem anonyme Fehlerberichte, wenn etwas schiefgeht.

WAS SIE KANN
Dokumente & PDF - Umwandeln zwischen PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint und Excel. Seiten in Bilder umwandeln und mehrere Dateien zu einem PDF zusammenfügen. PDF komprimieren: PDF hinzufügen, „PDF komprimieren“ wählen und die nötige Größe eingeben (z. B. 500 KB); die Bilder darin werden verkleinert, bis es passt, der Text bleibt scharf.
Bilder - Umwandeln zwischen JPG, PNG, WEBP, BMP, GIF, TIFF und ICO. Auch HEIC- und AVIF-Fotos lassen sich öffnen. Größe ändern in Pixeln, Prozent oder Dateigröße. Bilder in PDF oder Word umwandeln und Text in Bildern lesen (OCR). Auch PDFs lassen sich hinzufügen: Jede Seite wird zu einem Bild.
Video - Videos in MP4, MKV, WebM oder MOV umwandeln oder ein animiertes GIF erstellen. MP4, MKV und MOV nutzen H.264 oder H.265 über den Hardware-Encoder des Handys; WebM nutzt die offenen Formate VP9 und Opus. Qualität, Auflösung und Ausschnitt wählen; zuschneiden, drehen oder den Ton entfernen; oder nur den Ton als M4A, OGG oder WAV speichern.
Einzelbilder speichern - Wählen Sie im Bereich Video Einzelbilder speichern, legen Sie den Zeitraum fest und speichern Sie alle paar Sekunden ein Bild, jedes Einzelbild oder nur eines.
Nach Excel - Tabellen aus PDFs, Scans, Fotos und Word-Dateien nach Excel oder CSV holen.
Unterschreiben - PDFs unterschreiben und Formulare ausfüllen. Erstellen Sie Ihre Unterschrift einmal – Namen tippen und Stil wählen, mit dem Finger oder einem Stift zeichnen oder ein Foto davon auf Papier verwenden – und lassen Sie die App die Unterschriftslinien finden, oder tippen Sie auf die Stelle der Seite, an der Unterschrift, Initialen, Datum, Text oder Häkchen stehen sollen. Viele Dateien werden in einem Durchgang unterschrieben; jede wird als Name_signed.pdf gespeichert, das Original bleibt unverändert. Dies ist eine sichtbare elektronische Unterschrift, keine zertifikatbasierte digitale Signatur.

SO GEHT'S
1. Wählen Sie unten auf dem Bildschirm einen Bereich.
2. Tippen Sie auf Dateien hinzufügen oder teilen Sie Dateien aus einer anderen App mit Universal Converter.
3. Wählen Sie Format und Optionen. Tippen Sie auf das (i) neben einer Option, um zu lesen, was sie bewirkt.
4. Tippen Sie auf die Schaltfläche unter den Optionen.
Die Ergebnisse werden in Downloads/Universal Converter gespeichert. Mit Öffnen oder Teilen können Sie sie sofort verwenden.
Fügen Sie Dateien hinzu, die ein anderer Reiter umwandelt, nennt die App den Reiter und bringt sie mit einem Tippen dorthin.

LANGE UMWANDLUNGEN
Sie können die App verlassen, während ein Video umgewandelt wird. Eine Benachrichtigung zeigt, dass sie noch arbeitet; erlauben Sie daher Benachrichtigungen, wenn Sie gefragt werden. Lange oder hochauflösende Videos können dauern und das Handy erwärmen.

TEXTERKENNUNG (OCR)
Englisch und andere Sprachen mit lateinischem Alphabet sowie Griechisch sind eingebaut. „Automatisch“ liest diese und jedes heruntergeladene Alphabet. Für andere Sprachen tippen Sie neben Sprachen auf Ändern und haken die Sprachen Ihrer Dateien an: Braucht eine davon ein Alphabet, das noch nicht auf dem Handy ist (Kyrillisch, Arabisch, Chinesisch, Japanisch, Koreanisch, Thai, Hindi, Georgisch, Tamil), bietet die App an, es sofort herunterzuladen, und Sie machen dort weiter, wo Sie waren. Heruntergeladene Alphabete lassen sich in den Einstellungen wieder entfernen. Lässt sich viel Text nicht lesen, sagt die App das und bietet an, ein Alphabet hinzuzufügen. Hebräischer Text kann noch nicht erkannt werden.

SPRACHEN
Alle 18 Sprachen sind eingebaut: Wählen Sie eine unter Einstellungen > App-Sprache, und die App startet in dieser Sprache neu. Arabisch und Hebräisch werden von rechts nach links angezeigt. Die App ist standardmäßig dunkel; wählen Sie Hell oder Wie das Handy unter Einstellungen > Darstellung.

GRENZEN AUF DEM HANDY
Alte .doc- und .ppt-Dateien lassen sich nicht öffnen: Speichern Sie sie zuerst als .docx oder .pptx. .ods-Dateien können noch nicht gelesen und passwortgeschützte PDFs noch nicht in Bilder umgewandelt werden. Sehr große Dateien können auf Handys mit wenig Speicher fehlschlagen. Welche Videos sich öffnen lassen, hängt vom Handy ab.

UPDATES
Die App sucht etwa einmal am Tag nach einer neuen Version und meldet sich, wenn es eine gibt (abschaltbar unter Einstellungen > Updates). Tippen Sie auf Herunterladen und öffnen Sie dann die heruntergeladene Datei, um sie über diese Version zu installieren; Ihre Einstellungen bleiben erhalten. Wenn Sie die App über Google Play installiert haben, aktualisiert Google Play sie.

DEINSTALLIEREN
Halten Sie das App-Symbol gedrückt und wählen Sie Deinstallieren. Umgewandelte Dateien bleiben in Downloads/Universal Converter.

HILFE UND SUPPORT
Fragen, Fehlerberichte und Wünsche: https://github.com/christzouv/universal-converter/issues
E-Mail für Fragen, Ideen und Sprachen, die Sie sich wünschen: universal.converter@outlook.com
Website: https://christzouv.github.io/universal-converter/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Alle Rechte vorbehalten.
