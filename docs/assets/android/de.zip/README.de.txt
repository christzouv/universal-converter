UNIVERSAL CONVERTER FÜR ANDROID - ERSTE SCHRITTE
Version 4.0

Universal Converter wandelt Bilder, Dokumente, Videos und Audio um, erstellt und unterschreibt PDFs und holt Tabellen nach Excel. Alles geschieht auf Ihrem Handy: Ihre Dateien werden nie hochgeladen. Die App nutzt das Internet nur, um nach neuen Versionen zu suchen, um die von Ihnen gewählten Alphabete der Texterkennung herunterzuladen und wenn Sie einen Link öffnen. Wenn Sie es erlauben, sendet sie außerdem anonyme Fehlerberichte, wenn etwas schiefgeht.

WAS SIE KANN
Dokumente & PDF - Umwandeln zwischen PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint und Excel. Seiten in Bilder umwandeln und mehrere Dateien zu einem PDF zusammenfügen. Unter PDF lassen sich „PDF komprimieren“ (Größe eingeben, z. B. 500 KB; der Text bleibt scharf) und „Unterschreiben“ (Unterschrift auf jede PDF setzen) einschalten. Excel und CSV holen Tabellen aus PDFs, Scans und Fotos.
Bilder - Umwandeln zwischen JPG, PNG, WEBP, BMP, GIF, TIFF und ICO. Auch HEIC- und AVIF-Fotos lassen sich öffnen. Größe ändern in Pixeln, Prozent oder Dateigröße. Bilder in PDF oder Word umwandeln und Text in Bildern lesen (OCR). Auch PDFs lassen sich hinzufügen: Jede Seite wird zu einem Bild.
Video - Videos in MP4, MKV, WebM oder MOV umwandeln oder ein animiertes GIF erstellen. MP4, MKV und MOV nutzen H.264 oder H.265 über den Hardware-Encoder des Handys; WebM nutzt die offenen Formate VP9 und Opus. Qualität, Auflösung und Ausschnitt wählen; zuschneiden, drehen oder den Ton entfernen; oder nur den Ton als MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF oder MKA speichern. Bei mehreren Videos in der Liste tippen Sie auf eines, um ihm eigene Einstellungen zu geben, oder übernehmen Sie sie für alle.
Einzelbilder speichern - Wählen Sie im Bereich Video Einzelbilder speichern, legen Sie den Zeitraum fest und speichern Sie alle paar Sekunden ein Bild, jedes Einzelbild oder nur eines.
Unterschreiben - PDFs unterschreiben und Formulare ausfüllen. Erstellen Sie Ihre Unterschrift einmal – Namen tippen und Stil wählen, mit dem Finger oder einem Stift zeichnen oder ein Foto davon auf Papier verwenden – und lassen Sie die App die Unterschriftslinien finden, oder tippen Sie auf die Stelle der Seite, an der Unterschrift, Initialen, Datum, Text oder Häkchen stehen sollen. Viele Dateien werden in einem Durchgang unterschrieben; jede wird als Name_signed.pdf gespeichert, das Original bleibt unverändert. Dies ist eine sichtbare elektronische Unterschrift, keine zertifikatbasierte digitale Signatur.

SO GEHT'S
1. Tippen Sie auf Dateien hinzufügen oder teilen Sie Dateien aus einer anderen App mit Universal Converter.
2. Tippen Sie in der Liste auf eine Datei: Ihre eigenen Optionen öffnen sich.
3. Tippen Sie auf ein Format: Seine Optionen öffnen sich direkt darunter. Tippen Sie auf das (i) neben einer Option, um zu lesen, was sie bewirkt.
4. Gehen Sie zurück zur Liste und tippen Sie auf Konvertieren: Jede Datei wird umgewandelt.
Die Ergebnisse werden in Downloads/Universal Converter gespeichert. Mit Öffnen oder Teilen können Sie sie sofort verwenden.
Einen anderen Ort wählen Sie unter Einstellungen > Standard-Speicherort; die App fragt einmal, nach der ersten Konvertierung.
Jede Datei hat ihre eigenen Einstellungen: Übernehmen Sie sie von der vorherigen Datei ihres Formats oder übertragen Sie sie auf jede Datei dieses Formats; „Nächste Datei“ bringt Sie zur nächsten.
Ein Format brauchen Sie nicht? Blenden Sie es unter Einstellungen > Formate aus. Dateien ohne gewähltes Format bekommen das Standardformat (Einstellungen > Standardformate).
Das Menü ☰ oben links öffnet Einstellungen, diese Anleitung, Neuigkeiten & Korrekturen und Unterstützen; Einstellungen gibt es auch oben rechts.

LANGE UMWANDLUNGEN
Sie können die App verlassen, während ein Video konvertiert wird: Sie arbeitet im Hintergrund weiter. Lange oder hochauflösende Videos können dauern und das Telefon erwärmen. Auf Wunsch meldet Einstellungen > Benachrichtigungen, wenn eine Konvertierung fertig ist. Schüttle das Telefon kräftig, um Konvertieren zu starten (Einstellungen > Schütteln zum Konvertieren).

TEXTERKENNUNG (OCR)
Englisch und andere Sprachen mit lateinischem Alphabet sowie Griechisch sind eingebaut. „Automatisch“ liest diese und jedes heruntergeladene Alphabet. Für andere Sprachen tippen Sie neben Sprachen auf Ändern und haken die Sprachen Ihrer Dateien an: Braucht eine davon ein Alphabet, das noch nicht auf dem Handy ist (Kyrillisch, Arabisch, Chinesisch, Japanisch, Koreanisch, Thai, Hindi, Georgisch, Tamil), bietet die App an, es sofort herunterzuladen, und Sie machen dort weiter, wo Sie waren. Heruntergeladene Alphabete lassen sich in den Einstellungen wieder entfernen. Lässt sich viel Text nicht lesen, sagt die App das und bietet an, ein Alphabet hinzuzufügen. Auch Hebräisch und Vietnamesisch werden gelesen: Beides wird einmal heruntergeladen, wenn Sie es zum ersten Mal wählen. Scans und ausgefüllte Formulare werden zu bearbeitbarem Text und Tabellen, angeordnet wie auf der Seite (Option „Seiten mit Text als Bild“ in den Optionen eines PDFs).

SPRACHEN
Alle 34 Sprachen sind eingebaut: Wählen Sie eine unter Einstellungen > App-Sprache, und die App startet in dieser Sprache neu. Arabisch und Hebräisch werden von rechts nach links angezeigt. Die App ist standardmäßig dunkel; wählen Sie Hell oder Wie das Handy unter Einstellungen > Darstellung.

GRENZEN AUF DEM HANDY
Sehr große Dateien können auf Handys mit wenig Speicher fehlschlagen. Welche Videos sich öffnen lassen, hängt vom Handy ab.

UPDATES
Die App sucht etwa einmal am Tag nach einer neuen Version und meldet sich, wenn es eine gibt (abschaltbar unter Einstellungen > Updates). Tippen Sie auf Herunterladen und öffnen Sie dann die heruntergeladene Datei, um sie über diese Version zu installieren; Ihre Einstellungen bleiben erhalten. Wenn Sie die App über Google Play installiert haben, aktualisiert Google Play sie.

DEINSTALLIEREN
Halten Sie das App-Symbol gedrückt und wählen Sie Deinstallieren. Konvertierte Dateien bleiben dort, wo sie gespeichert wurden.

HILFE UND SUPPORT
Fragen, Fehlerberichte und Wünsche: universal.converter@outlook.com
E-Mail für Fragen, Ideen und Sprachen, die Sie sich wünschen: universal.converter@outlook.com
Website: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Alle Rechte vorbehalten.
