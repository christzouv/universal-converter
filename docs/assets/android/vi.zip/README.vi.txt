UNIVERSAL CONVERTER CHO ANDROID - BẮT ĐẦU
Phiên bản 4.0

Universal Converter chuyển đổi hình ảnh, tài liệu, video và âm thanh, tạo PDF và đưa bảng vào Excel. Mọi thứ diễn ra trên điện thoại của bạn: tệp của bạn không bao giờ bị tải lên. Ứng dụng chỉ dùng internet để kiểm tra phiên bản mới, tải các bảng chữ cái nhận dạng chữ bạn chọn, và khi bạn mở một liên kết. Nếu bạn cho phép, ứng dụng còn gửi báo cáo lỗi ẩn danh khi có sự cố.

ỨNG DỤNG LÀM ĐƯỢC GÌ
Tài liệu & PDF - Chuyển đổi qua lại giữa PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint và Excel. Chuyển trang thành ảnh, và gộp nhiều tệp thành một PDF. Trong PDF, bạn có thể bật Nén PDF (nhập dung lượng như 500 KB; chữ vẫn sắc nét) và Ký (đặt chữ ký lên từng PDF). Excel và CSV lấy bảng ra từ PDF, bản quét và ảnh chụp.
Hình ảnh - Chuyển đổi giữa JPG, PNG, WEBP, BMP, GIF, TIFF và ICO. Cũng mở được ảnh HEIC và AVIF. Đổi kích thước theo điểm ảnh, phần trăm hoặc dung lượng tệp. Chuyển ảnh thành PDF hoặc Word, và đọc chữ trong ảnh (OCR). Cũng có thể thêm PDF: mỗi trang thành một ảnh.
Video - Chuyển video sang MP4, MKV, WebM hoặc MOV, hoặc tạo GIF động. MP4, MKV và MOV dùng H.264 hoặc H.265 từ bộ mã hóa phần cứng của điện thoại; WebM dùng các định dạng mở VP9 và Opus. Chọn chất lượng, độ phân giải và phần video cần chuyển; cắt khung, xoay hoặc bỏ âm thanh; hoặc chỉ lưu âm thanh dưới dạng MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF hoặc MKA. Khi danh sách có nhiều video, chạm vào một video để đặt cài đặt riêng, hoặc sao chép cài đặt cho tất cả.
Lưu khung hình - Trong thẻ Video, chọn Lưu khung hình, chọn khoảng thời gian và lưu một ảnh sau mỗi vài giây, mọi khung hình hoặc chỉ một ảnh.
Ký - Ký PDF và điền biểu mẫu. Tạo chữ ký một lần - gõ tên và chọn kiểu chữ, vẽ bằng ngón tay hoặc bút, hoặc dùng ảnh chụp chữ ký trên giấy - rồi để ứng dụng tự tìm dòng chữ ký, hoặc chạm vào chỗ trên trang cần đặt chữ ký, chữ ký tắt, ngày, chữ hoặc dấu tích. Nhiều tệp được ký cùng lúc; mỗi tệp được lưu thành tên_signed.pdf và tệp gốc vẫn giữ nguyên. Đây là chữ ký điện tử có thể nhìn thấy, không phải chữ ký số dựa trên chứng thư.

CÁCH DÙNG
1. Chạm Thêm tệp, hoặc chia sẻ tệp sang Universal Converter từ ứng dụng khác.
2. Chạm vào một tệp trong danh sách: tùy chọn riêng của nó mở ra.
3. Chạm vào một định dạng: các tùy chọn của nó mở ra ngay bên dưới. Chạm vào (i) cạnh một tùy chọn để đọc tùy chọn đó làm gì.
4. Quay lại danh sách và chạm Chuyển đổi: mọi tệp đều được chuyển đổi.
Kết quả được lưu vào Downloads/Universal Converter. Dùng Mở hoặc Chia sẻ để dùng ngay.
Bạn có thể chọn nơi khác trong Cài đặt > Vị trí lưu mặc định; ứng dụng hỏi một lần, sau lần chuyển đổi đầu tiên.
Mỗi tệp có cài đặt riêng: sao chép từ tệp trước cùng định dạng hoặc cho mọi tệp định dạng đó; «Tệp tiếp theo» đưa bạn sang tệp kế.
Không cần một định dạng? Ẩn nó trong Cài đặt > Định dạng. Tệp chưa chọn định dạng nhận định dạng mặc định (Cài đặt > Định dạng mặc định).
Menu ☰ ở góc trên bên trái mở Cài đặt, hướng dẫn này, Có gì mới & bản sửa lỗi và Ủng hộ; Cài đặt cũng có ở góc trên bên phải.

CHUYỂN ĐỔI LÂU
Bạn có thể rời ứng dụng khi video đang chuyển đổi: ứng dụng vẫn chạy trong nền. Video dài hoặc độ phân giải cao có thể mất thời gian và làm nóng điện thoại. Nếu muốn, Cài đặt > Thông báo sẽ báo cho bạn khi chuyển đổi xong. Lắc mạnh điện thoại để bắt đầu Chuyển đổi (Cài đặt > Lắc để chuyển đổi).

NHẬN DẠNG CHỮ (OCR)
Tiếng Anh và các ngôn ngữ dùng chữ Latinh khác (như tiếng Indonesia và tiếng Thổ Nhĩ Kỳ), cùng tiếng Hy Lạp, đã có sẵn. Tự động đọc các ngôn ngữ này và mọi bảng chữ cái bạn đã tải. Để đọc ngôn ngữ khác, chạm Thay đổi cạnh mục Ngôn ngữ và đánh dấu các ngôn ngữ có trong tệp: nếu một ngôn ngữ cần bảng chữ cái chưa có trên điện thoại (Kirin, Ả Rập, Trung Quốc, Nhật, Hàn, Thái, Hindi, Gruzia, Tamil), ứng dụng đề nghị tải ngay, và bạn tiếp tục từ chỗ đang làm. Có thể xóa các bảng chữ cái đã tải trong Cài đặt. Nếu phần lớn chữ không đọc được, ứng dụng sẽ báo và đề nghị thêm bảng chữ cái. Tiếng Do Thái và tiếng Việt cũng được đọc: mỗi ngôn ngữ được tải một lần, vào lần đầu bạn chọn. Bản quét và biểu mẫu đã điền thành chữ và bảng chỉnh sửa được, bố cục giống trang gốc (tùy chọn "Trang có chữ ở dạng hình ảnh" trong tùy chọn của một PDF).

NGÔN NGỮ
Cả 34 ngôn ngữ đều có sẵn: chọn một ngôn ngữ trong Cài đặt > Ngôn ngữ ứng dụng, và ứng dụng khởi động lại bằng ngôn ngữ đó. Tiếng Ả Rập và tiếng Do Thái hiển thị từ phải sang trái. Ứng dụng mặc định dùng giao diện tối; chọn Sáng hoặc Theo điện thoại trong Cài đặt > Giao diện.

GIỚI HẠN TRÊN ĐIỆN THOẠI
Tệp rất lớn có thể bị lỗi trên điện thoại ít bộ nhớ. Mở được video nào tùy thuộc vào điện thoại của bạn.

CẬP NHẬT
Ứng dụng kiểm tra phiên bản mới khoảng mỗi ngày một lần và báo cho bạn khi có (tắt trong Cài đặt > Cập nhật). Chạm Tải về, rồi mở tệp đã tải để cài đè lên phiên bản này; cài đặt của bạn vẫn được giữ. Nếu bạn cài ứng dụng từ Google Play, Google Play sẽ cập nhật ứng dụng.

GỠ CÀI ĐẶT
Nhấn giữ biểu tượng ứng dụng và chọn Gỡ cài đặt. Các tệp bạn đã chuyển đổi vẫn ở nơi chúng được lưu.

TRỢ GIÚP VÀ HỖ TRỢ
Câu hỏi, báo lỗi và đề xuất tính năng: universal.converter@outlook.com
Email cho câu hỏi, ý tưởng và ngôn ngữ bạn muốn được thêm: universal.converter@outlook.com
Trang web: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Bảo lưu mọi quyền.
