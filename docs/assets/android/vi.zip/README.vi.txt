UNIVERSAL CONVERTER CHO ANDROID - BẮT ĐẦU
Phiên bản 3.3

Universal Converter chuyển đổi hình ảnh, tài liệu, video và âm thanh, tạo PDF và đưa bảng vào Excel. Mọi thứ diễn ra trên điện thoại của bạn: tệp của bạn không bao giờ bị tải lên. Ứng dụng chỉ dùng internet để kiểm tra phiên bản mới, tải các bảng chữ cái nhận dạng chữ bạn chọn, và khi bạn mở một liên kết. Nếu bạn cho phép, ứng dụng còn gửi báo cáo lỗi ẩn danh khi có sự cố.

ỨNG DỤNG LÀM ĐƯỢC GÌ
Tài liệu & PDF - Chuyển đổi qua lại giữa PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint và Excel. Chuyển trang thành ảnh, và gộp nhiều tệp thành một PDF. Nén PDF: thêm một PDF, chọn Nén PDF và nhập dung lượng bạn cần (vd. 500 KB); ảnh bên trong được thu nhỏ đến khi vừa và chữ vẫn sắc nét.
Hình ảnh - Chuyển đổi giữa JPG, PNG, WEBP, BMP, GIF, TIFF và ICO. Cũng mở được ảnh HEIC và AVIF. Đổi kích thước theo điểm ảnh, phần trăm hoặc dung lượng tệp. Chuyển ảnh thành PDF hoặc Word, và đọc chữ trong ảnh (OCR). Cũng có thể thêm PDF: mỗi trang thành một ảnh.
Video - Chuyển video sang MP4, MKV, WebM hoặc MOV, hoặc tạo GIF động. MP4, MKV và MOV dùng H.264 hoặc H.265 từ bộ mã hóa phần cứng của điện thoại; WebM dùng các định dạng mở VP9 và Opus. Chọn chất lượng, độ phân giải và phần video cần chuyển; cắt khung, xoay hoặc bỏ âm thanh; hoặc chỉ lưu âm thanh dưới dạng M4A, OGG hoặc WAV.
Lưu khung hình - Trong thẻ Video, chọn Lưu khung hình, chọn khoảng thời gian và lưu một ảnh sau mỗi vài giây, mọi khung hình hoặc chỉ một ảnh.
Sang Excel - Lấy bảng từ PDF, bản quét, ảnh chụp và tệp Word sang Excel hoặc CSV.
Ký - Ký PDF và điền biểu mẫu. Tạo chữ ký một lần - gõ tên và chọn kiểu chữ, vẽ bằng ngón tay hoặc bút, hoặc dùng ảnh chụp chữ ký trên giấy - rồi để ứng dụng tự tìm dòng chữ ký, hoặc chạm vào chỗ trên trang cần đặt chữ ký, chữ ký tắt, ngày, chữ hoặc dấu tích. Nhiều tệp được ký cùng lúc; mỗi tệp được lưu thành tên_signed.pdf và tệp gốc vẫn giữ nguyên. Đây là chữ ký điện tử có thể nhìn thấy, không phải chữ ký số dựa trên chứng thư.

CÁCH DÙNG
1. Chọn một thẻ ở cuối màn hình.
2. Chạm Thêm tệp, hoặc chia sẻ tệp sang Universal Converter từ ứng dụng khác.
3. Chạm vào một định dạng: các tùy chọn của nó mở ra ngay bên dưới. Chạm vào (i) cạnh một tùy chọn để đọc tùy chọn đó làm gì.
4. Chạm vào nút ở dưới các tùy chọn.
Kết quả được lưu vào Downloads/Universal Converter. Dùng Mở hoặc Chia sẻ để dùng ngay.
Nếu bạn thêm tệp do thẻ khác chuyển đổi, ứng dụng sẽ cho biết thẻ nào và chuyển chúng sang đó chỉ với một lần chạm.

CHUYỂN ĐỔI LÂU
Bạn có thể rời ứng dụng trong khi video đang được chuyển đổi. Một thông báo cho biết ứng dụng vẫn đang làm việc, vì vậy hãy cho phép thông báo khi được hỏi. Video dài hoặc độ phân giải cao có thể mất thời gian và làm điện thoại nóng lên.

NHẬN DẠNG CHỮ (OCR)
Tiếng Anh và các ngôn ngữ dùng chữ Latinh khác (như tiếng Indonesia và tiếng Thổ Nhĩ Kỳ), cùng tiếng Hy Lạp, đã có sẵn. Tự động đọc các ngôn ngữ này và mọi bảng chữ cái bạn đã tải. Để đọc ngôn ngữ khác, chạm Thay đổi cạnh mục Ngôn ngữ và đánh dấu các ngôn ngữ có trong tệp: nếu một ngôn ngữ cần bảng chữ cái chưa có trên điện thoại (Kirin, Ả Rập, Trung Quốc, Nhật, Hàn, Thái, Hindi, Gruzia, Tamil), ứng dụng đề nghị tải ngay, và bạn tiếp tục từ chỗ đang làm. Có thể xóa các bảng chữ cái đã tải trong Cài đặt. Nếu phần lớn chữ không đọc được, ứng dụng sẽ báo và đề nghị thêm bảng chữ cái. Tiếng Do Thái và tiếng Việt cũng được đọc: mỗi ngôn ngữ được tải một lần, vào lần đầu bạn chọn. Bản quét và biểu mẫu đã điền thành chữ và bảng chỉnh sửa được, bố cục giống trang gốc (tùy chọn "Trang có chữ ở dạng hình ảnh" trong thẻ Tài liệu & PDF và Sang Excel).

NGÔN NGỮ
Cả 22 ngôn ngữ đều có sẵn: chọn một ngôn ngữ trong Cài đặt > Ngôn ngữ ứng dụng, và ứng dụng khởi động lại bằng ngôn ngữ đó. Tiếng Ả Rập và tiếng Do Thái hiển thị từ phải sang trái. Ứng dụng mặc định dùng giao diện tối; chọn Sáng hoặc Theo điện thoại trong Cài đặt > Giao diện.

GIỚI HẠN TRÊN ĐIỆN THOẠI
Không mở được tệp .doc và .ppt cũ: hãy lưu chúng thành .docx hoặc .pptx trước. Chưa đọc được tệp .ods, và chưa chuyển được PDF có mật khẩu thành ảnh. Tệp rất lớn có thể bị lỗi trên điện thoại ít bộ nhớ. Mở được video nào tùy thuộc vào điện thoại của bạn.

CẬP NHẬT
Ứng dụng kiểm tra phiên bản mới khoảng mỗi ngày một lần và báo cho bạn khi có (tắt trong Cài đặt > Cập nhật). Chạm Tải về, rồi mở tệp đã tải để cài đè lên phiên bản này; cài đặt của bạn vẫn được giữ. Nếu bạn cài ứng dụng từ Google Play, Google Play sẽ cập nhật ứng dụng.

GỠ CÀI ĐẶT
Nhấn giữ biểu tượng ứng dụng và chọn Gỡ cài đặt. Các tệp bạn đã chuyển đổi vẫn nằm trong Downloads/Universal Converter.

TRỢ GIÚP VÀ HỖ TRỢ
Câu hỏi, báo lỗi và đề xuất tính năng: https://github.com/christzouv/universal-converter/issues
Email cho câu hỏi, ý tưởng và ngôn ngữ bạn muốn được thêm: universal.converter@outlook.com
Trang web: https://christzouv.github.io/universal-converter/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Bảo lưu mọi quyền.
