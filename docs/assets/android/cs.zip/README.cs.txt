UNIVERSAL CONVERTER PRO ANDROID - ZAČÍNÁME
Verze 4.0

Universal Converter převádí obrázky, dokumenty, videa a zvuk, vytváří PDF a přenáší tabulky do Excelu. Vše probíhá ve vašem telefonu: vaše soubory se nikam nenahrávají. Aplikace používá internet jen ke hledání nových verzí, ke stažení abeced pro rozpoznávání textu, které si zvolíte, a když otevřete odkaz. Pokud to povolíte, posílá také anonymní hlášení o chybách, když se něco pokazí.

CO UMÍ
Dokumenty a PDF - Převod mezi PDF, Wordem, ODT, RTF, TXT, Markdownem, HTML, EPUB, PowerPointem a Excelem. Stránky na obrázky a spojení více souborů do jednoho PDF. V části PDF můžete zapnout Komprimovat PDF (zadejte velikost, třeba 500 KB; text zůstane ostrý) a Podepsat (umístit podpis na každé PDF). Excel a CSV vytáhnou tabulky z PDF, skenů a fotek.
Obrázky - Převod mezi JPG, PNG, WEBP, BMP, GIF, TIFF a ICO. Otevřít lze i fotky v HEIC a AVIF. Změna velikosti v pixelech, procentech nebo podle velikosti souboru. Obrázky do PDF nebo Wordu a čtení textu z obrázků (OCR). Přidat lze i PDF: z každé stránky se stane obrázek.
Video - Převádějte videa do MP4, MKV, WebM nebo MOV nebo vytvořte animovaný GIF. MP4, MKV a MOV používají H.264 nebo H.265 z hardwarového kodéru telefonu; WebM používá otevřené formáty VP9 a Opus. Zvolte kvalitu, rozlišení a část videa; ořízněte, otočte nebo odstraňte zvuk; nebo uložte jen zvuk jako MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF či MKA. Je-li v seznamu více videí, klepněte na jedno a dejte mu vlastní nastavení, nebo je zkopírujte na všechna.
Uložit snímky - Na kartě Video zvolte Uložit snímky, nastavte časový úsek a ukládejte obrázek každých pár sekund, každý snímek nebo jen jeden.
Podepsat - Podepisujte PDF a vyplňujte formuláře. Vytvořte si podpis jednou - napište jméno a zvolte styl, nakreslete ho prstem nebo perem, nebo použijte jeho fotku na papíře - a nechte aplikaci najít řádky pro podpis, nebo klepněte na stránku tam, kde má být podpis, iniciály, datum, text nebo zaškrtnutí. Mnoho souborů se podepíše najednou; každý se uloží jako název_signed.pdf a originál zůstane, jak byl. Jde o viditelný elektronický podpis, ne o digitální podpis založený na certifikátu.

JAK HO POUŽÍVAT
1. Klepněte na Přidat soubory, nebo soubory sdílejte do Universal Converteru z jiné aplikace.
2. Klepněte na soubor v seznamu: otevřou se jeho vlastní možnosti.
3. Klepněte na formát: jeho možnosti se otevřou hned pod ním. Klepnutím na (i) vedle možnosti si přečtete, co dělá.
4. Vraťte se k seznamu a klepněte na Převést: převede se každý soubor.
Výsledky se ukládají do Downloads/Universal Converter. Tlačítky Otevřít a Sdílet je můžete hned použít.
Jiné místo zvolíte v Nastavení > Výchozí umístění pro ukládání; aplikace se zeptá jednou, po prvním převodu.
Každý soubor má vlastní nastavení: zkopírujte ho z předchozího souboru stejného formátu nebo do každého souboru toho formátu; „Další soubor“ vás posune na další.
Nepotřebujete nějaký formát? Skryjte ho v Nastavení > Formáty. Soubory bez zvoleného formátu dostanou výchozí (Nastavení > Výchozí formáty).
Nabídka ☰ vlevo nahoře otevírá Nastavení, tuto příručku, Co je nového a opraveno a Podpořit; Nastavení je i vpravo nahoře.

DLOUHÉ PŘEVODY
Během převodu videa můžete aplikaci opustit: pracuje dál na pozadí. Dlouhá videa nebo videa ve vysokém rozlišení mohou chvíli trvat a zahřát telefon. Pokud chcete, Nastavení > Oznámení vám dá vědět, až bude převod hotový. Pořádně zatřeste telefonem a spustí se Převést (Nastavení > Zatřesením převést).

ROZPOZNÁVÁNÍ TEXTU (OCR)
Angličtina a další jazyky s latinkou a také řečtina jsou vestavěné. Automaticky čte tyto jazyky a každou abecedu, kterou jste stáhli. Chcete-li číst jiné jazyky, klepněte na Změnit vedle Jazyky a zaškrtněte jazyky svých souborů: pokud některý potřebuje abecedu, která v telefonu ještě není (cyrilice, arabština, čínština, japonština, korejština, thajština, hindština, gruzínština, tamilština), aplikace ji nabídne stáhnout hned a vy pokračujete tam, kde jste byli. Stažené abecedy lze odebrat v Nastavení. Pokud nelze přečíst velkou část textu, aplikace to oznámí a nabídne přidání abecedy. Čte se i hebrejština a vietnamština: každá se stáhne jednou, když ji poprvé zvolíte. Ze skenů a vyplněných formulářů se stane upravitelný text a tabulky rozvržené jako stránka (možnost „Stránky s obrázky textu“ v možnostech PDF).

JAZYKY
Všech 34 jazyků je vestavěných: jeden zvolte v Nastavení > Jazyk aplikace a aplikace se v něm znovu spustí. Arabština a hebrejština se zobrazují zprava doleva. Aplikace je ve výchozím stavu tmavá; v Nastavení > Vzhled zvolte Světlý nebo Podle telefonu.

OMEZENÍ V TELEFONU
Velmi velké soubory se na telefonech s malou pamětí nemusí podařit. Která videa lze otevřít, závisí na vašem telefonu.

AKTUALIZACE
Aplikace zhruba jednou denně hledá novou verzi a dá vědět, když nějaká je (vypnete to v Nastavení > Aktualizace). Klepněte na Stáhnout a pak otevřete stažený soubor, aby se nainstaloval přes tuto verzi; vaše nastavení zůstanou. Pokud jste aplikaci nainstalovali z Google Play, aktualizuje ji Google Play.

ODINSTALACE
Podržte ikonu aplikace a zvolte Odinstalovat. Převedené soubory zůstanou tam, kam se uložily.

NÁPOVĚDA A PODPORA
Dotazy, hlášení problémů a návrhy funkcí: universal.converter@outlook.com
E-mail pro dotazy, nápady a jazyky, které byste chtěli přidat: universal.converter@outlook.com
Web: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Všechna práva vyhrazena.
