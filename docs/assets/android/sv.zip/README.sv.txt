UNIVERSAL CONVERTER FÖR ANDROID - KOM IGÅNG
Version 4.0

Universal Converter konverterar bilder, dokument, videor och ljud, skapar PDF-filer och hämtar tabeller till Excel. Allt sker på din telefon: dina filer laddas aldrig upp. Appen använder internet bara för att söka efter nya versioner, för att hämta de alfabet för textigenkänning som du väljer och när du öppnar en länk. Om du tillåter det skickar den också anonyma felrapporter när något går fel.

VAD DEN GÖR
Dokument och PDF - Konvertera mellan PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint och Excel. Gör sidor till bilder och slå ihop flera filer till en PDF. Under PDF kan du slå på Komprimera PDF (ange en storlek som 500 KB; texten förblir skarp) och Signera (placera din signatur på varje PDF). Excel och CSV hämtar tabeller ur PDF-filer, skanningar och foton.
Bilder - Konvertera mellan JPG, PNG, WEBP, BMP, GIF, TIFF och ICO. Foton i HEIC och AVIF kan också öppnas. Ändra storlek i pixlar, procent eller filstorlek. Gör bilder till PDF eller Word och läs texten i bilder (OCR). PDF-filer kan också läggas till: varje sida blir en bild.
Video - Konvertera videor till MP4, MKV, WebM eller MOV, eller gör en animerad GIF. MP4, MKV och MOV använder H.264 eller H.265 från telefonens hårdvarukodare; WebM använder de öppna formaten VP9 och Opus. Välj kvalitet, upplösning och del av videon; beskär, rotera eller ta bort ljudet; eller spara bara ljudet som MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF eller MKA. Med flera videor i listan trycker du på en för att ge den egna inställningar, eller kopierar dem till alla.
Spara bildrutor - Välj Spara bildrutor på fliken Video, välj tidsintervallet och spara en bild med några sekunders mellanrum, varje bildruta eller bara en.
Signera - Signera PDF-filer och fyll i formulär. Gör din signatur en gång - skriv ditt namn och välj en stil, rita den med fingret eller en penna, eller använd ett foto av den på papper - och låt sedan appen hitta signaturraderna, eller tryck på sidan där signatur, initialer, datum, text eller bockar ska stå. Många filer signeras på en gång; var och en sparas som namn_signed.pdf och originalet förblir som det var. Detta är en synlig elektronisk signatur, inte en certifikatbaserad digital signatur.

SÅ HÄR ANVÄNDER DU DEN
1. Tryck på Lägg till filer, eller dela filer till Universal Converter från en annan app.
2. Tryck på en fil i listan: dess egna alternativ öppnas.
3. Tryck på ett format: dess alternativ öppnas direkt under det. Tryck på (i) bredvid ett alternativ för att läsa vad det gör.
4. Gå tillbaka till listan och tryck på Konvertera: varje fil konverteras.
Resultaten sparas i Downloads/Universal Converter. Använd Öppna eller Dela för att använda dem direkt.
Du kan välja en annan plats i Inställningar > Standardplats för att spara; appen frågar en gång, efter din första konvertering.
Varje fil har sina egna inställningar: kopiera dem från föregående fil i samma format eller till varje fil i det formatet; ”Nästa fil” tar dig vidare till nästa.
Behöver du inte ett format? Dölj det i Inställningar > Format. Filer utan valt format får standardformatet (Inställningar > Standardformat).
Menyn ☰ uppe till vänster öppnar Inställningar, den här guiden, Nyheter & rättningar och Stöd; Inställningar finns även uppe till höger.

LÅNGA KONVERTERINGAR
Du kan lämna appen medan en video konverteras: den fortsätter arbeta i bakgrunden. Långa videor eller videor med hög upplösning kan ta en stund och värma upp telefonen. Om du vill meddelar Inställningar > Aviseringar när en konvertering är klar. Skaka telefonen ordentligt för att starta Konvertera (Inställningar > Skaka för att konvertera).

TEXTIGENKÄNNING (OCR)
Engelska och andra språk med latinskt alfabet, samt grekiska, är inbyggda. Automatiskt läser dessa och alla alfabet du har hämtat. För att läsa andra språk trycker du på Ändra bredvid Språk och bockar för språken i dina filer: om ett av dem behöver ett alfabet som inte finns på telefonen än (kyrilliska, arabiska, kinesiska, japanska, koreanska, thailändska, hindi, georgiska, tamil) erbjuder appen att hämta det direkt, och du fortsätter där du var. Hämtade alfabet kan tas bort i Inställningar. Om mycket av texten inte kan läsas säger appen det och erbjuder att lägga till ett alfabet. Hebreiska och vietnamesiska läses också: vart och ett hämtas en gång, första gången du väljer det. Skanningar och ifyllda formulär blir redigerbar text och tabeller, upplagda som sidan (alternativet "Sidor med bilder av text" i en PDF-fils alternativ).

SPRÅK
Alla 34 språk är inbyggda: välj ett i Inställningar > Appens språk, så startar appen om på det språket. Arabiska och hebreiska visas från höger till vänster. Appen är mörk som standard; välj Ljust eller Följ telefonen i Inställningar > Utseende.

BEGRÄNSNINGAR PÅ EN TELEFON
Mycket stora filer kan misslyckas på telefoner med lite minne. Vilka videor som kan öppnas beror på din telefon.

UPPDATERINGAR
Appen söker efter en ny version ungefär en gång om dagen och säger till när det finns en (stäng av det i Inställningar > Uppdateringar). Tryck på Hämta och öppna sedan den hämtade filen för att installera den över den här; dina inställningar finns kvar. Om du installerade appen från Google Play uppdaterar Google Play den i stället.

AVINSTALLATION
Håll ned appens ikon och välj Avinstallera. Filer du har konverterat ligger kvar där de sparades.

HJÄLP OCH SUPPORT
Frågor, problemrapporter och önskemål om funktioner: universal.converter@outlook.com
E-post för frågor, idéer och språk du vill ha: universal.converter@outlook.com
Webbplats: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Med ensamrätt.
