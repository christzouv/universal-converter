UNIVERSAL CONVERTER VIR ANDROID - BEGIN HIER
Weergawe 4.0

Universal Converter skakel prente, dokumente, video's en klank om, maak en onderteken PDF's en haal tabelle na Excel. Alles gebeur op jou foon: jou lêers word nooit opgelaai nie. Die program gebruik die internet net om vir nuwe weergawes te kyk, om die teksherkenning-alfabette wat jy kies af te laai, en wanneer jy 'n skakel oopmaak. As jy dit toelaat, stuur dit ook anonieme foutverslae wanneer iets verkeerd loop.

WAT DIT DOEN
Dokumente & PDF - Skakel om tussen PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint en Excel. Maak bladsye prente, en voeg verskeie lêers in een PDF saam. Onder PDF kan jy Komprimeer PDF (tik 'n grootte soos 500 KB; die teks bly skerp) en Teken (plaas jou handtekening op elke PDF) aanskakel. Excel en CSV haal tabelle uit PDF's, skanderings en foto's.
Prente - Skakel om tussen JPG, PNG, WEBP, BMP, GIF, TIFF en ICO. Foto's in HEIC en AVIF kan ook oopgemaak word. Verander die grootte volgens pieksels, persentasie of lêergrootte. Maak prente PDF of Word, en lees die teks in prente (OCR). PDF's kan ook bygevoeg word: elke bladsy word 'n prent.
Video - Skakel video's om na MP4, MKV, WebM of MOV, of maak 'n geanimeerde GIF. MP4, MKV en MOV gebruik H.264 of H.265 van jou foon se hardeware-enkodeerder; WebM gebruik die oop VP9- en Opus-formate. Kies die kwaliteit, resolusie en deel van die video; sny uit, draai of verwyder die klank; of stoor net die klank as MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF of MKA. Met verskeie video's in die lys, tik een om dit sy eie instellings te gee, of kopieer hulle na almal.
Stoor rame - Kies Stoor rame in die Video-oortjie, kies die tydspan en stoor elke paar sekondes 'n prent, elke raam of net een.
Onderteken - Onderteken PDF's en vul vorms in. Maak jou handtekening een keer – tik jou naam en kies 'n styl, teken dit met jou vinger of 'n pen, of gebruik 'n foto daarvan op papier – en laat die program dan die handtekeningreëls vind, of tik op die bladsy waar die handtekening, voorletters, datum, teks of regmerkies moet kom. Baie lêers word in een slag onderteken; elkeen word as naam_signed.pdf gestoor en die oorspronklike bly soos dit was. Dit is 'n sigbare elektroniese handtekening, nie 'n sertifikaatgebaseerde digitale handtekening nie.

HOE OM DIT TE GEBRUIK
1. Tik Voeg lêers by, of deel lêers na Universal Converter vanuit 'n ander program.
2. Tik op 'n lêer in die lys: sy eie opsies maak oop.
3. Tik op 'n formaat: sy opsies gaan reg daaronder oop. Tik die (i) langs 'n opsie om te lees wat dit doen.
4. Gaan terug na die lys en tik op Skakel om: elke lêer word omgeskakel.
Resultate word in Downloads/Universal Converter gestoor. Gebruik Maak oop of Deel om hulle dadelik te gebruik.
Jy kan 'n ander plek kies in Instellings > Verstek-stoorplek; die app vra een keer, ná jou eerste omskakeling.
Elke lêer het sy eie instellings: kopieer dit van die vorige lêer van sy formaat of na elke lêer van daardie formaat; 'Volgende lêer' neem jou na die volgende een.
Het jy 'n formaat nie nodig nie? Versteek dit in Instellings > Formate. Lêers sonder gekose formaat kry die verstekformaat (Instellings > Verstekformate).
Die ☰-kieslys links bo maak Instellings, hierdie gids, Wat's nuut & regstellings en Ondersteun oop; Instellings is ook regs bo.

LANG OMSKAKELINGS
Jy kan die app verlaat terwyl 'n video omgeskakel word: dit werk in die agtergrond voort. Lang video's of video's met 'n hoë resolusie kan 'n ruk neem en die foon warm maak. As jy wil, laat Instellings > Kennisgewings jou weet wanneer 'n omskakeling klaar is. Skud die foon ferm om Skakel om te begin (Instellings > Skud om om te skakel).

TEKSHERKENNING (OCR)
Engels en ander tale in die Latynse alfabet, en Grieks, is ingebou. Outomaties lees hierdie en enige alfabet wat jy afgelaai het. Om ander tale te lees, tik Verander langs Tale en merk die tale in jou lêers: as een 'n alfabet nodig het wat nog nie op die foon is nie (Cyrillies, Arabies, Chinees, Japannees, Koreaans, Thai, Hindi, Georgies, Tamil), bied die program aan om dit dadelik af te laai, en jy gaan voort waar jy was. Afgelaaide alfabette kan in Instellings verwyder word. As baie van die teks nie gelees kan word nie, sê die program so en bied aan om 'n alfabet by te voeg. Hebreeus en Viëtnamees word ook gelees: elkeen word een keer afgelaai, die eerste keer dat jy dit kies. Skanderings en ingevulde vorms word teks en tabelle wat jy kan wysig, uitgelê soos die bladsy (opsie "Bladsye met teks as prent" in 'n PDF se opsies).

TALE
Al 34 tale is ingebou: kies een in Instellings > Programtaal, en die program begin weer in daardie taal. Arabies en Hebreeus word van regs na links gewys. Die program is by verstek donker; kies Lig of Volg die foon in Instellings > Voorkoms.

BEPERKINGS OP 'N FOON
Baie groot lêers kan misluk op fone met min geheue. Watter video's oopgemaak kan word, hang van jou foon af.

BYWERKINGS
Die program kyk ongeveer een keer per dag vir 'n nuwe weergawe en sê vir jou wanneer daar een is (skakel dit af in Instellings > Bywerkings). Tik Laai af, maak dan die afgelaaide lêer oop om dit oor hierdie een te installeer; jou instellings bly. As jy die program van Google Play af geïnstalleer het, werk Google Play dit eerder by.

DEÏNSTALLEER
Hou die app se ikoon in en kies Deïnstalleer. Lêers wat jy omgeskakel het, bly waar hulle gestoor is.

HULP EN ONDERSTEUNING
Vrae, probleemverslae en versoeke vir funksies: universal.converter@outlook.com
E-pos vir vrae, idees en tale wat jy bygevoeg wil hê: universal.converter@outlook.com
Webwerf: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Alle regte voorbehou.