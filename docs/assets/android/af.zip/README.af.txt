UNIVERSAL CONVERTER VIR ANDROID - BEGIN HIER
Weergawe 3.2

Universal Converter skakel prente, dokumente, video's en klank om, maak en onderteken PDF's en haal tabelle na Excel. Alles gebeur op jou foon: jou lêers word nooit opgelaai nie. Die program gebruik die internet net om vir nuwe weergawes te kyk, om die teksherkenning-alfabette wat jy kies af te laai, en wanneer jy 'n skakel oopmaak. As jy dit toelaat, stuur dit ook anonieme foutverslae wanneer iets verkeerd loop.

WAT DIT DOEN
Dokumente & PDF - Skakel om tussen PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint en Excel. Maak bladsye prente, en voeg verskeie lêers in een PDF saam. Komprimeer PDF: voeg 'n PDF by, kies Komprimeer PDF en tik die grootte wat jy nodig het (bv. 500 KB); die prente binne-in word kleiner gemaak totdat dit pas, en teks bly skerp.
Prente - Skakel om tussen JPG, PNG, WEBP, BMP, GIF, TIFF en ICO. Foto's in HEIC en AVIF kan ook oopgemaak word. Verander die grootte volgens pieksels, persentasie of lêergrootte. Maak prente PDF of Word, en lees die teks in prente (OCR). PDF's kan ook bygevoeg word: elke bladsy word 'n prent.
Video - Skakel video's om na MP4, MKV, WebM of MOV, of maak 'n geanimeerde GIF. MP4, MKV en MOV gebruik H.264 of H.265 van jou foon se hardeware-enkodeerder; WebM gebruik die oop VP9- en Opus-formate. Kies die kwaliteit, resolusie en deel van die video; sny uit, draai of verwyder die klank; of stoor net die klank as M4A, OGG of WAV.
Stoor rame - Kies Stoor rame in die Video-oortjie, kies die tydspan en stoor elke paar sekondes 'n prent, elke raam of net een.
Na Excel - Haal tabelle uit PDF's, skanderings, foto's en Word-lêers na Excel of CSV.
Onderteken - Onderteken PDF's en vul vorms in. Maak jou handtekening een keer – tik jou naam en kies 'n styl, teken dit met jou vinger of 'n pen, of gebruik 'n foto daarvan op papier – en laat die program dan die handtekeningreëls vind, of tik op die bladsy waar die handtekening, voorletters, datum, teks of regmerkies moet kom. Baie lêers word in een slag onderteken; elkeen word as naam_signed.pdf gestoor en die oorspronklike bly soos dit was. Dit is 'n sigbare elektroniese handtekening, nie 'n sertifikaatgebaseerde digitale handtekening nie.

HOE OM DIT TE GEBRUIK
1. Kies 'n oortjie onderaan die skerm.
2. Tik Voeg lêers by, of deel lêers na Universal Converter vanuit 'n ander program.
3. Kies die formaat en opsies. Tik die (i) langs 'n opsie om te lees wat dit doen.
4. Tik die knoppie onder die opsies.
Resultate word in Downloads/Universal Converter gestoor. Gebruik Maak oop of Deel om hulle dadelik te gebruik.
As jy lêers byvoeg wat 'n ander oortjie omskakel, sê die program watter oortjie en neem hulle met een tik soontoe.

LANG OMSKAKELINGS
Jy kan die program verlaat terwyl 'n video omgeskakel word. 'n Kennisgewing wys dat dit nog werk, so laat asseblief kennisgewings toe wanneer gevra. Lang of hoë-resolusie video's kan 'n ruk neem en die foon warm maak.

TEKSHERKENNING (OCR)
Engels en ander tale in die Latynse alfabet, en Grieks, is ingebou. Outomaties lees hierdie en enige alfabet wat jy afgelaai het. Om ander tale te lees, tik Verander langs Tale en merk die tale in jou lêers: as een 'n alfabet nodig het wat nog nie op die foon is nie (Cyrillies, Arabies, Chinees, Japannees, Koreaans, Thai, Hindi, Georgies, Tamil), bied die program aan om dit dadelik af te laai, en jy gaan voort waar jy was. Afgelaaide alfabette kan in Instellings verwyder word. As baie van die teks nie gelees kan word nie, sê die program so en bied aan om 'n alfabet by te voeg. Hebreeuse teks kan nog nie herken word nie.

TALE
Al 18 tale is ingebou: kies een in Instellings > Programtaal, en die program begin weer in daardie taal. Arabies en Hebreeus word van regs na links gewys. Die program is by verstek donker; kies Lig of Volg die foon in Instellings > Voorkoms.

BEPERKINGS OP 'N FOON
Ou .doc- en .ppt-lêers kan nie oopgemaak word nie: stoor hulle eers as .docx of .pptx. .ods-lêers kan nog nie gelees word nie, en wagwoordbeskermde PDF's kan nog nie prente word nie. Baie groot lêers kan misluk op fone met min geheue. Watter video's oopgemaak kan word, hang van jou foon af.

BYWERKINGS
Die program kyk ongeveer een keer per dag vir 'n nuwe weergawe en sê vir jou wanneer daar een is (skakel dit af in Instellings > Bywerkings). Tik Laai af, maak dan die afgelaaide lêer oop om dit oor hierdie een te installeer; jou instellings bly. As jy die program van Google Play af geïnstalleer het, werk Google Play dit eerder by.

DEÏNSTALLEER
Hou die program se ikoon in en kies Deïnstalleer. Lêers wat jy omgeskakel het, bly in Downloads/Universal Converter.

HULP EN ONDERSTEUNING
Vrae, probleemverslae en versoeke vir funksies: https://github.com/christzouv/universal-converter/issues
E-pos vir vrae, idees en tale wat jy bygevoeg wil hê: universal.converter@outlook.com
Webwerf: https://christzouv.github.io/universal-converter/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Alle regte voorbehou.