UNIVERSAL CONVERTER POUR ANDROID - BIEN DÉMARRER
Version 3.0

Universal Converter convertit images, documents, vidéos et audio, crée des PDF et extrait des tableaux vers Excel. Tout se passe sur votre téléphone : vos fichiers ne sont jamais envoyés en ligne. L'application n'utilise internet que pour rechercher de nouvelles versions, pour télécharger les langues que vous choisissez et lorsque vous ouvrez un lien. Si vous l'autorisez, elle envoie aussi des rapports d'erreur anonymes en cas de problème.

CE QU'IL FAIT
Documents et PDF - Convertit entre PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint et Excel. Transforme des pages en images et réunit plusieurs fichiers en un PDF. Compresser le PDF : ajoutez un PDF, choisissez Compresser le PDF et indiquez la taille voulue (par ex. 500 KB) ; les images à l'intérieur sont réduites jusqu'à ce qu'il tienne et le texte reste net.
Images - Convertit entre JPG, PNG, WEBP, BMP, GIF, TIFF et ICO. Les photos HEIC et AVIF s'ouvrent aussi. Redimensionne en pixels, en pourcentage ou en taille de fichier. Transforme des images en PDF ou Word et lit le texte des images (OCR). Vous pouvez aussi ajouter des PDF : chaque page devient une image.
Vidéo - Convertit des vidéos en MP4 ou MKV avec H.264 ou H.265, grâce à l'encodeur matériel du téléphone. Choisissez la qualité, la résolution et la partie de la vidéo ; recadrez, faites pivoter ou supprimez le son ; ou gardez seulement le son en M4A.
Enregistrer des images - Dans l'onglet Vidéo, choisissez Enregistrer des images, sélectionnez l'intervalle de temps et enregistrez une image toutes les quelques secondes, chaque image ou une seule.
Vers Excel - Extrait les tableaux de PDF, scans, photos et fichiers Word vers Excel ou CSV.
Signer - Signez des PDF et remplissez des formulaires. Créez votre signature une fois (tapez votre nom et choisissez un style, dessinez-la avec la souris ou le doigt, ou utilisez une photo de celle-ci sur papier), puis laissez l'application trouver les lignes de signature, ou cliquez sur la page là où doivent aller la signature, les initiales, la date, du texte ou des coches. De nombreux fichiers sont signés en une fois ; chacun est enregistré sous nom_signed.pdf et l'original reste tel quel. Il s'agit d'une signature électronique visible, pas d'une signature numérique à certificat.

COMMENT L'UTILISER
1. Choisissez un onglet en bas de l'écran.
2. Touchez Ajouter des fichiers, ou partagez des fichiers vers Universal Converter depuis une autre application.
3. Choisissez le format et les options. Touchez le (i) à côté d'une option pour savoir ce qu'elle fait.
4. Touchez le bouton sous les options.
Les résultats sont enregistrés dans Téléchargements/Universal Converter. Utilisez Ouvrir ou Partager pour vous en servir tout de suite.
Si vous ajoutez des fichiers qui se convertissent dans un autre onglet, l'app vous indique lequel et les y déplace d'un geste.

CONVERSIONS LONGUES
Vous pouvez quitter l'application pendant la conversion d'une vidéo. Une notification indique qu'elle travaille encore ; autorisez donc les notifications quand on vous le demande. Les vidéos longues ou en haute résolution peuvent prendre du temps et faire chauffer le téléphone.

RECONNAISSANCE DE TEXTE (OCR)
L'anglais et les autres langues à alphabet latin, ainsi que le grec, sont intégrés. Automatique lit ceux-ci et tout alphabet téléchargé ; en choisir un lit plus vite. D'autres alphabets (cyrillique, arabe, chinois, japonais, coréen, thaï, hindi, géorgien, tamoul) se téléchargent dans les Paramètres puis se choisissent dans chaque onglet. Si une grande partie du texte est illisible, l'application le signale et propose d'ajouter un alphabet. Le texte hébreu ne peut pas encore être reconnu.

LANGUES
L'anglais et le grec sont intégrés. L'espagnol, l'italien, l'allemand, le français, le portugais, le polonais, le russe, l'arabe, l'hébreu, le chinois, le japonais, le coréen, le tamoul, l'afrikaans, le yoruba et le haoussa se téléchargent quand vous les choisissez dans les Paramètres, et l'application redémarre pour les utiliser. L'application est sombre par défaut ; choisissez Clair ou Comme le téléphone dans Paramètres > Apparence.

LIMITES SUR UN TÉLÉPHONE
Les anciens fichiers .doc et .ppt ne s'ouvrent pas : enregistrez-les d'abord en .docx ou .pptx. Les fichiers .ods ne peuvent pas encore être lus, et les PDF protégés par mot de passe ne peuvent pas encore être transformés en images. Les très gros fichiers peuvent échouer sur les téléphones qui ont peu de mémoire. Les vidéos qui s'ouvrent dépendent de votre téléphone.

MISES À JOUR
L'application recherche une nouvelle version environ une fois par jour et vous prévient quand il y en a une (désactivable dans Paramètres > Mises à jour). Touchez Télécharger, puis ouvrez le fichier téléchargé pour l'installer par-dessus cette version ; vos réglages sont conservés. Si vous avez installé l'application depuis Google Play, c'est Google Play qui la met à jour.

DÉSINSTALLER
Maintenez l'icône de l'application et choisissez Désinstaller. Les fichiers convertis restent dans Téléchargements/Universal Converter.

AIDE ET ASSISTANCE
Questions, signalements de problèmes et demandes de fonctions : https://github.com/christzouv/universal-converter/issues
E-mail pour les questions, les idées et les langues que vous aimeriez voir ajoutées : universal.converter@outlook.com
Site web: https://christzouv.github.io/universal-converter/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Tous droits réservés.
