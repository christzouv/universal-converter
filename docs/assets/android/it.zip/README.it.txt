UNIVERSAL CONVERTER PER ANDROID - PER INIZIARE
Versione 4.0

Universal Converter converte immagini, documenti, video e audio, crea e firma PDF ed estrae tabelle in Excel. Tutto avviene sul tuo telefono: i tuoi file non vengono mai caricati da nessuna parte. L'app usa internet solo per cercare nuove versioni, per scaricare gli alfabeti di riconoscimento del testo che scegli e quando apri un link. Se lo consenti, invia anche segnalazioni di errore anonime quando qualcosa non va.

COSA FA
Documenti e PDF - Converte tra PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint ed Excel. Trasforma pagine in immagini e unisce più file in un PDF. In PDF puoi attivare Comprimi PDF (inserisci una dimensione, ad es. 500 KB; il testo resta nitido) e Firma (metti la tua firma su ogni PDF). Excel e CSV estraggono tabelle da PDF, scansioni e foto.
Immagini - Converte tra JPG, PNG, WEBP, BMP, GIF, TIFF e ICO. Apre anche foto HEIC e AVIF. Ridimensiona in pixel, percentuale o dimensione del file. Trasforma immagini in PDF o Word e legge il testo nelle immagini (OCR). Si possono aggiungere anche PDF: ogni pagina diventa un'immagine.
Video - Converte video in MP4, MKV, WebM o MOV, oppure crea una GIF animata. MP4, MKV e MOV usano H.264 o H.265 tramite il codificatore hardware del telefono; WebM usa i formati aperti VP9 e Opus. Scegli qualità, risoluzione e parte del video; ritaglia, ruota o rimuovi l'audio; oppure salva solo l'audio in MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF o MKA. Con più video nell'elenco, tocca uno per dargli impostazioni proprie, oppure copiale su tutti.
Salva fotogrammi - Nella scheda Video scegli Salva fotogrammi, seleziona l'intervallo di tempo e salva un'immagine ogni pochi secondi, ogni fotogramma o uno solo.
Firma - Firma PDF e compila moduli. Crea la tua firma una volta (digita il tuo nome e scegli uno stile, disegnala con il dito o una penna, oppure usa una sua foto su carta) e lascia che l'app trovi le righe per la firma, oppure tocca la pagina dove vanno firma, iniziali, data, testo o segni di spunta. Molti file vengono firmati insieme; ognuno viene salvato come nome_signed.pdf e l'originale resta com'era. È una firma elettronica visibile, non una firma digitale basata su certificato.

COME SI USA
1. Tocca Aggiungi file oppure condividi file con Universal Converter da un'altra app.
2. Tocca un file della lista: si aprono le sue opzioni.
3. Tocca un formato: le sue opzioni si aprono subito sotto. Tocca la (i) accanto a un'opzione per leggere cosa fa.
4. Torna alla lista e tocca Converti: viene convertito ogni file.
I risultati vengono salvati in Download/Universal Converter. Usa Apri o Condividi per usarli subito.
Puoi scegliere un altro posto in Impostazioni > Posizione di salvataggio predefinita; l'app lo chiede una volta, dopo la prima conversione.
Ogni file ha le sue impostazioni: copiale dal file precedente dello stesso formato o su ogni file di quel formato; «File successivo» ti porta al prossimo.
Non ti serve un formato? Nascondilo in Impostazioni > Formati. I file senza formato scelto ricevono quello predefinito (Impostazioni > Formati predefiniti).
Il menu ☰ in alto a sinistra apre Impostazioni, questa guida, Novità e correzioni e Sostieni; Impostazioni è anche in alto a destra.

CONVERSIONI LUNGHE
Puoi uscire dall'app mentre un video viene convertito: continua a lavorare in background. I video lunghi o ad alta risoluzione possono richiedere tempo e scaldare il telefono. Se vuoi, Impostazioni > Notifiche ti avvisa quando una conversione è terminata. Scuoti il telefono con decisione per avviare Converti (Impostazioni > Scuoti per convertire).

RICONOSCIMENTO DEL TESTO (OCR)
L'inglese e le altre lingue con alfabeto latino, e il greco, sono inclusi. Automatico legge queste lingue e ogni alfabeto che hai scaricato. Per leggere altre lingue, tocca Cambia accanto a Lingue e spunta le lingue dei tuoi file: se una richiede un alfabeto non ancora presente sul telefono (cirillico, arabo, cinese, giapponese, coreano, thai, hindi, georgiano, tamil), l'app propone di scaricarlo subito e riprendi da dove eri. Gli alfabeti scaricati si possono rimuovere nelle Impostazioni. Se gran parte del testo non si legge, l'app lo dice e propone di aggiungere un alfabeto. Si leggono anche l'ebraico e il vietnamita: ciascuno si scarica una volta, la prima volta che lo si sceglie. Scansioni e moduli compilati diventano testo e tabelle modificabili, disposti come nella pagina (opzione «Pagine con immagini di testo» nelle opzioni di un PDF).

LINGUE
Tutte le 34 lingue sono incluse: scegline una in Impostazioni > Lingua dell'app e l'app si riavvia in quella lingua. Arabo ed ebraico sono mostrati da destra a sinistra. L'app è scura per impostazione predefinita; scegli Chiaro o Come il telefono in Impostazioni > Aspetto.

LIMITI SU UN TELEFONO
File molto grandi possono non riuscire su telefoni con poca memoria. Quali video si possono aprire dipende dal telefono.

AGGIORNAMENTI
L'app cerca una nuova versione circa una volta al giorno e ti avvisa quando c'è (puoi disattivarlo in Impostazioni > Aggiornamenti). Tocca Scarica, poi apri il file scaricato per installarlo sopra questa versione; le impostazioni restano. Se hai installato l'app da Google Play, la aggiorna Google Play.

DISINSTALLARE
Tieni premuta l'icona dell'app e scegli Disinstalla. I file convertiti restano dove sono stati salvati.

AIUTO E SUPPORTO
Domande, segnalazioni di problemi e richieste di funzioni: universal.converter@outlook.com
Email per domande, idee e lingue che vorresti aggiungere: universal.converter@outlook.com
Sito web: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Tutti i diritti riservati.
