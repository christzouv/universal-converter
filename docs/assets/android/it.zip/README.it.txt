UNIVERSAL CONVERTER PER ANDROID - PER INIZIARE
Versione 3.0

Universal Converter converte immagini, documenti, video e audio, crea PDF ed estrae tabelle in Excel. Tutto avviene sul tuo telefono: i tuoi file non vengono mai caricati da nessuna parte. L'app usa internet solo per cercare nuove versioni, per scaricare le lingue che scegli e quando apri un link. Se lo consenti, invia anche segnalazioni di errore anonime quando qualcosa non va.

COSA FA
Documenti e PDF - Converte tra PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint ed Excel. Trasforma pagine in immagini e unisce più file in un PDF. Comprimi PDF: aggiungi un PDF, scegli Comprimi PDF e inserisci la dimensione che ti serve (ad es. 500 KB); le immagini all'interno vengono ridotte finché rientra e il testo resta nitido.
Immagini - Converte tra JPG, PNG, WEBP, BMP, GIF, TIFF e ICO. Apre anche foto HEIC e AVIF. Ridimensiona in pixel, percentuale o dimensione del file. Trasforma immagini in PDF o Word e legge il testo nelle immagini (OCR). Si possono aggiungere anche PDF: ogni pagina diventa un'immagine.
Video - Converte video in MP4 o MKV con H.264 o H.265, usando l'encoder hardware del telefono. Scegli qualità, risoluzione e parte del video; ritaglia, ruota o rimuovi l'audio; oppure salva solo l'audio in M4A.
Salva fotogrammi - Nella scheda Video scegli Salva fotogrammi, seleziona l'intervallo di tempo e salva un'immagine ogni pochi secondi, ogni fotogramma o uno solo.
In Excel - Estrae tabelle da PDF, scansioni, foto e file Word in Excel o CSV.
Firma - Firma PDF e compila moduli. Crea la tua firma una volta (digita il tuo nome e scegli uno stile, disegnala con il mouse o il dito, oppure usa una sua foto su carta) e lascia che l'app trovi le righe per la firma, oppure fai clic sulla pagina dove vanno firma, iniziali, data, testo o segni di spunta. Molti file vengono firmati insieme; ognuno viene salvato come nome_signed.pdf e l'originale resta com'era. È una firma elettronica visibile, non una firma digitale basata su certificato.

COME SI USA
1. Scegli una scheda in basso sullo schermo.
2. Tocca Aggiungi file oppure condividi file con Universal Converter da un'altra app.
3. Scegli formato e opzioni. Tocca la (i) accanto a un'opzione per leggere cosa fa.
4. Tocca il pulsante sotto le opzioni.
I risultati vengono salvati in Download/Universal Converter. Usa Apri o Condividi per usarli subito.
Se aggiungi file che si convertono in un'altra scheda, l'app ti dice quale e li sposta lì con un tocco.

CONVERSIONI LUNGHE
Puoi uscire dall'app mentre un video viene convertito. Una notifica mostra che sta ancora lavorando, quindi consenti le notifiche quando richiesto. Video lunghi o ad alta risoluzione possono richiedere tempo e scaldare il telefono.

RICONOSCIMENTO DEL TESTO (OCR)
L'inglese e le altre lingue con alfabeto latino, e il greco, sono inclusi. Automatico legge questi e ogni alfabeto che hai scaricato; sceglierne uno legge più velocemente. Altri alfabeti (cirillico, arabo, cinese, giapponese, coreano, thai, hindi, georgiano, tamil) si scaricano nelle Impostazioni e poi si scelgono in ogni scheda. Se gran parte del testo non si legge, l'app lo dice e propone di aggiungere un alfabeto. Il testo in ebraico non si può ancora riconoscere.

LINGUE
Inglese e greco sono inclusi. Spagnolo, italiano, tedesco, francese, portoghese, polacco, russo, arabo, ebraico, cinese, giapponese, coreano, tamil, afrikaans, yoruba e hausa si scaricano quando li scegli nelle Impostazioni, e l'app si riavvia per usarli. L'app è scura per impostazione predefinita; scegli Chiaro o Come il telefono in Impostazioni > Aspetto.

LIMITI SU UN TELEFONO
I vecchi file .doc e .ppt non si possono aprire: salvali prima come .docx o .pptx. I file .ods non si possono ancora leggere e i PDF protetti da password non si possono ancora trasformare in immagini. File molto grandi possono non riuscire su telefoni con poca memoria. Quali video si possono aprire dipende dal telefono.

AGGIORNAMENTI
L'app cerca una nuova versione circa una volta al giorno e ti avvisa quando c'è (puoi disattivarlo in Impostazioni > Aggiornamenti). Tocca Scarica, poi apri il file scaricato per installarlo sopra questa versione; le impostazioni restano. Se hai installato l'app da Google Play, la aggiorna Google Play.

DISINSTALLARE
Tieni premuta l'icona dell'app e scegli Disinstalla. I file convertiti restano in Download/Universal Converter.

AIUTO E SUPPORTO
Domande, segnalazioni di problemi e richieste di funzioni: https://github.com/christzouv/universal-converter/issues
Email per domande, idee e lingue che vorresti aggiungere: universal.converter@outlook.com
Sito web: https://christzouv.github.io/universal-converter/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Tutti i diritti riservati.
