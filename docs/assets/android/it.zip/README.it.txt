UNIVERSAL CONVERTER PER ANDROID - PER INIZIARE
Versione 1.2

Universal Converter converte immagini, documenti, video e audio, crea PDF ed estrae tabelle in Excel. Tutto avviene sul tuo telefono: i tuoi file non vengono mai caricati da nessuna parte. L'app usa internet solo per cercare nuove versioni, per scaricare le lingue che scegli e quando apri un link. Se lo consenti, invia anche segnalazioni di errore anonime quando qualcosa non va.

COSA FA
Documenti - Converte tra PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint ed Excel. Trasforma pagine in immagini e unisce più file in un PDF.
Immagini - Converte tra JPG, PNG, WEBP, BMP, GIF, TIFF e ICO. Apre anche foto HEIC e AVIF. Ridimensiona in pixel, percentuale o dimensione del file. Trasforma immagini in PDF o Word e legge il testo nelle immagini (OCR). Si possono aggiungere anche PDF: ogni pagina diventa un'immagine.
Video - Converte video in MP4 o MKV con H.264 o H.265, usando l'encoder hardware del telefono. Scegli qualità, risoluzione e parte del video; ritaglia, ruota o rimuovi l'audio; oppure salva solo l'audio in M4A.
Salva fotogrammi - Nella scheda Video scegli Salva fotogrammi, seleziona l'intervallo di tempo e salva un'immagine ogni pochi secondi, ogni fotogramma o uno solo.
In Excel - Estrae tabelle da PDF, scansioni, foto e file Word in Excel o CSV.

COME SI USA
1. Scegli una scheda in basso sullo schermo.
2. Tocca Aggiungi file oppure condividi file con Universal Converter da un'altra app.
3. Scegli formato e opzioni. Tocca la (i) accanto a un'opzione per leggere cosa fa.
4. Tocca il pulsante sotto le opzioni.
I risultati vengono salvati in Download/Universal Converter. Usa Apri o Condividi per usarli subito.
Se aggiungi file che si convertono in un'altra scheda, l'app ti dice quale e li sposta lì con un tocco.

CONVERSIONI LUNGHE
Puoi uscire dall'app mentre un video viene convertito. Una notifica mostra che sta ancora lavorando, quindi consenti le notifiche quando richiesto. Video lunghi o ad alta risoluzione possono richiedere tempo e scaldare il telefono.

RICONOSCIMENTO DEL TESTO (OCR)
L'inglese e le altre lingue con alfabeto latino, e il greco, sono inclusi. Automatico li prova entrambi; sceglierne uno è più veloce. Altri alfabeti (cirillico, arabo, cinese, giapponese, coreano, thailandese, hindi, georgiano) si possono scaricare nelle Impostazioni e poi scegliere in ogni scheda.

LINGUE
L'inglese e il greco sono inclusi. Spagnolo, italiano, tedesco, francese, portoghese, cinese, giapponese e coreano vengono scaricati quando li scegli nelle Impostazioni, e l'app si riavvia per usarli. Il primo avvio della versione 1.0 li propone una volta. L'app è scura per impostazione predefinita; scegli Chiaro o Come il telefono in Impostazioni > Aspetto.

LIMITI SU UN TELEFONO
I vecchi file .doc e .ppt non si possono aprire: salvali prima come .docx o .pptx. I file .ods non si possono ancora leggere e i PDF protetti da password non si possono ancora trasformare in immagini. File molto grandi possono non riuscire su telefoni con poca memoria. Quali video si possono aprire dipende dal telefono.

AGGIORNAMENTI
L'app cerca una nuova versione circa una volta al giorno e ti avvisa quando c'è (puoi disattivarlo in Impostazioni > Aggiornamenti). Tocca Scarica, poi apri il file scaricato per installarlo sopra questa versione; le impostazioni restano.

DISINSTALLARE
Tieni premuta l'icona dell'app e scegli Disinstalla. I file convertiti restano in Download/Universal Converter.

AIUTO E SUPPORTO
Domande, segnalazioni di problemi e richieste di funzioni: https://github.com/christzouv/universal-converter/issues

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Tutti i diritti riservati.
