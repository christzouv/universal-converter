UNIVERSAL CONVERTER KWA ANDROID - KUANZA
Toleo 4.0

Universal Converter hubadilisha picha, hati, video na sauti, hutengeneza PDF na huhamishia majedwali kwenye Excel. Kila kitu hufanyika kwenye simu yako: faili zako hazipakiwi kamwe. Programu hutumia intaneti tu kutafuta matoleo mapya, kupakua alfabeti za utambuzi wa maandishi unazochagua, na unapofungua kiungo. Ukiruhusu, pia hutuma ripoti za hitilafu bila kutaja jina jambo likienda vibaya.

INACHOFANYA
Hati na PDF - Badilisha kati ya PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint na Excel. Geuza kurasa kuwa picha, na unganisha faili kadhaa kuwa PDF moja. Chini ya PDF unaweza kuwasha Bana PDF (weka ukubwa kama KB 500; maandishi hubaki wazi) na Sahihi (weka sahihi yako kwenye kila PDF). Excel na CSV hutoa majedwali kutoka PDF, skani na picha.
Picha - Badilisha kati ya JPG, PNG, WEBP, BMP, GIF, TIFF na ICO. Picha za HEIC na AVIF pia zinaweza kufunguliwa. Badilisha ukubwa kwa pikseli, asilimia au ukubwa wa faili. Geuza picha kuwa PDF au Word, na usome maandishi yaliyo kwenye picha (OCR). PDF pia zinaweza kuongezwa: kila ukurasa huwa picha.
Video - Badilisha video kuwa MP4, MKV, WebM au MOV, au tengeneza GIF inayosonga. MP4, MKV na MOV hutumia H.264 au H.265 kutoka kwa kisimbaji cha maunzi cha simu yako; WebM hutumia miundo huria ya VP9 na Opus. Chagua ubora, ubora wa picha na sehemu ya video; punguza kingo, zungusha au ondoa sauti; au hifadhi sauti tu kama MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF au MKA. Zikiwa video kadhaa kwenye orodha, gusa moja ili kuipa mipangilio yake, au nakili mipangilio hiyo kwa zote.
Hifadhi fremu - Kwenye kichupo cha Video, chagua Hifadhi fremu, chagua kipindi cha muda na uhifadhi picha moja kila baada ya sekunde chache, kila fremu au moja tu.
Sahihi - Tia sahihi PDF na ujaze fomu. Tengeneza sahihi yako mara moja - andika jina lako na uchague mtindo, ichore kwa kidole au kalamu, au tumia picha yake kwenye karatasi - kisha uache programu itafute mistari ya sahihi, au gusa ukurasa mahali sahihi, herufi za mwanzo, tarehe, maandishi au alama za tiki zinapopaswa kwenda. Faili nyingi hutiwa sahihi kwa mara moja; kila moja huhifadhiwa kama jina_signed.pdf na asili hubaki kama ilivyokuwa. Hii ni sahihi ya kielektroniki inayoonekana, si sahihi ya kidijitali inayotegemea cheti.

JINSI YA KUTUMIA
1. Gusa Ongeza faili, au shiriki faili kwa Universal Converter kutoka programu nyingine.
2. Gusa faili kwenye orodha: chaguo zake hufunguka.
3. Gusa umbizo: chaguo zake hufunguka chini yake moja kwa moja. Gusa (i) kando ya chaguo ili usome kinachofanya.
4. Rudi kwenye orodha na uguse Badilisha: kila faili hubadilishwa.
Matokeo huhifadhiwa kwenye Downloads/Universal Converter. Tumia Fungua au Shiriki ili kuyatumia mara moja.
Unaweza kuchagua mahali pengine katika Mipangilio > Mahali pa kawaida pa kuhifadhi; programu huuliza mara moja, baada ya ubadilishaji wako wa kwanza.
Kila faili ina mipangilio yake: zinakili kutoka faili iliyotangulia ya umbizo hilo au kwa kila faili ya umbizo hilo; «Faili inayofuata» inakupeleka kwenye inayofuata.
Huhitaji umbizo fulani? Lifiche katika Mipangilio > Umbizo. Faili zisizo na umbizo lililochaguliwa hupata la msingi (Mipangilio > Umbizo za msingi).
Menyu ☰ juu kushoto hufungua Mipangilio, mwongozo huu, Mapya na marekebisho na Saidia; Mipangilio iko pia juu kulia.

UBADILISHAJI MREFU
Unaweza kuondoka kwenye programu wakati video inabadilishwa: inaendelea kufanya kazi chinichini. Video ndefu au zenye ubora wa juu zinaweza kuchukua muda na kupasha simu joto. Ukipenda, Mipangilio > Arifa itakuarifu ubadilishaji ukikamilika. Tikisa simu kwa nguvu ili kuanza Badilisha (Mipangilio > Tikisa ili kubadilisha).

UTAMBUZI WA MAANDISHI (OCR)
Kiingereza na lugha nyingine za alfabeti ya Kilatini, pamoja na Kigiriki, zimejengwa ndani. Kiotomatiki husoma hizi na alfabeti yoyote uliyopakua. Ili kusoma lugha nyingine, gusa Badilisha kando ya Lugha na uweke tiki kwenye lugha za faili zako: ikiwa mojawapo inahitaji alfabeti ambayo bado haiko kwenye simu (Kisiriliki, Kiarabu, Kichina, Kijapani, Kikorea, Kithai, Kihindi, Kijojia, Kitamili), programu hutoa kuipakua papo hapo, na unaendelea ulipokuwa. Alfabeti zilizopakuliwa zinaweza kuondolewa katika Mipangilio. Ikiwa sehemu kubwa ya maandishi haiwezi kusomwa, programu husema hivyo na hutoa kuongeza alfabeti. Kiebrania na Kivietinamu pia husomwa: kila moja hupakuliwa mara moja, mara ya kwanza unapoichagua. Skani na fomu zilizojazwa huwa maandishi na majedwali yanayoweza kuhaririwa, yaliyopangwa kama ukurasa (chaguo "Kurasa zenye picha za maandishi" katika chaguo za PDF).

LUGHA
Lugha zote 34 zimejengwa ndani: chagua moja katika Mipangilio > Lugha ya programu, na programu huanza upya kwa lugha hiyo. Kiarabu na Kiebrania huonyeshwa kutoka kulia kwenda kushoto. Programu huwa na rangi nyeusi kwa chaguo-msingi; chagua Angavu au Kama simu katika Mipangilio > Mwonekano.

VIKOMO KWENYE SIMU
Faili kubwa sana zinaweza kushindwa kwenye simu zenye kumbukumbu ndogo. Video zipi zinaweza kufunguliwa hutegemea simu yako.

MASASISHO
Programu hutafuta toleo jipya takriban mara moja kwa siku na hukuambia linapopatikana (zima hili katika Mipangilio > Masasisho). Gusa Pakua, kisha fungua faili iliyopakuliwa ili kuisakinisha juu ya hii; mipangilio yako hubaki. Ikiwa ulisakinisha programu kutoka Google Play, Google Play ndiyo huisasisha.

KUONDOA
Shikilia aikoni ya programu na uchague Ondoa. Faili ulizobadilisha hubaki mahali zilipohifadhiwa.

MSAADA NA USAIDIZI
Maswali, ripoti za matatizo na maombi ya vipengele: universal.converter@outlook.com
Barua pepe kwa maswali, mawazo na lugha ungependa ziongezwe: universal.converter@outlook.com
Tovuti: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Haki zote zimehifadhiwa.
