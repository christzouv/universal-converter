UNIVERSAL CONVERTER VOOR ANDROID - AAN DE SLAG
Versie 4.0

Universal Converter converteert afbeeldingen, documenten, video's en geluid, maakt PDF's en haalt tabellen naar Excel. Alles gebeurt op je telefoon: je bestanden worden nooit geüpload. De app gebruikt internet alleen om naar nieuwe versies te zoeken, om de alfabetten voor tekstherkenning te downloaden die je kiest, en als je een link opent. Als je het toestaat, stuurt hij ook anonieme foutrapporten als er iets misgaat.

WAT HIJ DOET
Documenten en PDF - Converteer tussen PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint en Excel. Maak afbeeldingen van pagina's en voeg meerdere bestanden samen tot één PDF. Onder PDF kun je PDF comprimeren aanzetten (vul een grootte in zoals 500 KB; de tekst blijft scherp) en Ondertekenen (zet je handtekening op elke PDF). Excel en CSV halen tabellen uit PDF's, scans en foto's.
Afbeeldingen - Converteer tussen JPG, PNG, WEBP, BMP, GIF, TIFF en ICO. Foto's in HEIC en AVIF kunnen ook worden geopend. Wijzig het formaat in pixels, procenten of bestandsgrootte. Maak van afbeeldingen een PDF of Word-bestand, en lees de tekst in afbeeldingen (OCR). Ook PDF's kunnen worden toegevoegd: elke pagina wordt een afbeelding.
Video - Converteer video's naar MP4, MKV, WebM of MOV, of maak een geanimeerde GIF. MP4, MKV en MOV gebruiken H.264 of H.265 van de hardware-encoder van je telefoon; WebM gebruikt de open formaten VP9 en Opus. Kies de kwaliteit, de resolutie en het deel van de video; snij bij, draai of haal het geluid weg; of sla alleen het geluid op als MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF of MKA. Staan er meerdere video's in de lijst, tik dan op een video om die eigen instellingen te geven, of kopieer ze naar alle video's.
Beelden opslaan - Kies Beelden opslaan in het tabblad Video, kies het tijdsbereik en sla om de paar seconden een afbeelding op, elk beeld of maar één.
Ondertekenen - Onderteken PDF's en vul formulieren in. Maak je handtekening één keer - typ je naam en kies een stijl, teken hem met je vinger of een pen, of gebruik een foto ervan op papier - en laat de app de handtekeningregels vinden, of tik op de pagina waar handtekening, initialen, datum, tekst of vinkjes moeten komen. Veel bestanden worden in één keer ondertekend; elk wordt opgeslagen als naam_signed.pdf en het origineel blijft zoals het was. Dit is een zichtbare elektronische handtekening, geen digitale handtekening op basis van een certificaat.

ZO GEBRUIK JE HEM
1. Tik op Bestanden toevoegen, of deel bestanden vanuit een andere app met Universal Converter.
2. Tik op een bestand in de lijst: de eigen opties openen.
3. Tik op een formaat: de opties gaan er meteen onder open. Tik op de (i) naast een optie om te lezen wat die doet.
4. Ga terug naar de lijst en tik op Omzetten: elk bestand wordt omgezet.
De resultaten worden opgeslagen in Downloads/Universal Converter. Gebruik Openen of Delen om ze meteen te gebruiken.
Je kunt een andere plek kiezen in Instellingen > Standaard opslaglocatie; de app vraagt het één keer, na je eerste conversie.
Elk bestand heeft zijn eigen instellingen: kopieer ze van het vorige bestand met hetzelfde formaat of naar elk bestand van dat formaat; 'Volgend bestand' brengt je naar het volgende.
Een formaat niet nodig? Verberg het in Instellingen > Formaten. Bestanden zonder gekozen formaat krijgen het standaardformaat (Instellingen > Standaardformaten).
Het menu ☰ linksboven opent Instellingen, deze handleiding, Wat is er nieuw & opgelost en Steunen; Instellingen staat ook rechtsboven.

LANGE CONVERSIES
Je kunt de app verlaten terwijl een video wordt geconverteerd: hij werkt op de achtergrond door. Lange video's of video's met een hoge resolutie kunnen even duren en de telefoon warm maken. Als je wilt, laat Instellingen > Meldingen weten wanneer een conversie klaar is. Schud de telefoon stevig om Converteren te starten (Instellingen > Schudden om te converteren).

TEKSTHERKENNING (OCR)
Engels en andere talen met het Latijnse alfabet, en Grieks, zijn ingebouwd. Automatisch leest deze en elk alfabet dat je hebt gedownload. Om andere talen te lezen, tik je op Wijzigen naast Talen en vink je de talen in je bestanden aan: heeft een ervan een alfabet nodig dat nog niet op de telefoon staat (Cyrillisch, Arabisch, Chinees, Japans, Koreaans, Thai, Hindi, Georgisch, Tamil), dan biedt de app aan het meteen te downloaden, en ga je verder waar je was. Gedownloade alfabetten kun je verwijderen in Instellingen. Kan een groot deel van de tekst niet worden gelezen, dan zegt de app dat en biedt aan een alfabet toe te voegen. Hebreeuws en Vietnamees worden ook gelezen: elk wordt één keer gedownload, de eerste keer dat je het kiest. Scans en ingevulde formulieren worden bewerkbare tekst en tabellen, ingedeeld zoals de pagina (optie "Pagina's met afbeeldingen van tekst" in de opties van een PDF).

TALEN
Alle 34 talen zijn ingebouwd: kies er een in Instellingen > Taal van de app, en de app start opnieuw in die taal. Arabisch en Hebreeuws worden van rechts naar links getoond. De app is standaard donker; kies Licht of Zoals de telefoon in Instellingen > Uiterlijk.

GRENZEN OP EEN TELEFOON
Heel grote bestanden kunnen mislukken op telefoons met weinig geheugen. Welke video's kunnen worden geopend, hangt af van je telefoon.

UPDATES
De app zoekt ongeveer één keer per dag naar een nieuwe versie en meldt het als die er is (zet dit uit in Instellingen > Updates). Tik op Downloaden en open dan het gedownloade bestand om het over deze versie te installeren; je instellingen blijven bewaard. Heb je de app via Google Play geïnstalleerd, dan werkt Google Play hem bij.

VERWIJDEREN
Houd het pictogram van de app ingedrukt en kies Verwijderen. Bestanden die je hebt geconverteerd, blijven waar ze zijn opgeslagen.

HULP EN ONDERSTEUNING
Vragen, probleemmeldingen en verzoeken om functies: universal.converter@outlook.com
E-mail voor vragen, ideeën en talen die je erbij wilt: universal.converter@outlook.com
Website: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Alle rechten voorbehouden.
