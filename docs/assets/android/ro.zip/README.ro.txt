UNIVERSAL CONVERTER PENTRU ANDROID - PRIMII PAȘI
Versiunea 4.0

Universal Converter convertește imagini, documente, videoclipuri și audio, creează PDF-uri și duce tabelele în Excel. Totul se întâmplă pe telefonul tău: fișierele tale nu sunt încărcate niciodată. Aplicația folosește internetul doar ca să caute versiuni noi, ca să descarce alfabetele de recunoaștere a textului pe care le alegi și când deschizi un link. Dacă îi permiți, trimite și rapoarte de eroare anonime când ceva nu merge.

CE FACE
Documente și PDF - Conversie între PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint și Excel. Pagini transformate în imagini și mai multe fișiere combinate într-un PDF. La PDF poți porni Comprimă PDF (introdu o mărime, ca 500 KB; textul rămâne clar) și Semnează (pune semnătura pe fiecare PDF). Excel și CSV scot tabelele din PDF-uri, scanări și fotografii.
Imagini - Conversie între JPG, PNG, WEBP, BMP, GIF, TIFF și ICO. Se pot deschide și fotografii HEIC și AVIF. Redimensionare după pixeli, procent sau mărimea fișierului. Imagini transformate în PDF sau Word și citirea textului din imagini (OCR). Se pot adăuga și PDF-uri: fiecare pagină devine o imagine.
Video - Convertește videoclipuri în MP4, MKV, WebM sau MOV, sau fă un GIF animat. MP4, MKV și MOV folosesc H.264 sau H.265 de la encoderul hardware al telefonului; WebM folosește formatele deschise VP9 și Opus. Alege calitatea, rezoluția și partea din videoclip; decupează, rotește sau elimină sunetul; sau salvează doar sunetul ca MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF sau MKA. Cu mai multe videoclipuri în listă, atinge unul ca să-i dai setări proprii sau copiază-le la toate.
Salvează cadre - În fila Video, alege Salvează cadre, stabilește intervalul de timp și salvează o imagine la câteva secunde, fiecare cadru sau doar unul.
Semnează - Semnează PDF-uri și completează formulare. Creează-ți semnătura o dată - scrie-ți numele și alege un stil, deseneaz-o cu degetul sau cu un stilou, sau folosește o fotografie a ei pe hârtie - apoi lasă aplicația să găsească liniile de semnătură, sau atinge pagina unde trebuie puse semnătura, inițialele, data, textul sau bifele. Multe fișiere se semnează deodată; fiecare e salvat ca nume_signed.pdf, iar originalul rămâne cum era. Aceasta este o semnătură electronică vizibilă, nu o semnătură digitală bazată pe certificat.

CUM SE FOLOSEȘTE
1. Atinge Adaugă fișiere sau distribuie fișiere către Universal Converter din altă aplicație.
2. Atinge un fișier din listă: i se deschid opțiunile.
3. Atinge un format: opțiunile lui se deschid chiar sub el. Atinge (i) de lângă o opțiune ca să citești ce face.
4. Întoarce-te la listă și atinge Convertește: fiecare fișier este convertit.
Rezultatele sunt salvate în Downloads/Universal Converter. Folosește Deschide sau Distribuie ca să le folosești imediat.
Poți alege alt loc în Setări > Locația implicită de salvare; aplicația întreabă o dată, după prima conversie.
Fiecare fișier are setările lui: copiază-le din fișierul anterior de același format sau la fiecare fișier de acel format; „Fișierul următor” te duce la următorul.
Nu ai nevoie de un format? Ascunde-l în Setări > Formate. Fișierele fără format ales primesc formatul implicit (Setări > Formate implicite).
Meniul ☰ din stânga sus deschide Setări, acest ghid, Noutăți și remedieri și Susține; Setări se află și în dreapta sus.

CONVERSII LUNGI
Poți ieși din aplicație cât timp se convertește un videoclip: lucrează mai departe în fundal. Videoclipurile lungi sau cu rezoluție mare pot dura o vreme și pot încălzi telefonul. Dacă doriți, Setări > Notificări vă anunță când se termină o conversie. Scuturați ferm telefonul pentru a porni Convertește (Setări > Scuturați pentru a converti).

RECUNOAȘTEREA TEXTULUI (OCR)
Engleza și alte limbi cu alfabet latin, plus greaca, sunt incluse. Automat citește aceste limbi și orice alfabet pe care l-ai descărcat. Ca să citești alte limbi, atinge Schimbă lângă Limbi și bifează limbile din fișierele tale: dacă una are nevoie de un alfabet care nu e încă pe telefon (chirilic, arab, chinez, japonez, coreean, thai, hindi, georgian, tamil), aplicația se oferă să-l descarce pe loc și continui de unde ai rămas. Alfabetele descărcate pot fi șterse din Setări. Dacă mare parte din text nu poate fi citită, aplicația spune asta și se oferă să adauge un alfabet. Se citesc și ebraica și vietnameza: fiecare se descarcă o dată, prima oară când o alegi. Scanările și formularele completate devin text și tabele editabile, așezate ca pe pagină (opțiunea „Pagini cu imagini de text” din opțiunile unui PDF).

LIMBI
Toate cele 34 de limbi sunt incluse: alege una în Setări > Limba aplicației, iar aplicația repornește în acea limbă. Araba și ebraica sunt afișate de la dreapta la stânga. Aplicația e întunecată implicit; alege Luminoasă sau Ca telefonul în Setări > Aspect.

LIMITE PE TELEFON
Fișierele foarte mari pot eșua pe telefoanele cu puțină memorie. Ce videoclipuri se pot deschide depinde de telefonul tău.

ACTUALIZĂRI
Aplicația caută o versiune nouă cam o dată pe zi și îți spune când apare una (dezactivează asta în Setări > Actualizări). Atinge Descarcă, apoi deschide fișierul descărcat ca să-l instalezi peste versiunea aceasta; setările tale rămân. Dacă ai instalat aplicația din Google Play, o actualizează Google Play.

DEZINSTALARE
Ține apăsat pe pictograma aplicației și alege Dezinstalează. Fișierele convertite rămân unde au fost salvate.

AJUTOR ȘI ASISTENȚĂ
Întrebări, raportări de probleme și cereri de funcții: universal.converter@outlook.com
E-mail pentru întrebări, idei și limbi pe care le-ai vrea adăugate: universal.converter@outlook.com
Site: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Toate drepturile rezervate.
