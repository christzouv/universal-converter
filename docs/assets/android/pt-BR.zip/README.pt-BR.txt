UNIVERSAL CONVERTER PARA ANDROID - PRIMEIROS PASSOS
Versão 4.0

O Universal Converter converte imagens, documentos, vídeos e áudio, cria PDFs e leva tabelas para o Excel. Tudo acontece no seu celular: seus arquivos nunca são enviados. O app só usa a internet para procurar novas versões, para baixar os alfabetos de reconhecimento de texto que você escolher e quando você abre um link. Se você permitir, ele também envia relatórios de erro anônimos quando algo dá errado.

O QUE ELE FAZ
Documentos e PDF - Converta entre PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint e Excel. Transforme páginas em imagens e junte vários arquivos em um PDF. Em PDF você pode ativar Comprimir PDF (digite um tamanho como 500 KB; o texto continua nítido) e Assinar (coloque sua assinatura em cada PDF). Excel e CSV tiram tabelas de PDFs, digitalizações e fotos.
Imagens - Converta entre JPG, PNG, WEBP, BMP, GIF, TIFF e ICO. Fotos em HEIC e AVIF também podem ser abertas. Redimensione por pixels, porcentagem ou tamanho de arquivo. Transforme imagens em PDF ou Word e leia o texto das imagens (OCR). Também dá para adicionar PDFs: cada página vira uma imagem.
Vídeo - Converta vídeos para MP4, MKV, WebM ou MOV, ou crie um GIF animado. MP4, MKV e MOV usam H.264 ou H.265 do codificador de hardware do seu celular; WebM usa os formatos abertos VP9 e Opus. Escolha a qualidade, a resolução e o trecho do vídeo; corte, gire ou tire o som; ou salve só o som em MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF ou MKA. Com vários vídeos na lista, toque em um para dar a ele configurações próprias, ou copie-as para todos.
Salvar quadros - Na aba Vídeo, escolha Salvar quadros, defina o intervalo de tempo e salve uma imagem a cada poucos segundos, todos os quadros ou só um.
Assinar - Assine PDFs e preencha formulários. Crie sua assinatura uma vez - digite seu nome e escolha um estilo, desenhe com o dedo ou uma caneta, ou use uma foto dela no papel - e deixe o app encontrar as linhas de assinatura, ou toque na página onde a assinatura, iniciais, data, texto ou marcas devem ir. Vários arquivos são assinados de uma vez; cada um é salvo como nome_signed.pdf e o original fica como estava. Esta é uma assinatura eletrônica visível, não uma assinatura digital baseada em certificado.

COMO USAR
1. Toque em Adicionar arquivos, ou compartilhe arquivos com o Universal Converter a partir de outro app.
2. Toque em um arquivo da lista: as opções dele abrem.
3. Toque em um formato: as opções dele abrem logo abaixo. Toque no (i) ao lado de uma opção para ler o que ela faz.
4. Volte à lista e toque em Converter: cada arquivo é convertido.
Os resultados são salvos em Downloads/Universal Converter. Use Abrir ou Compartilhar para usá-los na hora.
Você pode escolher outro lugar em Configurações > Local de salvamento padrão; o app pergunta uma vez, depois da sua primeira conversão.
Cada arquivo tem as próprias configurações: copie do arquivo anterior do mesmo formato ou para cada arquivo desse formato; «Próximo arquivo» leva você ao seguinte.
Não precisa de um formato? Oculte-o em Configurações > Formatos. Arquivos sem formato escolhido recebem o padrão (Configurações > Formatos padrão).
O menu ☰ no canto superior esquerdo abre Configurações, este guia, Novidades e correções e Apoiar; Configurações também fica no canto superior direito.

CONVERSÕES LONGAS
Você pode sair do app enquanto um vídeo é convertido: ele continua trabalhando em segundo plano. Vídeos longos ou de alta resolução podem demorar e esquentar o celular. Se quiser, Configurações > Notificações avisa quando uma conversão termina. Agite o celular com firmeza para iniciar Converter (Configurações > Agitar para converter).

RECONHECIMENTO DE TEXTO (OCR)
Inglês e outros idiomas com alfabeto latino, e grego, já vêm no app. Automático lê esses e qualquer alfabeto que você tenha baixado. Para ler outros idiomas, toque em Alterar ao lado de Idiomas e marque os idiomas dos seus arquivos: se algum precisar de um alfabeto que ainda não está no celular (cirílico, árabe, chinês, japonês, coreano, tailandês, hindi, georgiano, tâmil), o app oferece baixá-lo na hora, e você continua de onde parou. Alfabetos baixados podem ser removidos em Configurações. Se boa parte do texto não puder ser lida, o app avisa e oferece adicionar um alfabeto. Hebraico e vietnamita também são lidos: cada um é baixado uma vez, na primeira vez que você escolher. Digitalizações e formulários preenchidos viram texto e tabelas editáveis, com o layout da página (opção "Páginas com imagens de texto" nas opções de um PDF).

IDIOMAS
Os 34 idiomas já vêm no app: escolha um em Configurações > Idioma do app, e o app reinicia nesse idioma. Árabe e hebraico aparecem da direita para a esquerda. O app é escuro por padrão; escolha Claro ou Igual ao celular em Configurações > Aparência.

LIMITES NO CELULAR
Arquivos muito grandes podem falhar em celulares com pouca memória. Quais vídeos podem ser abertos depende do seu celular.

ATUALIZAÇÕES
O app procura uma nova versão mais ou menos uma vez por dia e avisa quando houver uma (desative isso em Configurações > Atualizações). Toque em Baixar e abra o arquivo baixado para instalá-lo por cima deste; suas configurações continuam. Se você instalou o app pelo Google Play, o Google Play é quem o atualiza.

DESINSTALAR
Toque e segure o ícone do app e escolha Desinstalar. Os arquivos que você converteu continuam onde foram salvos.

AJUDA E SUPORTE
Dúvidas, relatos de problemas e pedidos de recursos: universal.converter@outlook.com
E-mail para dúvidas, ideias e idiomas que você queira: universal.converter@outlook.com
Site: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Todos os direitos reservados.
