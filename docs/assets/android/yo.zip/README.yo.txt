UNIVERSAL CONVERTER FÚN ANDROID - BÍ A ṢE Ń BẸ̀RẸ̀
Ẹ̀yà 3.0

Universal Converter ń yí àwòrán, ìwé, fídíò àti ohùn padà, ó ń ṣe PDF, ó ń buwọ́lu wọ́n, ó sì ń gbé tábìlì lọ sí Excel. Gbogbo rẹ̀ ń ṣẹlẹ̀ lórí fóònù rẹ: a kò gbé àwọn fáìlì rẹ sókè láé. Ìṣàfilọ́lẹ̀ náà ń lo íńtánẹ́ẹ̀tì láti ṣàyẹ̀wò fún ẹ̀yà tuntun, láti gba àwọn èdè tí o yàn sílẹ̀, àti nígbà tí o bá ṣí ìjápọ̀ nìkan. Tí o bá gbà, ó tún ń fi ìròyìn àṣìṣe àìlórúkọ ránṣẹ́ nígbà tí nǹkan bá bàjẹ́.

OHUN TÍ Ó Ń ṢE
Àwọn ìwé & PDF - Yí padà láàrin PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint àti Excel. Sọ ojú-ìwé di àwòrán, kí o sì da ọ̀pọ̀ fáìlì pọ̀ sínú PDF kan. Fún PDF pọ̀: fi PDF kan kún un, yan Fún PDF pọ̀, kí o sì tẹ ìwọ̀n tí o nílò (fún àpẹẹrẹ 500 KB); a ó dín àwọn àwòrán inú rẹ̀ kù títí yóò fi bá a mu, ọ̀rọ̀ yóò sì ṣì mọ́ kedere.
Àwọn àwòrán - Yí padà láàrin JPG, PNG, WEBP, BMP, GIF, TIFF àti ICO. A tún lè ṣí fọ́tò HEIC àti AVIF. Yí ìwọ̀n padà nípasẹ̀ píksẹ́lì, ìpín tàbí ìwọ̀n fáìlì. Sọ àwòrán di PDF tàbí Word, kí o sì ka ọ̀rọ̀ inú àwòrán (OCR). A tún lè fi PDF kún un: ojú-ìwé kọ̀ọ̀kan á di àwòrán.
Fídíò - Yí fídíò padà sí MP4 tàbí MKV pẹ̀lú H.264 tàbí H.265, ní lílo ẹ̀rọ ìyípadà hádíwíà fóònù rẹ. Yan ìdára, ìpinnu àti apá fídíò; gé e, yí i padà tàbí yọ ohùn kúrò; tàbí fi ohùn nìkan pamọ́ bí M4A.
Fi àwọn fírémù pamọ́ - Ní táàbù Fídíò, yan Fi àwọn fírémù pamọ́, yan àkókò kí o sì fi àwòrán kan pamọ́ ní ìṣẹ́jú-àáyá díẹ̀ kọ̀ọ̀kan, gbogbo fírémù tàbí ẹyọ kan ṣoṣo.
Sí Excel - Gbé tábìlì láti PDF, ẹ̀dà, fọ́tò àti fáìlì Word lọ sí Excel tàbí CSV.
Ìbuwọ́lù - Buwọ́lu PDF kí o sì kún fọ́ọ̀mù. Ṣe ìbuwọ́lù rẹ lẹ́ẹ̀kan – tẹ orúkọ rẹ kí o yan ọ̀nà kíkọ, yà á pẹ̀lú màúsì tàbí ìka, tàbí lo fọ́tò rẹ̀ lórí bébà – lẹ́yìn náà jẹ́ kí ìṣàfilọ́lẹ̀ wá àwọn ìlà ìbuwọ́lù, tàbí tẹ ibi tí ìbuwọ́lù, lẹ́tà àkọ́kọ́ orúkọ, déètì, ọ̀rọ̀ tàbí àmì yẹ kí ó wà lórí ojú-ìwé. A ń buwọ́lu ọ̀pọ̀ fáìlì lẹ́ẹ̀kan; a ń fi ọ̀kọ̀ọ̀kan pamọ́ bí orúkọ_signed.pdf, fáìlì àtilẹ̀wá sì wà bí ó ti wà. Ìbuwọ́lù oníná tí a lè rí ni èyí, kì í ṣe ìbuwọ́lù oní-nọ́ńbà tí ó ní ìwé-ẹ̀rí.

BÍ A ṢE Ń LÒ Ó
1. Yan táàbù kan ní ìsàlẹ̀ ojú-ìbòjú.
2. Tẹ Fi fáìlì kún un, tàbí pín fáìlì sí Universal Converter láti ìṣàfilọ́lẹ̀ mìíràn.
3. Yan ìrísí àti àwọn àṣàyàn. Tẹ (i) lẹ́gbẹ̀ẹ́ àṣàyàn kan láti ka ohun tí ó ń ṣe.
4. Tẹ bọ́tìnnì tí ó wà ní ìsàlẹ̀ àwọn àṣàyàn.
A ń fi àwọn èsì pamọ́ sínú Downloads/Universal Converter. Lo Ṣí tàbí Pín láti lò wọ́n lẹ́sẹ̀kẹsẹ̀.
Tí o bá fi fáìlì tí táàbù mìíràn ń yí padà kún un, ìṣàfilọ́lẹ̀ náà yóò sọ táàbù wo, yóò sì gbé wọn lọ síbẹ̀ pẹ̀lú títẹ̀ kan.

ÌYÍPADÀ GÍGÙN
O lè fi ìṣàfilọ́lẹ̀ náà sílẹ̀ nígbà tí fídíò bá ń yí padà. Ìfitónilétí kan ń fi hàn pé ó ṣì ń ṣiṣẹ́, nítorí náà jọ̀wọ́ gba ìfitónilétí láàyè nígbà tí a bá béèrè. Fídíò gígùn tàbí tí ó ní ìpinnu gíga lè gba àkókò, ó sì lè mú fóònù gbóná.

ÌDÁMỌ̀ Ọ̀RỌ̀ (OCR)
Gẹ̀ẹ́sì àti àwọn èdè mìíràn ní álífábẹ́ẹ̀tì Látìn, àti Gíríìkì, wà nínú rẹ̀. Aládàáṣe ń ka àwọn wọ̀nyí àti álífábẹ́ẹ̀tì èyíkéyìí tí o ti gbà sílẹ̀; yíyan ọ̀kan ń kà yára. A lè gba àwọn álífábẹ́ẹ̀tì mìíràn (Cyrillic, Lárúbáwá, Ṣáínà, Japanese, Korean, Thai, Hindi, Georgian, Tamil) sílẹ̀ ní Ètò, kí a sì yàn wọ́n nínú táàbù kọ̀ọ̀kan. Tí a kò bá lè ka ọ̀pọ̀ nínú ọ̀rọ̀ náà, ìṣàfilọ́lẹ̀ yóò sọ bẹ́ẹ̀, yóò sì dábàá láti fi álífábẹ́ẹ̀tì kún un. A kò tíì lè dá ọ̀rọ̀ Hébérù mọ̀.

ÀWỌN ÈDÈ
Gẹ̀ẹ́sì àti Gíríìkì wà nínú rẹ̀. A ń gba Sípáníìṣì, Ítálì, Jámánì, Faransé, Potogí, Pólándì, Rọ́ṣíà, Lárúbáwá, Hébérù, Ṣáínà, Japanese, Korean, Tamil, Afrikaans, Yorùbá àti Hausa sílẹ̀ nígbà tí o bá yàn wọ́n ní Ètò, ìṣàfilọ́lẹ̀ yóò sì tún bẹ̀rẹ̀ láti lò wọ́n. Ìṣàfilọ́lẹ̀ náà dúdú ní àkọ́kọ́; yan Ìmọ́lẹ̀ tàbí Bá ti fóònù mu ní Ètò > Ìrísí.

ÀWỌN ÀLÀ LÓRÍ FÓÒNÙ
A kò lè ṣí àwọn fáìlì .doc àti .ppt àtijọ́: kọ́kọ́ fi wọ́n pamọ́ bí .docx tàbí .pptx. A kò tíì lè ka fáìlì .ods, a kò sì tíì lè sọ PDF tí ó ní ọ̀rọ̀ aṣínà di àwòrán. Fáìlì tí ó tóbi gan-an lè kùnà lórí fóònù tí kò ní ìrántí púpọ̀. Àwọn fídíò tí a lè ṣí dá lórí fóònù rẹ.

ÀTÚNṢE
Ìṣàfilọ́lẹ̀ náà ń ṣàyẹ̀wò fún ẹ̀yà tuntun ní ẹ̀ẹ̀kan lójúmọ́, ó sì ń sọ fún ọ nígbà tí ọ̀kan bá wà (pa á ní Ètò > Àtúnṣe). Tẹ Gbà á sílẹ̀, lẹ́yìn náà ṣí fáìlì tí a gbà sílẹ̀ láti fi sí i lórí èyí; ètò rẹ wà bí wọ́n ti wà. Tí o bá fi ìṣàfilọ́lẹ̀ náà sí i láti Google Play, Google Play ni yóò máa ṣe àtúnṣe rẹ̀.

YÍYỌ KÚRÒ
Di àmì ìṣàfilọ́lẹ̀ náà mú kí o sì yan Yọ kúrò. Àwọn fáìlì tí o ti yí padà wà nínú Downloads/Universal Converter.

ÌRÀNLỌ́WỌ́ ÀTI ÀTÌLẸ́YÌN
Ìbéèrè, ìròyìn ìṣòro àti ìbéèrè fún àwọn ẹ̀yà: https://github.com/christzouv/universal-converter/issues
Í-meèlì fún ìbéèrè, èrò àti èdè tí o fẹ́ kí a fi kún un: universal.converter@outlook.com
Ojú-ìwé wẹ́ẹ̀bù: https://christzouv.github.io/universal-converter/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Gbogbo ẹ̀tọ́ wà ní ìpamọ́.