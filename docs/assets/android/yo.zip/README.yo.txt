UNIVERSAL CONVERTER FÚN ANDROID - BÍ A ṢE Ń BẸ̀RẸ̀
Ẹ̀yà 3.5

Universal Converter ń yí àwòrán, ìwé, fídíò àti ohùn padà, ó ń ṣe PDF, ó ń buwọ́lu wọ́n, ó sì ń gbé tábìlì lọ sí Excel. Gbogbo rẹ̀ ń ṣẹlẹ̀ lórí fóònù rẹ: a kò gbé àwọn fáìlì rẹ sókè láé. Ìṣàfilọ́lẹ̀ náà ń lo íńtánẹ́ẹ̀tì láti ṣàyẹ̀wò fún ẹ̀yà tuntun, láti gba àwọn álífábẹ́ẹ̀tì ìdámọ̀ ọ̀rọ̀ tí o yàn sílẹ̀, àti nígbà tí o bá ṣí ìjápọ̀ nìkan. Tí o bá gbà, ó tún ń fi ìròyìn àṣìṣe aláìlórúkọ ránṣẹ́ nígbà tí nǹkan bá bàjẹ́.

OHUN TÍ Ó Ń ṢE
Àwọn ìwé & PDF - Yí padà láàrin PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint àti Excel. Sọ ojú-ìwé di àwòrán, kí o sì da ọ̀pọ̀ fáìlì pọ̀ sínú PDF kan. Lábẹ́ PDF, o lè tan Fún PDF pọ̀ (tẹ ìwọ̀n bíi 500 KB; ọ̀rọ̀ á ṣì mọ́ kedere) àti Ìbuwọ́lù (fi ìbuwọ́lù rẹ sórí PDF kọ̀ọ̀kan). Excel àti CSV ń fa àwọn tábìlì jáde láti inú PDF, àwọn ìwé tí a ṣàyẹ̀wò àti àwọn fọ́tò.
Àwọn àwòrán - Yí padà láàrin JPG, PNG, WEBP, BMP, GIF, TIFF àti ICO. A tún lè ṣí fọ́tò HEIC àti AVIF. Yí ìwọ̀n padà nípasẹ̀ píksẹ́lì, ìpín tàbí ìwọ̀n fáìlì. Sọ àwòrán di PDF tàbí Word, kí o sì ka ọ̀rọ̀ inú àwòrán (OCR). A tún lè fi PDF kún un: ojú-ìwé kọ̀ọ̀kan á di àwòrán.
Fídíò - Yí fídíò padà sí MP4, MKV, WebM tàbí MOV, tàbí ṣe GIF tó ń rìn. MP4, MKV àti MOV ń lo H.264 tàbí H.265 láti ẹ̀rọ ìyípadà hádíwíà fóònù rẹ; WebM ń lo àwọn ìlànà VP9 àti Opus tí ó ṣí sílẹ̀. Yan dídára, ìpinnu àti apá fídíò; gé e, yí i po tàbí yọ ohùn kúrò; tàbí fi ohùn nìkan pamọ́ bí M4A, OGG tàbí WAV.
Fi àwọn férémù pamọ́ - Ní táàbù Fídíò, yan Fi àwọn férémù pamọ́, yan àkókò kí o sì fi àwòrán kan pamọ́ ní ìṣẹ́jú-àáyá díẹ̀ kọ̀ọ̀kan, gbogbo férémù tàbí ẹyọ kan ṣoṣo.
Ìbuwọ́lù - Buwọ́lu PDF kí o sì kún fọ́ọ̀mù. Ṣe ìbuwọ́lù rẹ lẹ́ẹ̀kan – tẹ orúkọ rẹ kí o yan ọ̀nà kíkọ, yà á pẹ̀lú ìka rẹ tàbí gègé, tàbí lo fọ́tò rẹ̀ lórí bébà – lẹ́yìn náà jẹ́ kí ìṣàfilọ́lẹ̀ wá àwọn ìlà ìbuwọ́lù, tàbí tẹ ibi tí ìbuwọ́lù, lẹ́tà àkọ́kọ́ orúkọ, déètì, ọ̀rọ̀ tàbí àmì yẹ kí ó wà lórí ojú-ìwé. A ń buwọ́lu ọ̀pọ̀ fáìlì lẹ́ẹ̀kan; a ń fi ọ̀kọ̀ọ̀kan pamọ́ bí orúkọ_signed.pdf, fáìlì àtilẹ̀wá sì wà bí ó ti wà. Ìbuwọ́lù ẹ̀rọ-ayárabíàṣá tí a lè rí ni èyí, kì í ṣe ìbuwọ́lù oní-nọ́ńbà tí ó ní ìwé-ẹ̀rí.

BÍ A ṢE Ń LÒ Ó
1. Yan táàbù kan ní ìsàlẹ̀ ojú-ìbòjú.
2. Tẹ Fi fáìlì kún un, tàbí pín fáìlì sí Universal Converter láti ìṣàfilọ́lẹ̀ mìíràn.
3. Tẹ ìrísí kan: àwọn àṣàyàn rẹ̀ yóò ṣí sílẹ̀ ní ìsàlẹ̀ rẹ̀ gan-an. Tẹ (i) lẹ́gbẹ̀ẹ́ àṣàyàn kan láti ka ohun tí ó ń ṣe.
4. Tẹ bọ́tìnnì tí ó wà ní ìsàlẹ̀ àwọn àṣàyàn.
A ń fi àwọn èsì pamọ́ sínú Downloads/Universal Converter. Lo Ṣí tàbí Pín láti lò wọ́n lẹ́sẹ̀kẹsẹ̀.
O lè yan ibòmíràn nínú Ètò > Fífi fáìlì pamọ́; áàpù á béèrè lẹ́ẹ̀kan, lẹ́yìn ìyípadà àkọ́kọ́.
Tí o bá fi fáìlì tí táàbù mìíràn ń yí padà kún un, ìṣàfilọ́lẹ̀ náà yóò sọ táàbù wo, yóò sì gbé wọn lọ síbẹ̀ pẹ̀lú títẹ̀ kan.
Ṣé o kò nílò táàbù tàbí ọ̀nà-kíkọ kan? Fi pamọ́ nínú Ètò > Àwọn táàbù àti ọ̀nà-kíkọ.

ÌYÍPADÀ GÍGÙN
O lè kúrò nínú áàpù nígbà tí fídíò bá ń yí padà: ó ń bá iṣẹ́ lọ lẹ́yìn. Àwọn fídíò gígùn tàbí tí ìpinnu wọn ga lè pẹ́ kí wọ́n sì mú fóònù gbóná.

ÌDÁMỌ̀ Ọ̀RỌ̀ (OCR)
Gẹ̀ẹ́sì àti àwọn èdè mìíràn ní álífábẹ́ẹ̀tì Látìn, àti Gíríìkì, wà nínú rẹ̀. Aládàáṣe ń ka àwọn wọ̀nyí àti álífábẹ́ẹ̀tì èyíkéyìí tí o ti gbà sílẹ̀. Láti ka àwọn èdè mìíràn, tẹ Yí padà lẹ́gbẹ̀ẹ́ Àwọn èdè kí o sì sàmì sí àwọn èdè inú fáìlì rẹ: tí ọ̀kan bá nílò álífábẹ́ẹ̀tì tí kò tíì sí lórí fóònù (Kírílíìkì, Lárúbáwá, Ṣáínà, Japanese, Korean, Thai, Hindi, Georgian, Támílì), ìṣàfilọ́lẹ̀ yóò dábàá láti gbà á sílẹ̀ lójú ẹsẹ̀, o sì máa tẹ̀síwájú láti ibi tí o wà. O lè yọ àwọn álífábẹ́ẹ̀tì tí o ti gbà sílẹ̀ kúrò ní Ètò. Tí a kò bá lè ka ọ̀pọ̀ nínú ọ̀rọ̀ náà, ìṣàfilọ́lẹ̀ yóò sọ bẹ́ẹ̀, yóò sì dábàá láti fi álífábẹ́ẹ̀tì kún un. A tún ń ka Hébérù àti Fiẹtnámù: ọ̀kọ̀ọ̀kan yóò gbàsílẹ̀ lẹ́ẹ̀kan, nígbà àkọ́kọ́ tí o bá yàn án. Àwọn ohun tí a ṣàyẹ̀wò àti fọ́ọ̀mù tí a ti kún di ọ̀rọ̀ àti tábìlì tí o lè ṣàtúnṣe, tí a tò bí ojú-ìwé náà (àṣàyàn “Àwọn ojú-ìwé tí ọ̀rọ̀ wọn jẹ́ àwòrán” nínú táàbù “Àwọn ìwé & PDF”).

ÀWỌN ÈDÈ
Gbogbo èdè 22 ló wà nínú rẹ̀: yan ọ̀kan ní Ètò > Èdè ìṣàfilọ́lẹ̀, ìṣàfilọ́lẹ̀ náà yóò sì tún bẹ̀rẹ̀ ní èdè náà. A ń fi Lárúbáwá àti Hébérù hàn láti ọ̀tún sí òsì. Ìṣàfilọ́lẹ̀ náà dúdú ní àkọ́kọ́; yan Ìmọ́lẹ̀ tàbí Bá ti fóònù mu ní Ètò > Ìrísí.

ÀWỌN ÀLÀ LÓRÍ FÓÒNÙ
A kò lè ṣí àwọn fáìlì .doc àti .ppt àtijọ́: kọ́kọ́ fi wọ́n pamọ́ bí .docx tàbí .pptx. A kò tíì lè ka fáìlì .ods, a kò sì tíì lè sọ PDF tí ó ní ọ̀rọ̀ aṣínà di àwòrán. Fáìlì tí ó tóbi gan-an lè kùnà lórí fóònù tí kò ní ìrántí púpọ̀. Àwọn fídíò tí a lè ṣí dá lórí fóònù rẹ.

ÀWỌN ÌMÚDÓJÚÌWỌ̀N
Ìṣàfilọ́lẹ̀ náà ń ṣàyẹ̀wò fún ẹ̀yà tuntun ní ẹ̀ẹ̀kan lójúmọ́, ó sì ń sọ fún ọ nígbà tí ọ̀kan bá wà (pa á ní Ètò > Àwọn ìmúdójúìwọ̀n). Tẹ Gbà á sílẹ̀, lẹ́yìn náà ṣí fáìlì tí a gbà sílẹ̀ láti fi sí i lórí èyí; ètò rẹ wà bí wọ́n ti wà. Tí o bá fi ìṣàfilọ́lẹ̀ náà sí i láti Google Play, Google Play ni yóò máa ṣe ìmúdójúìwọ̀n rẹ̀.

YÍYỌ KÚRÒ
Di àmì áàpù náà mú kí o sì yan Yọ kúrò. Àwọn fáìlì tí o yí padà á wà níbi tí a fi wọ́n pamọ́ sí.

ÌRÀNLỌ́WỌ́ ÀTI ÀTÌLẸ́YÌN
Ìbéèrè, ìròyìn ìṣòro àti ìbéèrè fún àwọn ẹ̀yà: universal.converter@outlook.com
Í-meèlì fún ìbéèrè, èrò àti èdè tí o fẹ́ kí a fi kún un: universal.converter@outlook.com
Ojú-ìwé wẹ́ẹ̀bù: https://christzouv.github.io/universal-converter/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Gbogbo ẹ̀tọ́ wà ní ìpamọ́.