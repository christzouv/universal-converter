UNIVERSAL CONVERTER PARA ANDROID - PRIMEROS PASOS
Versión 3.0

Universal Converter convierte imágenes, documentos, vídeos y audio, crea PDF y pasa tablas a Excel. Todo ocurre en tu móvil: tus archivos nunca se suben a ningún sitio. La aplicación solo usa internet para buscar versiones nuevas, para descargar los idiomas que elijas y cuando abres un enlace. Si lo permite, también envía informes de errores anónimos cuando algo falla.

QUÉ HACE
Documentos y PDF - Convierte entre PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint y Excel. Pasa páginas a imágenes y une varios archivos en un PDF. Comprimir PDF: añade un PDF, elige Comprimir PDF e indica el tamaño que necesitas (p. ej. 500 KB); las imágenes del interior se reducen hasta que cabe y el texto sigue nítido.
Imágenes - Convierte entre JPG, PNG, WEBP, BMP, GIF, TIFF e ICO. También abre fotos HEIC y AVIF. Cambia el tamaño en píxeles, porcentaje o tamaño de archivo. Convierte imágenes en PDF o Word y lee el texto de las imágenes (OCR). También se pueden añadir PDF: cada página se convierte en una imagen.
Vídeo - Convierte vídeos a MP4 o MKV con H.264 o H.265, usando el codificador de hardware del móvil. Elige la calidad, la resolución y la parte del vídeo; recorta, gira o quita el sonido; o guarda solo el sonido en M4A.
Guardar fotogramas - En la pestaña Vídeo, elige Guardar fotogramas, selecciona el intervalo de tiempo y guarda una imagen cada pocos segundos, todos los fotogramas o solo uno.
A Excel - Saca tablas de PDF, escaneos, fotos y archivos de Word a Excel o CSV.
Firmar - Firme PDF y rellene formularios. Cree su firma una vez (escriba su nombre y elija un estilo, dibújela con el ratón o el dedo, o use una foto de ella en papel) y deje que la aplicación encuentre las líneas de firma, o haga clic en la página donde deben ir la firma, las iniciales, la fecha, texto o marcas. Se firman muchos archivos de una vez; cada uno se guarda como nombre_signed.pdf y el original queda como estaba. Es una firma electrónica visible, no una firma digital basada en certificado.

CÓMO SE USA
1. Elige una pestaña en la parte inferior de la pantalla.
2. Pulsa Añadir archivos o comparte archivos con Universal Converter desde otra aplicación.
3. Elige el formato y las opciones. Pulsa la (i) junto a una opción para leer qué hace.
4. Pulsa el botón que hay debajo de las opciones.
Los resultados se guardan en Descargas/Universal Converter. Usa Abrir o Compartir para utilizarlos enseguida.
Si añade archivos que se convierten en otra pestaña, la aplicación le indica cuál y los lleva allí con un toque.

CONVERSIONES LARGAS
Puedes salir de la aplicación mientras se convierte un vídeo. Una notificación indica que sigue trabajando, así que permite las notificaciones cuando se te pida. Los vídeos largos o de alta resolución pueden tardar y calentar el móvil.

RECONOCIMIENTO DE TEXTO (OCR)
El inglés y los demás idiomas con alfabeto latino, y el griego, vienen incluidos. Automático lee estos y cualquier alfabeto que haya descargado; elegir uno lee más rápido. Otros alfabetos (cirílico, árabe, chino, japonés, coreano, tailandés, hindi, georgiano, tamil) se descargan en Ajustes y luego se eligen en cada pestaña. Si gran parte del texto no se puede leer, la aplicación lo indica y ofrece añadir un alfabeto. El texto en hebreo aún no se puede reconocer.

IDIOMAS
El inglés y el griego vienen incluidos. Español, italiano, alemán, francés, portugués, polaco, ruso, árabe, hebreo, chino, japonés, coreano, tamil, afrikáans, yoruba y hausa se descargan al elegirlos en Ajustes, y la aplicación se reinicia para usarlos. La aplicación es oscura por defecto; elija Claro o Igual que el teléfono en Ajustes > Apariencia.

LÍMITES EN UN MÓVIL
Los archivos .doc y .ppt antiguos no se pueden abrir: guárdalos primero como .docx o .pptx. Los archivos .ods aún no se pueden leer, y los PDF protegidos con contraseña aún no se pueden convertir en imágenes. Los archivos muy grandes pueden fallar en móviles con poca memoria. Los vídeos que se pueden abrir dependen de tu móvil.

ACTUALIZACIONES
La aplicación busca una versión nueva aproximadamente una vez al día y te avisa cuando la hay (puedes desactivarlo en Ajustes > Actualizaciones). Pulsa Descargar y abre el archivo descargado para instalarlo sobre esta versión; tus ajustes se mantienen. Si instaló la aplicación desde Google Play, es Google Play quien la actualiza.

DESINSTALAR
Mantén pulsado el icono de la aplicación y elige Desinstalar. Los archivos que convertiste se quedan en Descargas/Universal Converter.

AYUDA Y SOPORTE
Preguntas, informes de problemas y peticiones de funciones: https://github.com/christzouv/universal-converter/issues
Correo para preguntas, ideas e idiomas que le gustaría añadir: universal.converter@outlook.com
Sitio web: https://christzouv.github.io/universal-converter/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Todos los derechos reservados.
