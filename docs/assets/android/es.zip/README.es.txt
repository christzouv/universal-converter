UNIVERSAL CONVERTER PARA ANDROID - PRIMEROS PASOS
Versión 3.5

Universal Converter convierte imágenes, documentos, vídeos y audio, crea y firma PDF y pasa tablas a Excel. Todo ocurre en tu móvil: tus archivos nunca se suben a ningún sitio. La aplicación solo usa internet para buscar versiones nuevas, para descargar los alfabetos de reconocimiento de texto que elijas y cuando abres un enlace. Si lo permites, también envía informes de errores anónimos cuando algo falla.

QUÉ HACE
Documentos y PDF - Convierte entre PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint y Excel. Pasa páginas a imágenes y une varios archivos en un PDF. En PDF puedes activar Comprimir PDF (indica un tamaño, p. ej. 500 KB; el texto sigue nítido) y Firmar (coloca tu firma en cada PDF). Excel y CSV extraen tablas de PDF, escaneos y fotos.
Imágenes - Convierte entre JPG, PNG, WEBP, BMP, GIF, TIFF e ICO. También abre fotos HEIC y AVIF. Cambia el tamaño en píxeles, porcentaje o tamaño de archivo. Convierte imágenes en PDF o Word y lee el texto de las imágenes (OCR). También se pueden añadir PDF: cada página se convierte en una imagen.
Vídeo - Convierte vídeos a MP4, MKV, WebM o MOV, o crea un GIF animado. MP4, MKV y MOV usan H.264 o H.265 con el codificador de hardware del móvil; WebM usa los formatos abiertos VP9 y Opus. Elige la calidad, la resolución y la parte del vídeo; recorta, gira o quita el sonido; o guarda solo el sonido en M4A, OGG o WAV.
Guardar fotogramas - En la pestaña Vídeo, elige Guardar fotogramas, selecciona el intervalo de tiempo y guarda una imagen cada pocos segundos, todos los fotogramas o solo uno.
Firmar - Firma PDF y rellena formularios. Crea tu firma una vez (escribe tu nombre y elige un estilo, dibújala con el dedo o un lápiz, o usa una foto de ella en papel) y deja que la aplicación encuentre las líneas de firma, o toca la página donde deben ir la firma, las iniciales, la fecha, texto o marcas. Se firman muchos archivos de una vez; cada uno se guarda como nombre_signed.pdf y el original queda como estaba. Es una firma electrónica visible, no una firma digital basada en certificado.

CÓMO SE USA
1. Elige una pestaña en la parte inferior de la pantalla.
2. Pulsa Añadir archivos o comparte archivos con Universal Converter desde otra aplicación.
3. Toca un formato: sus opciones se abren justo debajo. Pulsa la (i) junto a una opción para leer qué hace.
4. Pulsa el botón que hay debajo de las opciones.
Los resultados se guardan en Descargas/Universal Converter. Usa Abrir o Compartir para utilizarlos enseguida.
Puedes elegir otro lugar en Ajustes > Guardar archivos; la app lo pregunta una vez, tras la primera conversión.
Si añade archivos que se convierten en otra pestaña, la aplicación le indica cuál y los lleva allí con un toque.
¿No necesitas una pestaña o un formato? Ocúltalo en Ajustes > Pestañas y formatos.

CONVERSIONES LARGAS
Puedes salir de la app mientras se convierte un vídeo: sigue trabajando en segundo plano. Los vídeos largos o de alta resolución pueden tardar y calentar el teléfono.

RECONOCIMIENTO DE TEXTO (OCR)
El inglés y los demás idiomas con alfabeto latino, y el griego, vienen incluidos. Automático lee estos y cualquier alfabeto que hayas descargado. Para leer otros idiomas, toca Cambiar junto a Idiomas y marca los idiomas de tus archivos: si alguno necesita un alfabeto que aún no está en el móvil (cirílico, árabe, chino, japonés, coreano, tailandés, hindi, georgiano, tamil), la aplicación te ofrece descargarlo al momento y sigues donde estabas. Los alfabetos descargados se pueden quitar en Ajustes. Si gran parte del texto no se puede leer, la aplicación lo indica y ofrece añadir un alfabeto. También se leen el hebreo y el vietnamita: cada uno se descarga una sola vez, la primera vez que se elige. Los escaneos y formularios rellenados se convierten en texto y tablas editables, colocados como en la página (opción «Páginas con imágenes de texto» en la pestaña Documentos y PDF).

IDIOMAS
Los 22 idiomas vienen incluidos: elige uno en Ajustes > Idioma de la aplicación y la aplicación se reinicia en ese idioma. El árabe y el hebreo se muestran de derecha a izquierda. La aplicación es oscura por defecto; elige Claro o Como el teléfono en Ajustes > Apariencia.

LÍMITES EN UN MÓVIL
Los archivos .doc y .ppt antiguos no se pueden abrir: guárdalos primero como .docx o .pptx. Los archivos .ods aún no se pueden leer, y los PDF protegidos con contraseña aún no se pueden convertir en imágenes. Los archivos muy grandes pueden fallar en móviles con poca memoria. Los vídeos que se pueden abrir dependen de tu móvil.

ACTUALIZACIONES
La aplicación busca una versión nueva aproximadamente una vez al día y te avisa cuando la hay (puedes desactivarlo en Ajustes > Actualizaciones). Toca Descargar y abre el archivo descargado para instalarlo sobre esta versión; tus ajustes se mantienen. Si instalaste la aplicación desde Google Play, es Google Play quien la actualiza.

DESINSTALAR
Mantén pulsado el icono de la app y elige Desinstalar. Los archivos que convertiste se quedan donde se guardaron.

AYUDA Y SOPORTE
Preguntas, informes de problemas y peticiones de funciones: universal.converter@outlook.com
Correo para preguntas, ideas e idiomas que le gustaría añadir: universal.converter@outlook.com
Sitio web: https://christzouv.github.io/universal-converter/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Todos los derechos reservados.
