UNIVERSAL CONVERTER PARA ANDROID - PRIMEROS PASOS
Versión 4.0

Universal Converter convierte imágenes, documentos, vídeos y audio, crea y firma PDF y pasa tablas a Excel. Todo ocurre en tu móvil: tus archivos nunca se suben a ningún sitio. La aplicación solo usa internet para buscar versiones nuevas, para descargar los alfabetos de reconocimiento de texto que elijas y cuando abres un enlace. Si lo permites, también envía informes de errores anónimos cuando algo falla.

QUÉ HACE
Documentos y PDF - Convierte entre PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint y Excel. Pasa páginas a imágenes y une varios archivos en un PDF. En PDF puedes activar Comprimir PDF (indica un tamaño, p. ej. 500 KB; el texto sigue nítido) y Firmar (coloca tu firma en cada PDF). Excel y CSV extraen tablas de PDF, escaneos y fotos.
Imágenes - Convierte entre JPG, PNG, WEBP, BMP, GIF, TIFF e ICO. También abre fotos HEIC y AVIF. Cambia el tamaño en píxeles, porcentaje o tamaño de archivo. Convierte imágenes en PDF o Word y lee el texto de las imágenes (OCR). También se pueden añadir PDF: cada página se convierte en una imagen.
Vídeo - Convierte vídeos a MP4, MKV, WebM o MOV, o crea un GIF animado. MP4, MKV y MOV usan H.264 o H.265 con el codificador de hardware del móvil; WebM usa los formatos abiertos VP9 y Opus. Elige la calidad, la resolución y la parte del vídeo; recorta, gira o quita el sonido; o guarda solo el sonido en MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF o MKA. Con varios vídeos en la lista, toque uno para darle sus propios ajustes, o cópielos a todos.
Guardar fotogramas - En la pestaña Vídeo, elige Guardar fotogramas, selecciona el intervalo de tiempo y guarda una imagen cada pocos segundos, todos los fotogramas o solo uno.
Firmar - Firma PDF y rellena formularios. Crea tu firma una vez (escribe tu nombre y elige un estilo, dibújala con el dedo o un lápiz, o usa una foto de ella en papel) y deja que la aplicación encuentre las líneas de firma, o toca la página donde deben ir la firma, las iniciales, la fecha, texto o marcas. Se firman muchos archivos de una vez; cada uno se guarda como nombre_signed.pdf y el original queda como estaba. Es una firma electrónica visible, no una firma digital basada en certificado.

CÓMO SE USA
1. Pulsa Añadir archivos o comparte archivos con Universal Converter desde otra aplicación.
2. Toca un archivo de la lista: se abren sus propias opciones.
3. Toca un formato: sus opciones se abren justo debajo. Pulsa la (i) junto a una opción para leer qué hace.
4. Vuelve a la lista y toca Convertir: se convierte cada archivo.
Los resultados se guardan en Descargas/Universal Converter. Usa Abrir o Compartir para utilizarlos enseguida.
Puedes elegir otro lugar en Ajustes > Ubicación de guardado predeterminada; la app lo pregunta una vez, tras la primera conversión.
Cada archivo tiene sus propios ajustes: cópialos del archivo anterior de su formato o a cada archivo de ese formato; «Archivo siguiente» te lleva al siguiente.
¿No necesitas un formato? Ocúltalo en Ajustes > Formatos. Los archivos sin formato elegido reciben el predeterminado (Ajustes > Formatos predeterminados).
El menú ☰ de arriba a la izquierda abre Ajustes, esta guía, Novedades y correcciones y Apoyar; Ajustes también está arriba a la derecha.

CONVERSIONES LARGAS
Puedes salir de la app mientras se convierte un vídeo: sigue trabajando en segundo plano. Los vídeos largos o de alta resolución pueden tardar y calentar el teléfono. Si quieres, Ajustes > Notificaciones te avisa cuando termina una conversión. Agita el teléfono con fuerza para empezar a Convertir (Ajustes > Agitar para convertir).

RECONOCIMIENTO DE TEXTO (OCR)
El inglés y los demás idiomas con alfabeto latino, y el griego, vienen incluidos. Automático lee estos y cualquier alfabeto que hayas descargado. Para leer otros idiomas, toca Cambiar junto a Idiomas y marca los idiomas de tus archivos: si alguno necesita un alfabeto que aún no está en el móvil (cirílico, árabe, chino, japonés, coreano, tailandés, hindi, georgiano, tamil), la aplicación te ofrece descargarlo al momento y sigues donde estabas. Los alfabetos descargados se pueden quitar en Ajustes. Si gran parte del texto no se puede leer, la aplicación lo indica y ofrece añadir un alfabeto. También se leen el hebreo y el vietnamita: cada uno se descarga una sola vez, la primera vez que se elige. Los escaneos y formularios rellenados se convierten en texto y tablas editables, colocados como en la página (opción «Páginas con imágenes de texto» en las opciones de un PDF).

IDIOMAS
Los 34 idiomas vienen incluidos: elige uno en Ajustes > Idioma de la aplicación y la aplicación se reinicia en ese idioma. El árabe y el hebreo se muestran de derecha a izquierda. La aplicación es oscura por defecto; elige Claro o Como el teléfono en Ajustes > Apariencia.

LÍMITES EN UN MÓVIL
Los archivos muy grandes pueden fallar en móviles con poca memoria. Los vídeos que se pueden abrir dependen de tu móvil.

ACTUALIZACIONES
La aplicación busca una versión nueva aproximadamente una vez al día y te avisa cuando la hay (puedes desactivarlo en Ajustes > Actualizaciones). Toca Descargar y abre el archivo descargado para instalarlo sobre esta versión; tus ajustes se mantienen. Si instalaste la aplicación desde Google Play, es Google Play quien la actualiza.

DESINSTALAR
Mantén pulsado el icono de la app y elige Desinstalar. Los archivos que convertiste se quedan donde se guardaron.

AYUDA Y SOPORTE
Preguntas, informes de problemas y peticiones de funciones: universal.converter@outlook.com
Correo para preguntas, ideas e idiomas que le gustaría añadir: universal.converter@outlook.com
Sitio web: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Todos los derechos reservados.
