UNIVERSAL CONVERTER PARA SA ANDROID - PAGSISIMULA
Bersyon 4.0

Kino-convert ng Universal Converter ang mga larawan, dokumento, video at audio, gumagawa ng mga PDF at naglilipat ng mga table sa Excel. Lahat ay nangyayari sa telepono mo: hindi kailanman ina-upload ang mga file mo. Gumagamit lang ng internet ang app para tumingin ng bagong bersyon, para i-download ang mga alpabeto ng pagkilala ng teksto na pipiliin mo, at kapag nagbukas ka ng link. Kung papayagan mo, nagpapadala rin ito ng mga hindi nagpapakilalang ulat ng error kapag may nagkamali.

ANO ANG GINAGAWA NITO
Mga Dokumento at PDF - Mag-convert sa pagitan ng PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint at Excel. Gawing larawan ang mga pahina, at pagsamahin ang ilang file sa isang PDF. Sa ilalim ng PDF, puwede mong i-on ang I-compress ang PDF (maglagay ng laki tulad ng 500 KB; nananatiling matalas ang teksto) at Pirma (ilagay ang pirma mo sa bawat PDF). Kinukuha ng Excel at CSV ang mga table mula sa mga PDF, scan at larawan.
Mga Larawan - Mag-convert sa pagitan ng JPG, PNG, WEBP, BMP, GIF, TIFF at ICO. Nabubuksan din ang mga larawang HEIC at AVIF. Baguhin ang laki ayon sa pixel, porsyento o laki ng file. Gawing PDF o Word ang mga larawan, at basahin ang teksto sa mga larawan (OCR). Puwede ring magdagdag ng mga PDF: nagiging larawan ang bawat pahina.
Video - Mag-convert ng mga video sa MP4, MKV, WebM o MOV, o gumawa ng animated na GIF. Gumagamit ang MP4, MKV at MOV ng H.264 o H.265 mula sa hardware encoder ng telepono mo; gumagamit ang WebM ng mga bukas na format na VP9 at Opus. Piliin ang kalidad, resolution at bahagi ng video; i-crop, iikot o alisin ang tunog; o i-save ang tunog lang bilang MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF o MKA. Kapag maraming video sa listahan, i-tap ang isa para bigyan ito ng sariling mga setting, o kopyahin ang mga ito sa lahat.
I-save ang mga frame - Sa tab na Video, piliin ang I-save ang mga frame, piliin ang saklaw ng oras at mag-save ng isang larawan bawat ilang segundo, bawat frame o isa lang.
Pirma - Pumirma sa mga PDF at sagutan ang mga form. Gawin minsan ang pirma mo - i-type ang pangalan mo at pumili ng istilo, iguhit ito gamit ang daliri o pen, o gumamit ng larawan nito sa papel - saka hayaan ang app na hanapin ang mga linya ng pirma, o i-tap ang pahina kung saan dapat ilagay ang pirma, inisyal, petsa, teksto o tsek. Maraming file ang napipirmahan nang sabay-sabay; sine-save ang bawat isa bilang pangalan_signed.pdf at nananatili ang orihinal kung ano ito. Isa itong nakikitang electronic signature, hindi digital signature na batay sa certificate.

PAANO GAMITIN
1. I-tap ang Magdagdag ng mga file, o i-share ang mga file sa Universal Converter mula sa ibang app.
2. I-tap ang isang file sa listahan: bubukas ang sarili nitong mga opsyon.
3. I-tap ang isang format: bubukas agad sa ilalim nito ang mga opsyon. I-tap ang (i) sa tabi ng isang opsyon para mabasa kung ano ang ginagawa nito.
4. Bumalik sa listahan at i-tap ang I-convert: iko-convert ang bawat file.
Sine-save ang mga resulta sa Downloads/Universal Converter. Gamitin ang Buksan o Ibahagi para magamit agad ang mga ito.
Puwede kang pumili ng ibang lugar sa Mga Setting > Default na lokasyon ng pag-save; minsan lang magtatanong ang app, pagkatapos ng una mong conversion.
May sariling mga setting ang bawat file: kopyahin ang mga ito mula sa naunang file na kapareho ng format o sa bawat file ng format na iyon; dadalhin ka ng «Susunod na file» sa kasunod.
Hindi mo kailangan ang isang format? Itago ito sa Mga Setting > Mga format. Ang mga file na walang napiling format ay kumukuha ng default (Mga Setting > Mga default na format).
Binubuksan ng menu na ☰ sa kaliwang itaas ang Mga Setting, ang gabay na ito, Ano ang bago at naayos at Suporta; nasa kanang itaas din ang Mga Setting.

MAHAHABANG CONVERSION
Puwede mong iwan ang app habang kino-convert ang isang video: tuloy ang trabaho nito sa background. Puwedeng matagalan ang mahahaba o mataas na resolution na video at uminit ang telepono. Kung gusto mo, sasabihan ka ng Mga Setting > Mga Notification kapag tapos na ang conversion. I-shake nang malakas ang telepono para simulan ang I-convert (Mga Setting > I-shake para mag-convert).

PAGKILALA NG TEKSTO (OCR)
Kasama na sa app ang English at iba pang wikang may alpabetong Latin, pati Greek. Binabasa ng Awtomatiko ang mga ito at anumang alpabetong na-download mo. Para mabasa ang ibang wika, i-tap ang Baguhin sa tabi ng Mga Wika at lagyan ng tsek ang mga wika sa mga file mo: kung kailangan ng isa ang alpabetong wala pa sa telepono (Cyrillic, Arabic, Chinese, Japanese, Korean, Thai, Hindi, Georgian, Tamil), mag-aalok ang app na i-download ito agad, at magpapatuloy ka kung saan ka huminto. Puwedeng alisin sa Mga Setting ang mga na-download na alpabeto. Kung hindi mabasa ang malaking bahagi ng teksto, sasabihin ito ng app at mag-aalok na magdagdag ng alpabeto. Nababasa rin ang Hebrew at Vietnamese: minsan lang dina-download ang bawat isa, sa unang beses mong piliin. Nagiging tekstong mae-edit at mga table ang mga scan at nasagutang form, nakaayos tulad ng pahina (opsyong "Mga pahinang may larawan ng teksto" sa mga opsyon ng isang PDF).

MGA WIKA
Kasama na sa app ang lahat ng 34 na wika: pumili ng isa sa Mga Setting > Wika ng app, at magre-restart ang app sa wikang iyon. Ipinapakita mula kanan pakaliwa ang Arabic at Hebrew. Madilim ang app bilang default; piliin ang Maliwanag o Kapareho ng telepono sa Mga Setting > Hitsura.

MGA LIMITASYON SA TELEPONO
Puwedeng pumalya ang napakalalaking file sa mga teleponong kaunti ang memory. Nakadepende sa telepono mo kung aling mga video ang mabubuksan.

MGA UPDATE
Tumitingin ang app ng bagong bersyon mga isang beses sa isang araw at sasabihin sa iyo kapag mayroon (i-off ito sa Mga Setting > Mga Update). I-tap ang I-download, saka buksan ang na-download na file para i-install ito sa ibabaw ng bersyong ito; mananatili ang mga setting mo. Kung in-install mo ang app mula sa Google Play, ang Google Play ang mag-a-update dito.

PAG-UNINSTALL
Pindutin nang matagal ang icon ng app at piliin ang I-uninstall. Mananatili ang mga file na na-convert mo kung saan sila na-save.

TULONG AT SUPORTA
Mga tanong, ulat ng problema at hiling na feature: universal.converter@outlook.com
Email para sa mga tanong, ideya at wikang gusto mong idagdag: universal.converter@outlook.com
Website: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Nakalaan ang lahat ng karapatan.
