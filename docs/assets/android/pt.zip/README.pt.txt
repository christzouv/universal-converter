UNIVERSAL CONVERTER PARA ANDROID - PRIMEIROS PASSOS
Versão 3.0

O Universal Converter converte imagens, documentos, vídeos e áudio, cria PDF e passa tabelas para Excel. Tudo acontece no seu telemóvel: os seus ficheiros nunca são enviados para lado nenhum. A aplicação só usa a internet para procurar novas versões, para transferir os idiomas que escolher e quando abre uma ligação. Se o permitir, também envia relatórios de erros anónimos quando algo corre mal.

O QUE FAZ
Documentos e PDF - Converte entre PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint e Excel. Transforma páginas em imagens e junta vários ficheiros num PDF. Comprimir PDF: adicione um PDF, escolha Comprimir PDF e indique o tamanho de que precisa (p. ex. 500 KB); as imagens no interior são reduzidas até caber e o texto continua nítido.
Imagens - Converte entre JPG, PNG, WEBP, BMP, GIF, TIFF e ICO. Também abre fotos HEIC e AVIF. Redimensiona em píxeis, percentagem ou tamanho do ficheiro. Transforma imagens em PDF ou Word e lê o texto das imagens (OCR). Também pode adicionar PDF: cada página torna-se uma imagem.
Vídeo - Converte vídeos para MP4 ou MKV com H.264 ou H.265, usando o codificador de hardware do telemóvel. Escolha a qualidade, a resolução e a parte do vídeo; recorte, rode ou remova o som; ou guarde só o som em M4A.
Guardar imagens do vídeo - No separador Vídeo, escolha Guardar imagens do vídeo, selecione o intervalo de tempo e guarde uma imagem a cada poucos segundos, todas as imagens ou só uma.
Para Excel - Passa tabelas de PDF, digitalizações, fotos e ficheiros Word para Excel ou CSV.
Assinar - Assine PDF e preencha formulários. Crie a sua assinatura uma vez (escreva o seu nome e escolha um estilo, desenhe-a com o rato ou o dedo, ou use uma foto dela em papel) e deixe a aplicação encontrar as linhas de assinatura, ou clique na página onde devem ficar a assinatura, as iniciais, a data, texto ou visto. Muitos ficheiros são assinados de uma só vez; cada um é guardado como nome_signed.pdf e o original fica como estava. É uma assinatura eletrónica visível, não uma assinatura digital com certificado.

COMO USAR
1. Escolha um separador na parte inferior do ecrã.
2. Toque em Adicionar ficheiros ou partilhe ficheiros com o Universal Converter a partir de outra aplicação.
3. Escolha o formato e as opções. Toque no (i) junto a uma opção para ler o que faz.
4. Toque no botão por baixo das opções.
Os resultados são guardados em Transferências/Universal Converter. Use Abrir ou Partilhar para os usar logo.
Se adicionar ficheiros que são convertidos noutro separador, a app indica qual e leva-os para lá com um toque.

CONVERSÕES LONGAS
Pode sair da aplicação enquanto um vídeo é convertido. Uma notificação mostra que continua a trabalhar, por isso permita as notificações quando lhe for pedido. Vídeos longos ou de alta resolução podem demorar e aquecer o telemóvel.

RECONHECIMENTO DE TEXTO (OCR)
O inglês e as outras línguas com alfabeto latino, e o grego, vêm incluídos. Automático lê estes e qualquer alfabeto que tenha transferido; escolher um lê mais depressa. Outros alfabetos (cirílico, árabe, chinês, japonês, coreano, tailandês, hindi, georgiano, tâmil) transferem-se nas Definições e depois escolhem-se em cada separador. Se grande parte do texto não puder ser lida, a aplicação diz-o e propõe adicionar um alfabeto. O texto em hebraico ainda não pode ser reconhecido.

IDIOMAS
O inglês e o grego vêm incluídos. Espanhol, italiano, alemão, francês, português, polaco, russo, árabe, hebraico, chinês, japonês, coreano, tâmil, africâner, iorubá e haúça são transferidos quando os escolhe nas Definições, e a aplicação reinicia para os usar. A aplicação é escura por predefinição; escolha Claro ou Igual ao telefone em Definições > Aspeto.

LIMITES NUM TELEMÓVEL
Os ficheiros .doc e .ppt antigos não abrem: guarde-os primeiro como .docx ou .pptx. Os ficheiros .ods ainda não podem ser lidos e os PDF protegidos por palavra-passe ainda não podem ser transformados em imagens. Ficheiros muito grandes podem falhar em telemóveis com pouca memória. Os vídeos que abrem dependem do seu telemóvel.

ATUALIZAÇÕES
A aplicação procura uma nova versão cerca de uma vez por dia e avisa quando existe (pode desativar em Definições > Atualizações). Toque em Transferir e abra o ficheiro transferido para o instalar sobre esta versão; as suas definições mantêm-se. Se instalou a aplicação a partir do Google Play, é o Google Play que a atualiza.

DESINSTALAR
Mantenha premido o ícone da aplicação e escolha Desinstalar. Os ficheiros convertidos ficam em Transferências/Universal Converter.

AJUDA E SUPORTE
Perguntas, relatórios de problemas e pedidos de funcionalidades: https://github.com/christzouv/universal-converter/issues
Email para perguntas, ideias e idiomas que gostaria de ver adicionados: universal.converter@outlook.com
Site: https://christzouv.github.io/universal-converter/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Todos os direitos reservados.
