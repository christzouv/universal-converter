ANDROID İÇİN UNIVERSAL CONVERTER - BAŞLARKEN
Sürüm 4.0

Universal Converter resimleri, belgeleri, videoları ve sesleri dönüştürür, PDF oluşturur ve tabloları Excel'e aktarır. Her şey telefonunuzda olur: dosyalarınız asla yüklenmez. Uygulama interneti yalnızca yeni sürümleri denetlemek, seçtiğiniz metin tanıma alfabelerini indirmek ve bir bağlantı açtığınızda kullanır. İzin verirseniz bir sorun çıktığında anonim hata raporları da gönderir.

NELER YAPAR
Belgeler ve PDF - PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint ve Excel arasında dönüştürün. Sayfaları resme çevirin ve birkaç dosyayı tek PDF'de birleştirin. PDF altında PDF sıkıştırmayı (500 KB gibi bir boyut girin; metin net kalır) ve İmzala'yı (her PDF'ye imzanızı ekleyin) açabilirsiniz. Excel ve CSV; PDF'lerden, taramalardan ve fotoğraflardan tabloları çıkarır.
Resimler - JPG, PNG, WEBP, BMP, GIF, TIFF ve ICO arasında dönüştürün. HEIC ve AVIF fotoğraflar da açılabilir. Piksel, yüzde veya dosya boyutuna göre yeniden boyutlandırın. Resimleri PDF'ye veya Word'e çevirin ve resimlerdeki metni okuyun (OCR). PDF de eklenebilir: her sayfa bir resim olur.
Video - Videoları MP4, MKV, WebM veya MOV'a dönüştürün ya da hareketli GIF yapın. MP4, MKV ve MOV telefonunuzun donanım kodlayıcısıyla H.264 veya H.265 kullanır; WebM açık VP9 ve Opus biçimlerini kullanır. Kaliteyi, çözünürlüğü ve videonun hangi kısmının dönüştürüleceğini seçin; kırpın, döndürün ya da sesi kaldırın; ya da yalnızca sesi MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF veya MKA olarak kaydedin. Listede birden çok video varsa birine dokunup ona kendi ayarlarını verin ya da ayarları hepsine kopyalayın.
Kareleri kaydet - Video sekmesinde Kareleri kaydet'i seçin, zaman aralığını belirleyin ve birkaç saniyede bir resim, her kareyi ya da yalnızca bir kareyi kaydedin.
İmzala - PDF'leri imzalayın ve formları doldurun. İmzanızı bir kez oluşturun - adınızı yazıp bir stil seçin, parmağınızla ya da bir kalemle çizin veya kâğıttaki imzanızın fotoğrafını kullanın - sonra uygulamanın imza çizgilerini bulmasına izin verin ya da sayfada imzanın, parafın, tarihin, metnin veya onay işaretlerinin gideceği yere dokunun. Birçok dosya tek seferde imzalanır; her biri ad_signed.pdf olarak kaydedilir ve orijinal olduğu gibi kalır. Bu, görünür bir elektronik imzadır; sertifikaya dayalı bir dijital imza değildir.

NASIL KULLANILIR
1. Dosya ekle'ye dokunun ya da başka bir uygulamadan dosyaları Universal Converter ile paylaşın.
2. Listede bir dosyaya dokunun: kendi seçenekleri açılır.
3. Bir biçime dokunun: seçenekleri hemen altında açılır. Bir seçeneğin ne yaptığını okumak için yanındaki (i) simgesine dokunun.
4. Listeye dönün ve Dönüştür'e dokunun: her dosya dönüştürülür.
Sonuçlar Downloads/Universal Converter klasörüne kaydedilir. Hemen kullanmak için Aç veya Paylaş'ı kullanın.
Başka bir yeri Ayarlar > Varsayılan kaydetme konumu'den seçebilirsiniz; uygulama ilk dönüştürmeden sonra bir kez sorar.
Her dosyanın kendi ayarları vardır: aynı biçimdeki önceki dosyadan kopyalayın ya da o biçimdeki her dosyaya kopyalayın; «Sonraki dosya» sizi bir sonrakine götürür.
Bir biçime ihtiyacınız yok mu? Ayarlar > Biçimler'de gizleyin. Biçim seçilmemiş dosyalar varsayılanı alır (Ayarlar > Varsayılan biçimler).
Sol üstteki ☰ menüsü Ayarlar'ı, bu kılavuzu, Yenilikler ve düzeltmeler'i ve Destek'i açar; Ayarlar sağ üstte de bulunur.

UZUN DÖNÜŞTÜRMELER
Bir video dönüştürülürken uygulamadan çıkabilirsiniz: arka planda çalışmaya devam eder. Uzun veya yüksek çözünürlüklü videolar zaman alabilir ve telefonu ısıtabilir. İsterseniz Ayarlar > Bildirimler, bir dönüştürme bitince size haber verir. Dönüştür'ü başlatmak için telefonu kuvvetlice sallayın (Ayarlar > Dönüştürmek için salla).

METİN TANIMA (OCR)
İngilizce ve Latin alfabesi kullanan diğer diller (Türkçe ve Endonezce gibi) ile Yunanca uygulamada yerleşiktir. Otomatik, bunları ve indirdiğiniz her alfabeyi okur. Başka dilleri okumak için Diller'in yanındaki Değiştir'e dokunun ve dosyalarınızdaki dilleri işaretleyin: biri telefonda henüz olmayan bir alfabe gerektiriyorsa (Kiril, Arap, Çin, Japon, Kore, Tay, Devanagari - Hintçe için, Gürcü, Tamil), uygulama onu hemen indirmeyi önerir ve kaldığınız yerden devam edersiniz. İndirilen alfabeler Ayarlar'dan kaldırılabilir. Metnin büyük kısmı okunamazsa uygulama bunu söyler ve bir alfabe eklemeyi önerir. İbranice ve Vietnamca da okunur: her biri ilk seçtiğinizde bir kez indirilir. Taramalar ve doldurulmuş formlar, sayfadaki gibi yerleştirilmiş düzenlenebilir metin ve tablolara dönüşür (bir PDF'nin seçeneklerindeki "Metni resim olarak içeren sayfalar" seçeneği).

DİLLER
34 dilin tamamı uygulamada yerleşiktir: Ayarlar > Uygulama dili bölümünden birini seçin, uygulama o dilde yeniden başlar. Arapça ve İbranice sağdan sola gösterilir. Uygulama varsayılan olarak koyudur; Ayarlar > Görünüm bölümünden Açık'ı veya Telefona uy'u seçin.

TELEFONDAKİ SINIRLAR
Çok büyük dosyalar belleği az olan telefonlarda başarısız olabilir. Hangi videoların açılabileceği telefonunuza bağlıdır.

GÜNCELLEMELER
Uygulama yaklaşık günde bir yeni sürüm denetler ve varsa size bildirir (Ayarlar > Güncellemeler bölümünden kapatabilirsiniz). İndir'e dokunun, ardından bu sürümün üzerine yüklemek için indirilen dosyayı açın; ayarlarınız korunur. Uygulamayı Google Play'den yüklediyseniz onu Google Play günceller.

KALDIRMA
Uygulama simgesine basılı tutun ve Kaldır'ı seçin. Dönüştürdüğünüz dosyalar kaydedildikleri yerde kalır.

YARDIM VE DESTEK
Sorular, sorun bildirimleri ve özellik istekleri: universal.converter@outlook.com
Sorular, fikirler ve eklenmesini istediğiniz diller için e-posta: universal.converter@outlook.com
Web sitesi: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Tüm hakları saklıdır.
