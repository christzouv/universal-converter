UNIVERSAL CONVERTER UNTUK ANDROID - MEMULAI
Versi 4.0

Universal Converter mengonversi gambar, dokumen, video, dan audio, membuat PDF, dan mengambil tabel ke Excel. Semuanya berlangsung di ponsel Anda: file Anda tidak pernah diunggah. Aplikasi hanya memakai internet untuk memeriksa versi baru, mengunduh aksara pengenalan teks yang Anda pilih, dan saat Anda membuka tautan. Jika Anda mengizinkan, aplikasi juga mengirim laporan kesalahan anonim saat terjadi masalah.

YANG DAPAT DILAKUKANNYA
Dokumen & PDF - Konversi antar PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint, dan Excel. Ubah halaman menjadi gambar, dan gabungkan beberapa file menjadi satu PDF. Di PDF Anda bisa mengaktifkan Kompres PDF (masukkan ukuran seperti 500 KB; teks tetap tajam) dan Tanda tangan (tempatkan tanda tangan di setiap PDF). Excel dan CSV mengambil tabel dari PDF, hasil pindaian, dan foto.
Gambar - Konversi antar JPG, PNG, WEBP, BMP, GIF, TIFF, dan ICO. Foto HEIC dan AVIF juga dapat dibuka. Ubah ukuran berdasarkan piksel, persen, atau ukuran file. Ubah gambar menjadi PDF atau Word, dan baca teks dalam gambar (OCR). PDF juga dapat ditambahkan: setiap halaman menjadi gambar.
Video - Konversi video ke MP4, MKV, WebM, atau MOV, atau buat GIF animasi. MP4, MKV, dan MOV memakai H.264 atau H.265 dari encoder perangkat keras ponsel Anda; WebM memakai format terbuka VP9 dan Opus. Pilih kualitas, resolusi, dan bagian video; potong, putar, atau hapus suara; atau simpan suaranya saja sebagai MP3, M4A, AAC, OGG, Opus, FLAC, WAV, AIFF, atau MKA. Jika ada beberapa video di daftar, ketuk salah satunya untuk memberinya pengaturan sendiri, atau salin pengaturan itu ke semua.
Simpan bingkai - Di tab Video, pilih Simpan bingkai, tentukan rentang waktunya, lalu simpan satu gambar setiap beberapa detik, setiap bingkai, atau hanya satu.
Tanda tangan - Tanda tangani PDF dan isi formulir. Buat tanda tangan Anda sekali - ketik nama Anda dan pilih gaya, gambar dengan jari atau pena, atau pakai fotonya di atas kertas - lalu biarkan aplikasi menemukan garis tanda tangan, atau ketuk halaman di tempat tanda tangan, paraf, tanggal, teks, atau centang diletakkan. Banyak file ditandatangani sekaligus; masing-masing disimpan sebagai nama_signed.pdf dan file aslinya tetap seperti semula. Ini adalah tanda tangan elektronik yang terlihat, bukan tanda tangan digital berbasis sertifikat.

CARA PAKAI
1. Ketuk Tambah file, atau bagikan file ke Universal Converter dari aplikasi lain.
2. Ketuk sebuah file di daftar: opsinya sendiri terbuka.
3. Ketuk sebuah format: opsinya terbuka tepat di bawahnya. Ketuk (i) di samping opsi untuk membaca fungsinya.
4. Kembali ke daftar dan ketuk Ubah: setiap file diubah.
Hasil disimpan di Downloads/Universal Converter. Gunakan Buka atau Bagikan untuk langsung memakainya.
Anda bisa memilih tempat lain di Pengaturan > Lokasi penyimpanan default; aplikasi bertanya sekali, setelah konversi pertama.
Setiap file punya pengaturannya sendiri: salin dari file sebelumnya dengan format yang sama atau ke setiap file format itu; «File berikutnya» membawa Anda ke file selanjutnya.
Tidak perlu suatu format? Sembunyikan di Pengaturan > Format. File tanpa format yang dipilih mendapat format bawaan (Pengaturan > Format bawaan).
Menu ☰ di kiri atas membuka Pengaturan, panduan ini, Yang baru & perbaikan, dan Dukung; Pengaturan juga ada di kanan atas.

KONVERSI YANG LAMA
Anda bisa meninggalkan aplikasi saat video dikonversi: aplikasi tetap bekerja di latar belakang. Video panjang atau beresolusi tinggi bisa lama dan membuat ponsel hangat. Jika mau, Pengaturan > Notifikasi memberi tahu saat konversi selesai. Goyangkan ponsel dengan kuat untuk memulai Konversi (Pengaturan > Goyangkan untuk mengonversi).

PENGENALAN TEKS (OCR)
Bahasa Inggris dan bahasa lain beraksara Latin (seperti Indonesia dan Turki), serta Yunani, sudah ada di aplikasi. Otomatis membaca bahasa-bahasa ini dan setiap aksara yang telah Anda unduh. Untuk membaca bahasa lain, ketuk Ubah di samping Bahasa dan centang bahasa dalam file Anda: jika salah satunya memerlukan aksara yang belum ada di ponsel (Sirilik, Arab, Tionghoa, Jepang, Korea, Thai, Hindi, Georgia, Tamil), aplikasi menawarkan untuk langsung mengunduhnya, dan Anda melanjutkan dari tempat semula. Aksara yang diunduh dapat dihapus di Pengaturan. Jika sebagian besar teks tidak dapat dibaca, aplikasi memberi tahu dan menawarkan untuk menambahkan aksara. Bahasa Ibrani dan Vietnam juga dibaca: masing-masing diunduh sekali, saat pertama kali dipilih. Pindaian dan formulir yang sudah diisi menjadi teks dan tabel yang dapat diedit, tersusun seperti halamannya (opsi "Halaman dengan teks berupa gambar" di opsi sebuah PDF).

BAHASA
Ke-34 bahasa sudah ada di aplikasi: pilih salah satunya di Pengaturan > Bahasa aplikasi, dan aplikasi dimulai ulang dalam bahasa itu. Bahasa Arab dan Ibrani ditampilkan dari kanan ke kiri. Aplikasi bertema gelap secara default; pilih Terang atau Ikuti ponsel di Pengaturan > Tampilan.

BATASAN DI PONSEL
File yang sangat besar bisa gagal di ponsel dengan memori kecil. Video mana yang dapat dibuka bergantung pada ponsel Anda.

PEMBARUAN
Aplikasi memeriksa versi baru sekitar sekali sehari dan memberi tahu Anda jika ada (matikan di Pengaturan > Pembaruan). Ketuk Unduh, lalu buka file yang diunduh untuk memasangnya di atas versi ini; pengaturan Anda tetap ada. Jika Anda memasang aplikasi dari Google Play, Google Play yang memperbaruinya.

MENCOPOT PEMASANGAN
Tahan ikon aplikasi lalu pilih Uninstal. File yang Anda konversi tetap di tempat penyimpanannya.

BANTUAN DAN DUKUNGAN
Pertanyaan, laporan masalah, dan permintaan fitur: universal.converter@outlook.com
Email untuk pertanyaan, ide, dan bahasa yang ingin Anda tambahkan: universal.converter@outlook.com
Situs web: https://getuniversalconverter.com/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Hak cipta dilindungi undang-undang.
