UNIVERSAL CONVERTER UNTUK ANDROID - MEMULAI
Versi 3.3

Universal Converter mengonversi gambar, dokumen, video, dan audio, membuat PDF, dan mengambil tabel ke Excel. Semuanya berlangsung di ponsel Anda: file Anda tidak pernah diunggah. Aplikasi hanya memakai internet untuk memeriksa versi baru, mengunduh aksara pengenalan teks yang Anda pilih, dan saat Anda membuka tautan. Jika Anda mengizinkan, aplikasi juga mengirim laporan kesalahan anonim saat terjadi masalah.

YANG DAPAT DILAKUKANNYA
Dokumen & PDF - Konversi antar PDF, Word, ODT, RTF, TXT, Markdown, HTML, EPUB, PowerPoint, dan Excel. Ubah halaman menjadi gambar, dan gabungkan beberapa file menjadi satu PDF. Kompres PDF: tambahkan PDF, pilih Kompres PDF, lalu masukkan ukuran yang Anda perlukan (mis. 500 KB); gambar di dalamnya diperkecil sampai pas dan teksnya tetap tajam.
Gambar - Konversi antar JPG, PNG, WEBP, BMP, GIF, TIFF, dan ICO. Foto HEIC dan AVIF juga dapat dibuka. Ubah ukuran berdasarkan piksel, persen, atau ukuran file. Ubah gambar menjadi PDF atau Word, dan baca teks dalam gambar (OCR). PDF juga dapat ditambahkan: setiap halaman menjadi gambar.
Video - Konversi video ke MP4, MKV, WebM, atau MOV, atau buat GIF animasi. MP4, MKV, dan MOV memakai H.264 atau H.265 dari encoder perangkat keras ponsel Anda; WebM memakai format terbuka VP9 dan Opus. Pilih kualitas, resolusi, dan bagian video; potong, putar, atau hapus suara; atau simpan suaranya saja sebagai M4A, OGG, atau WAV.
Simpan bingkai - Di tab Video, pilih Simpan bingkai, tentukan rentang waktunya, lalu simpan satu gambar setiap beberapa detik, setiap bingkai, atau hanya satu.
Ke Excel - Ambil tabel dari PDF, hasil pindaian, foto, dan file Word ke Excel atau CSV.
Tanda tangan - Tanda tangani PDF dan isi formulir. Buat tanda tangan Anda sekali - ketik nama Anda dan pilih gaya, gambar dengan jari atau pena, atau pakai fotonya di atas kertas - lalu biarkan aplikasi menemukan garis tanda tangan, atau ketuk halaman di tempat tanda tangan, paraf, tanggal, teks, atau centang diletakkan. Banyak file ditandatangani sekaligus; masing-masing disimpan sebagai nama_signed.pdf dan file aslinya tetap seperti semula. Ini adalah tanda tangan elektronik yang terlihat, bukan tanda tangan digital berbasis sertifikat.

CARA PAKAI
1. Pilih tab di bagian bawah layar.
2. Ketuk Tambah file, atau bagikan file ke Universal Converter dari aplikasi lain.
3. Ketuk sebuah format: opsinya terbuka tepat di bawahnya. Ketuk (i) di samping opsi untuk membaca fungsinya.
4. Ketuk tombol di bawah opsi.
Hasil disimpan di Downloads/Universal Converter. Gunakan Buka atau Bagikan untuk langsung memakainya.
Jika Anda menambahkan file yang dikonversi di tab lain, aplikasi memberi tahu tab mana dan membawanya ke sana dengan satu ketukan.

KONVERSI YANG LAMA
Anda dapat meninggalkan aplikasi selama video dikonversi. Sebuah notifikasi menunjukkan bahwa proses masih berjalan, jadi izinkan notifikasi saat diminta. Video yang panjang atau beresolusi tinggi bisa memakan waktu dan membuat ponsel hangat.

PENGENALAN TEKS (OCR)
Bahasa Inggris dan bahasa lain beraksara Latin (seperti Indonesia dan Turki), serta Yunani, sudah ada di aplikasi. Otomatis membaca bahasa-bahasa ini dan setiap aksara yang telah Anda unduh. Untuk membaca bahasa lain, ketuk Ubah di samping Bahasa dan centang bahasa dalam file Anda: jika salah satunya memerlukan aksara yang belum ada di ponsel (Sirilik, Arab, Tionghoa, Jepang, Korea, Thai, Hindi, Georgia, Tamil), aplikasi menawarkan untuk langsung mengunduhnya, dan Anda melanjutkan dari tempat semula. Aksara yang diunduh dapat dihapus di Pengaturan. Jika sebagian besar teks tidak dapat dibaca, aplikasi memberi tahu dan menawarkan untuk menambahkan aksara. Bahasa Ibrani dan Vietnam juga dibaca: masing-masing diunduh sekali, saat pertama kali dipilih. Pindaian dan formulir yang sudah diisi menjadi teks dan tabel yang dapat diedit, tersusun seperti halamannya (opsi "Halaman dengan teks berupa gambar" di tab Dokumen & PDF dan Ke Excel).

BAHASA
Ke-22 bahasa sudah ada di aplikasi: pilih salah satunya di Pengaturan > Bahasa aplikasi, dan aplikasi dimulai ulang dalam bahasa itu. Bahasa Arab dan Ibrani ditampilkan dari kanan ke kiri. Aplikasi bertema gelap secara default; pilih Terang atau Ikuti ponsel di Pengaturan > Tampilan.

BATASAN DI PONSEL
File .doc dan .ppt lama tidak dapat dibuka: simpan dulu sebagai .docx atau .pptx. File .ods belum dapat dibaca, dan PDF yang dilindungi kata sandi belum dapat diubah menjadi gambar. File yang sangat besar bisa gagal di ponsel dengan memori kecil. Video mana yang dapat dibuka bergantung pada ponsel Anda.

PEMBARUAN
Aplikasi memeriksa versi baru sekitar sekali sehari dan memberi tahu Anda jika ada (matikan di Pengaturan > Pembaruan). Ketuk Unduh, lalu buka file yang diunduh untuk memasangnya di atas versi ini; pengaturan Anda tetap ada. Jika Anda memasang aplikasi dari Google Play, Google Play yang memperbaruinya.

MENCOPOT PEMASANGAN
Tahan ikon aplikasi dan pilih Copot pemasangan. File yang Anda konversi tetap ada di Downloads/Universal Converter.

BANTUAN DAN DUKUNGAN
Pertanyaan, laporan masalah, dan permintaan fitur: universal.converter@outlook.com
Email untuk pertanyaan, ide, dan bahasa yang ingin Anda tambahkan: universal.converter@outlook.com
Situs web: https://christzouv.github.io/universal-converter/

Universal Converter - Copyright (c) 2026 Christos Tzouvaras. Hak cipta dilindungi undang-undang.
